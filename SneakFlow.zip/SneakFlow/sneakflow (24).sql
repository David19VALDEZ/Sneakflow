-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-11-2024 a las 20:08:37
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sneakflow`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrito`
--

CREATE TABLE `carrito` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `talla_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `colores`
--

CREATE TABLE `colores` (
  `id` int(11) NOT NULL,
  `color` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `colores`
--

INSERT INTO `colores` (`id`, `color`) VALUES
(1, 'Blanco'),
(2, 'Negro'),
(3, 'Gris'),
(4, 'Azul'),
(5, 'Rojo'),
(6, 'Verde'),
(7, 'Amarillo'),
(8, 'Naranja'),
(9, 'Rosa'),
(10, 'Marrón'),
(11, 'Beige'),
(12, 'Morado'),
(13, 'Turquesa'),
(14, 'Bordeaux'),
(15, 'Plata'),
(16, 'Oro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_pedidos`
--

CREATE TABLE `detalles_pedidos` (
  `id` int(11) NOT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `producto_id` int(11) NOT NULL,
  `talla_id` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `metodo_pago` enum('Daviplata','Nequi') NOT NULL,
  `numero_pago` int(255) NOT NULL,
  `fecha_pedido` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalles_pedidos`
--

INSERT INTO `detalles_pedidos` (`id`, `pedido_id`, `producto_id`, `talla_id`, `cantidad`, `precio`, `metodo_pago`, `numero_pago`, `fecha_pedido`) VALUES
(23, 24, 6, 18, 1, 200000.00, 'Daviplata', 2147483647, '2024-10-21 00:00:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `favoritos`
--

CREATE TABLE `favoritos` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `favoritos`
--

INSERT INTO `favoritos` (`id`, `usuario_id`, `producto_id`, `estado`, `fecha_creacion`) VALUES
(15, 1, 6, 1, '2024-11-01 16:01:42'),
(16, 1, 22, 1, '2024-11-01 17:35:19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marcas`
--

CREATE TABLE `marcas` (
  `id` int(11) NOT NULL,
  `marca` varchar(100) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `imagen` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `marcas`
--

INSERT INTO `marcas` (`id`, `marca`, `logo`, `descripcion`, `imagen`) VALUES
(1, 'Nike', '', 'Nike es una marca líder en la industria del calzado deportivo, conocida por sus innovaciones tecnológicas como Air Max y Nike Free. Ofrece una amplia gama de zapatillas para todos los deportes y actividades, con un diseño moderno y rendimiento superior.', 'Adidas.jpg'),
(2, 'Adidas', 'logo_adidas.png', 'Adidas es famosa por su estilo icónico y su tecnología de amortiguación Boost. La marca combina moda y funcionalidad, ofreciendo zapatillas para correr, entrenar y uso diario, destacándose por su durabilidad y comodidad.', 'Adidas.jpg'),
(3, 'Puma', '', 'Puma se destaca por sus diseños deportivos y colaboraciones con celebridades. Ofrece una mezcla de estilo y rendimiento, con modelos que abarcan desde zapatillas para deportes hasta opciones casuales.', 'Adidas.jpg'),
(4, 'Reebok', '', 'Reebok es conocida por su amplia gama de zapatillas de entrenamiento y deporte. Con un enfoque en la comodidad y la funcionalidad, Reebok ofrece productos de alta calidad a precios accesibles.', 'Adidas.jpg'),
(5, 'New Balance', '', 'New Balance se especializa en zapatillas deportivas que ofrecen un excelente soporte y comodidad. Ideal para corredores y caminantes, la marca es reconocida por sus tecnologías de amortiguación y ajuste personalizado.', 'NewBalance.jpg'),
(6, 'Asics', '', 'Asics es una marca de renombre en el ámbito del running, conocida por su tecnología de amortiguación GEL. Ofrece zapatillas diseñadas para mejorar el rendimiento y reducir el impacto en las articulaciones.', 'Asics.jpg'),
(7, 'Converse', '', 'Converse es famosa por sus zapatillas Chuck Taylor All Star, un clásico atemporal en el mundo de la moda. Ofrece un estilo casual y versátil que ha perdurado a lo largo de los años.', 'Converse.jpg'),
(8, 'Saucony', '', 'Saucony se enfoca en la tecnología de rendimiento para corredores, proporcionando zapatillas que combinan comodidad y soporte. Es conocida por sus modelos altamente recomendados para entrenamiento y carreras.', 'Saucony.jpg'),
(9, 'Under Armour', '', 'Under Armour es una marca innovadora en el ámbito deportivo, ofreciendo zapatillas con tecnologías avanzadas para mejorar el rendimiento y la comodidad durante el ejercicio.', 'UnderArmour.jpg'),
(10, 'Vans', '', 'Vans es icónica por sus zapatillas estilo skater y casual. Con un enfoque en el estilo y la autenticidad, Vans ofrece una amplia variedad de diseños que capturan la esencia del estilo urbano.', 'Vans.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `repartidor_id` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `total` decimal(10,2) NOT NULL,
  `estado` enum('pendiente','procesado','entregado') DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id`, `usuario_id`, `repartidor_id`, `fecha`, `total`, `estado`) VALUES
(24, 1, 1, '2024-10-20 19:00:32', 200000.00, 'entregado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `marca_id` int(11) DEFAULT NULL,
  `genero` enum('Hombre','Mujer','Unisex','') DEFAULT NULL,
  `color_id` int(11) DEFAULT NULL,
  `promocion` tinyint(1) DEFAULT 0,
  `precio` decimal(10,2) NOT NULL,
  `descuento` varchar(50) DEFAULT NULL,
  `existencias` int(11) DEFAULT NULL,
  `fecha_agregado` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `imagen`, `marca_id`, `genero`, `color_id`, `promocion`, `precio`, `descuento`, `existencias`, `fecha_agregado`) VALUES
(2, 'Zapatos de Cuero', 'Zapatos elegantes para ocasiones especiales.', 'Adidas.jpg', 2, 'Mujer', 10, 1, 150000.00, '12', 95, '2024-08-22 22:16:37'),
(6, 'Nike Air Max 270', 'Las Nike Air Max 270 son unas zapatillas de estilo urbano que combinan confort y diseño moderno. Con una parte superior de malla transpirable y una suela Max Air que ofrece una excelente amortiguación, son ideales tanto para el uso diario como para ocasiones especiales. Su diseño atractivo y colores vibrantes hacen que destaquen en cualquier outfit.', 'Adidas.jpg', 1, 'Hombre', 2, 1, 200000.00, '10', 25, '2024-10-07 17:32:26'),
(22, 'qefe', '343r23tewfwefw', 'getting-started-with-cybersecurity.png', 3, 'Hombre', 15, 0, 200000.00, '5', 15, '2024-10-31 12:00:17'),
(23, 'Asf', 'wff', 'fotor-ai-20240419164922.jpg', 1, 'Hombre', 14, 1, 122222.00, '0', 12, '2024-11-01 10:56:45');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recuperaciones`
--

CREATE TABLE `recuperaciones` (
  `recuperar_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `repartidores`
--

CREATE TABLE `repartidores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `contacto_nombre` varchar(100) DEFAULT NULL,
  `contacto_telefono` varchar(20) DEFAULT NULL,
  `contacto_email` varchar(100) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `pedidos_activos` int(11) DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `repartidores`
--

INSERT INTO `repartidores` (`id`, `nombre`, `contacto_nombre`, `contacto_telefono`, `contacto_email`, `direccion`, `pedidos_activos`, `creado_en`) VALUES
(1, 'Helbert Dubler Morera Hernández', 'r12r23', '52353253', 'ergergeher@hrefhe', '34y34y34', 2, '2024-10-17 13:57:15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tallas`
--

CREATE TABLE `tallas` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `talla` varchar(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `disponible` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tallas`
--

INSERT INTO `tallas` (`id`, `producto_id`, `talla`, `cantidad`, `disponible`) VALUES
(15, 2, '32', 31, 1),
(18, 6, '31', 12, 1),
(35, 6, '42', 13, 1),
(36, 2, '41', 43, 1),
(38, 2, '43', 2, 1),
(39, 2, '40', 19, 1),
(40, 22, '40', 15, 1),
(41, 23, '43', 12, 1);

--
-- Disparadores `tallas`
--
DELIMITER $$
CREATE TRIGGER `actualizar_existencias_actualizacion` AFTER UPDATE ON `tallas` FOR EACH ROW BEGIN
    -- Calcular la suma de todas las tallas disponibles para el producto
    IF OLD.cantidad != NEW.cantidad OR OLD.disponible != NEW.disponible THEN
        UPDATE productos
        SET existencias = (
            SELECT SUM(cantidad)
            FROM tallas
            WHERE producto_id = NEW.producto_id AND disponible = 1
        )
        WHERE id = NEW.producto_id;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `actualizar_existencias_after_delete` AFTER DELETE ON `tallas` FOR EACH ROW BEGIN
    -- Actualizar las existencias del producto tras eliminar una talla
    UPDATE productos
    SET existencias = (
        SELECT SUM(cantidad)
        FROM tallas
        WHERE producto_id = OLD.producto_id AND disponible = 1
    )
    WHERE id = OLD.producto_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `actualizar_existencias_after_insert` AFTER INSERT ON `tallas` FOR EACH ROW BEGIN
    -- Actualizar las existencias del producto tras insertar una nueva talla
    UPDATE productos
    SET existencias = (
        SELECT SUM(cantidad)
        FROM tallas
        WHERE producto_id = NEW.producto_id AND disponible = 1
    )
    WHERE id = NEW.producto_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `actualizar_existencias_after_update` AFTER UPDATE ON `tallas` FOR EACH ROW BEGIN
    -- Solo actualizar si la cantidad o disponible han cambiado
    IF OLD.cantidad != NEW.cantidad OR OLD.disponible != NEW.disponible THEN
        UPDATE productos
        SET existencias = (
            SELECT SUM(cantidad)
            FROM tallas
            WHERE producto_id = NEW.producto_id AND disponible = 1
        )
        WHERE id = NEW.producto_id;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `tipo_documento` enum('C.C','T.I') DEFAULT NULL,
  `numero_documento` varchar(20) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `contrasena` varchar(255) NOT NULL,
  `rol` enum('usuario','administrador') DEFAULT 'usuario',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `correo`, `tipo_documento`, `numero_documento`, `telefono`, `direccion`, `contrasena`, `rol`, `fecha_registro`) VALUES
(1, 'Helbert', 'morerahelbert9@gmail.com', 'T.I', '1102938212', '525', 'Kr6 Sur #6-27', '$2y$10$qbilwIAN3XEIBHi6.b7h3uJ48VFa4TvWfLpRbKtbnELE7W80B3fIi', 'administrador', '2024-09-01 22:07:19'),
(2, 'Valdez', 'brayan@gmail.com', NULL, NULL, '3105738706', 'Kr6 Sur #6-27', '$2y$10$cdiQ71q.iGe2alswra/Xa.eVFdwdavdsgNkPic/gFg5RGijfeui3W', 'administrador', '2024-09-01 22:07:19'),
(3, 'Brayan', 'valdez@gmail.com', NULL, NULL, '3105738706', 'Kr6 Sur #6-29', '$2y$10$QOYDn0GvCA5i3F08Yn595eBGvbZ.3.nAYs5P3cQ/GcWFHawJXzOae', 'administrador', '2024-09-01 22:07:21');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carrito`
--
ALTER TABLE `carrito`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `producto_id` (`producto_id`),
  ADD KEY `talla_id` (`talla_id`);

--
-- Indices de la tabla `colores`
--
ALTER TABLE `colores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `detalles_pedidos`
--
ALTER TABLE `detalles_pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedido_id` (`pedido_id`),
  ADD KEY `producto_id` (`producto_id`),
  ADD KEY `talla_id` (`talla_id`);

--
-- Indices de la tabla `favoritos`
--
ALTER TABLE `favoritos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `marcas`
--
ALTER TABLE `marcas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `fk_repartidor` (`repartidor_id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_marca` (`marca_id`),
  ADD KEY `fk_color` (`color_id`);

--
-- Indices de la tabla `recuperaciones`
--
ALTER TABLE `recuperaciones`
  ADD PRIMARY KEY (`recuperar_id`),
  ADD KEY `fk_usuario` (`usuario_id`);

--
-- Indices de la tabla `repartidores`
--
ALTER TABLE `repartidores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tallas`
--
ALTER TABLE `tallas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_producto` (`producto_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carrito`
--
ALTER TABLE `carrito`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT de la tabla `colores`
--
ALTER TABLE `colores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `detalles_pedidos`
--
ALTER TABLE `detalles_pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `favoritos`
--
ALTER TABLE `favoritos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `marcas`
--
ALTER TABLE `marcas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `recuperaciones`
--
ALTER TABLE `recuperaciones`
  MODIFY `recuperar_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `repartidores`
--
ALTER TABLE `repartidores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `tallas`
--
ALTER TABLE `tallas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `carrito`
--
ALTER TABLE `carrito`
  ADD CONSTRAINT `carrito_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `carrito_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `carrito_ibfk_3` FOREIGN KEY (`talla_id`) REFERENCES `tallas` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `detalles_pedidos`
--
ALTER TABLE `detalles_pedidos`
  ADD CONSTRAINT `detalles_pedidos_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `detalles_pedidos_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `detalles_pedidos_ibfk_3` FOREIGN KEY (`talla_id`) REFERENCES `tallas` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `favoritos`
--
ALTER TABLE `favoritos`
  ADD CONSTRAINT `favoritos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `favoritos_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `fk_repartidor` FOREIGN KEY (`repartidor_id`) REFERENCES `repartidores` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_color` FOREIGN KEY (`color_id`) REFERENCES `colores` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_marca` FOREIGN KEY (`marca_id`) REFERENCES `marcas` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `recuperaciones`
--
ALTER TABLE `recuperaciones`
  ADD CONSTRAINT `fk_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `tallas`
--
ALTER TABLE `tallas`
  ADD CONSTRAINT `fk_producto` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE;

DELIMITER $$
--
-- Eventos
--
CREATE DEFINER=`root`@`localhost` EVENT `eliminar_recuperaciones_antiguas` ON SCHEDULE EVERY 1 HOUR STARTS '2024-10-12 21:17:52' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    DELETE FROM `recuperaciones`
    WHERE `created_at` < NOW() - INTERVAL 24 HOUR;
END$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
