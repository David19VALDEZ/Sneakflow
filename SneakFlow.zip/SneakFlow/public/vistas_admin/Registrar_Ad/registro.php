<?php 
    require_once '../public/vistas_admin/menu.php'; 
?>

<link rel="stylesheet" href="/SneakFlow/public/vistas_admin/css/registro.css">

<style>
    .flex {
        display: <?php echo isset($mostrarPopup) && $mostrarPopup ? 'none' : 'flex'; ?>; /* Oculta el contenido principal si el popup está visible */
        justify-content: center; /* Centrar horizontalmente */
    }
</style>
<div class="content-container flex justify-center items-center min-h-screen  mx-auto">
    <div class="flex-1 p-10 bg-gray-900 rounded-lg shadow-lg w-full max-w-[1400px] mx-auto mt-5"> <!-- Aumentar max-w -->
        <h2 class="text-4xl font-bold text-white text-center">Registro de Administrador</h2> <!-- Aumentar tamaño del título -->
        <div class="border-b-2 border-green-500 my-4"></div>

        <form action="registroAdmin" method="POST" onsubmit="return validarFormulario()" class="space-y-6"> <!-- Aumentar el espacio entre campos -->
            <div class="grid grid-cols-2 gap-6"> <!-- Aumentar el espacio entre columnas -->
                <div>
                    <label for="usuario" class="block text-gray-300">Usuario:</label>
                    <input type="text" id="usuario" name="usuario" required autocomplete="username" class="w-full p-3 rounded bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-green-500 transition duration-300" placeholder="Ingrese su usuario">
                </div>

                <div>
                    <label for="correo" class="block text-gray-300">Correo:</label>
                    <input type="email" id="correo" name="correo" required autocomplete="email" class="w-full p-3 rounded bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-green-500 transition duration-300" placeholder="Ingrese su correo">
                </div>

                <div>
                    <label for="tipo_documento" class="block text-gray-300">Tipo de Documento:</label>
                    <select id="tipo_documento" name="tipo_documento" required class="w-full p-3 rounded bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-green-500 transition duration-300">
                        <option value="">Seleccione</option>
                        <option value="C.C">C.C</option>
                        <option value="T.I">T.I</option>
                    </select>
                </div>

                <div>
                    <label for="numero_documento" class="block text-gray-300">Número de Documento:</label>
                    <input type="text" id="numero_documento" name="numero_documento" required pattern="\d{10}" title="Debe tener exactamente 10 dígitos" class="w-full p-3 rounded bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-green-500 transition duration-300" placeholder="Ingrese el número del documento">
                </div>

                <div>
                    <label for="telefono" class="block text-gray-300">Teléfono:</label>
                    <input type="text" id="telefono" name="telefono" required pattern="\d{10}" title="Debe tener exactamente 10 dígitos" class="w-full p-3 rounded bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-green-500 transition duration-300" placeholder="Ingrese su teléfono">
                </div>

                <div>
                    <label for="direccion" class="block text-gray-300">Dirección:</label>
                    <input type="text" id="direccion" name="direccion" required class="w-full p-3 rounded bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-green-500 transition duration-300" placeholder="Ingrese su dirección">
                </div>

                <div class="col-span-2">
                    <label for="contrasena" class="block text-gray-300">Contraseña:</label>
                    <input type="password" id="contrasena" name="contrasena" required autocomplete="new-password" class="w-full p-3 rounded bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-green-500 transition duration-300" placeholder="Ingrese su contraseña">
                </div>
            </div>

            <input type="hidden" name="rol" value="administrador">

            <button type="submit" class="w-full bg-green-600 text-white font-bold py-3 rounded hover:bg-green-700 transition duration-300">Registrar</button>

            <?php
                // Mensajes de éxito o error
                if (isset($_GET['mensaje'])): ?>
                    <script>
                        alert('<?php echo htmlspecialchars($_GET['mensaje']); ?>');
                    </script>
                <?php endif; ?>

            <?php
                if (isset($_GET['error'])): ?>
                    <script>
                        alert('<?php echo htmlspecialchars($_GET['error']); ?>');
                    </script>
                <?php endif; ?>
        </form>
    </div>
</div>

