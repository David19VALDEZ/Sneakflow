<?php
// Incluye la cabecera principal de la página
require_once '../public/vistas/header.php';

// Incluye la función de verificación de administrador
require_once __DIR__ . '/../../app/seguridad/verificarAdmin.php';

// Llama a la función de verificación de sesión de administrador
verificarSesionAdmin();

// Incluye el archivo de alerta
include 'alerta.php';
?>

<!-- Incluye Tailwind CSS -->
<script src="https://cdn.tailwindcss.com"></script>

<!-- Fuente moderna -->
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">

<!-- Incluye estilos específicos -->
<link rel="stylesheet" href="/SneakFlow/public/vistas_admin/css/menu.css">
<style>
    .flex {
        display: <?php echo isset($mostrarPopup) && $mostrarPopup ? 'none' : 'flex'; ?>; /* Oculta el contenido principal si el popup está visible */
    }
</style>
<body class="bg-gray-100 font-roboto">
    <!-- Menú lateral -->
    <div class="menu-degradado menu fixed top-0 left-0 h-full bg-gray-800 text-white shadow-lg flex flex-col">
        <h1 class="text-2xl font-bold text-center py-4 border-b border-green-700 mt-14 md:mt-14 mb-2 font-poppins">Panel de Administración</h1>
        
        <div class="flex-grow menu-scroll">
            <nav class="flex flex-col">
                <h3 class="text-lg font-bold p-4 border-b border-green-700">Administrar</h3>
                <a href="Administrar-Usuarios" class="p-4 hover:bg-gray-700 transition-colors duration-300 mb-2 md:mb-4 mt- md:mt-4">
                    <i class="fas fa-users"></i> Administrar Usuarios
                </a>
                <a href="Administrar-Productos" class="p-4 hover:bg-gray-700 transition-colors duration-300 mb-2 md:mb-4 mt-2 md:mt-4">
                    <i class="fas fa-box"></i> Administrar Productos
                </a>
                <a href="Administrar-Pedidos" class="p-4 hover:bg-gray-700 transition-colors duration-300 mb-2 md:mb-4 mt-2 md:mt-4">
                    <i class="fas fa-receipt"></i> Administrar Pedidos
                </a>

                <div class="mb-2"></div> <!-- Espacio reducido entre secciones -->

                <h3 class="text-lg font-bold p-4 border-b border-green-700">Crear</h3>
                <a href="Crear-Producto" class="p-4 hover:bg-gray-700 transition-colors duration-300 mb-2 md:mb-4 mt-2 md:mt-4">
                    <i class="fas fa-plus-circle"></i> Crear Productos
                </a>
                <a href="Formulario-de-Repartidor" class="p-4 hover:bg-gray-700 transition-colors duration-300 mb-2 md:mb-4 mt-2 md:mt-4">
                    <i class="fas fa-receipt"></i> Registrar Repartidor
                </a>
                <a href="Login-Admin" class="p-4 hover:bg-gray-700 transition-colors duration-300 mb-2 md:mb-4 mt-2 md:mt-4">
                    <i class="fas fa-user-plus"></i> Registrar Administradores
                </a>
            </nav>

        </div>

        <footer class="p-4 border-t border-green-700 text-center text-sm">
            © 2024 SneakFlow. Todos los derechos reservados.
        </footer>
    </div>


    <!-- Incluye Font Awesome para los iconos -->
    <script src="/SneakFlow/public/vistas_admin/js/menu.js"></script>
    <script src="/SneakFlow/public/vistas/js/general.js"></script>
</body>
