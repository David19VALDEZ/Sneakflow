<?php     
    require_once '../public/vistas_admin/menu.php';  
?>
<style>
    .flex {
        display: <?php echo isset($mostrarPopup) && $mostrarPopup ? 'none' : 'flex'; ?>;
    }
</style>

<link rel="stylesheet" href="/SneakFlow/public/vistas_admin/css/repartidor.css">

<div class="flex justify-center items-center min-h-screen bg-gray-100">
    <div class="content bg-gray-900 text-white p-8 rounded-lg shadow-lg max-w-lg mt-14">
        <h2 class="text-3xl font-bold mb-2 text-center">Agregar Repartidor</h2>
        <hr class="border-b-2 border-green-400 mb-4">
        <form action="agregarRepartidor" method="POST">
            <div class="grid grid-cols-1 gap-6"> <!-- Cambiar a 1 columna -->

                <!-- Nombre del Distribuidor -->
                <div class="form-group">
                    <label for="nombre" class="block text-sm font-medium text-gray-300">Nombre del Distribuidor</label>
                    <input type="text" id="nombre" name="nombre" required class="mt-1 block w-full p-3 bg-gray-800 border border-green-500 text-white rounded-lg focus:border-green-400 focus:ring focus:ring-green-300 transition duration-200 ease-in-out">
                </div>

                <!-- Nombre de Contacto -->
                <div class="form-group">
                    <label for="contacto_nombre" class="block text-sm font-medium text-gray-300">Nombre de Contacto</label>
                    <input type="text" id="contacto_nombre" name="contacto_nombre" class="mt-1 block w-full p-3 bg-gray-800 border border-green-500 text-white rounded-lg focus:border-green-400 focus:ring focus:ring-green-300 transition duration-200 ease-in-out">
                </div>

                <!-- Teléfono de Contacto -->
                <div class="form-group">
                    <label for="contacto_telefono" class="block text-sm font-medium text-gray-300">Teléfono de Contacto</label>
                    <input type="text" id="contacto_telefono" name="contacto_telefono" class="mt-1 block w-full p-3 bg-gray-800 border border-green-500 text-white rounded-lg focus:border-green-400 focus:ring focus:ring-green-300 transition duration-200 ease-in-out">
                </div>

                <!-- Email de Contacto -->
                <div class="form-group">
                    <label for="contacto_email" class="block text-sm font-medium text-gray-300">Email de Contacto</label>
                    <input type="email" id="contacto_email" name="contacto_email" class="mt-1 block w-full p-3 bg-gray-800 border border-green-500 text-white rounded-lg focus:border-green-400 focus:ring focus:ring-green-300 transition duration-200 ease-in-out">
                </div>

                <!-- Dirección -->
                <div class="form-group">
                    <label for="direccion" class="block text-sm font-medium text-gray-300">Dirección</label>
                    <textarea id="direccion" name="direccion" rows="2" class="mt-1 block w-full p-3 bg-gray-800 border border-green-500 text-white rounded-lg focus:border-green-400 focus:ring focus:ring-green-300 transition duration-200 ease-in-out"></textarea>
                </div>

            </div>

            <!-- Botón Agregar Distribuidor -->
            <button type="submit" class="mt-6 w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg shadow-md transition duration-300 ease-in-out focus:outline-none focus:ring focus:ring-green-300">
                Agregar Distribuidor
            </button>
        </form>
    </div>
</div>
