function confirmDelete(button) {
    // Muestra un cuadro de diálogo de confirmación
    const confirmed = confirm("¿Estás seguro de que deseas eliminar este producto?");

    if (confirmed) {
        // Si el usuario confirma, enviamos el formulario que contiene este botón
        button.closest('form').submit();
    }
}

function openDescriptionModal(description) {
    document.getElementById("fullDescription").innerText = description; // Establecer la descripción en el modal
    document.getElementById("descriptionModal").style.display = "block"; // Mostrar el modal
}

// Función para cerrar el modal
function closeDescriptionModal() {
    document.getElementById("descriptionModal").style.display = "none"; // Ocultar el modal
}

// Cerrar el modal si se hace clic fuera de él
window.onclick = function(event) {
    if (event.target == document.getElementById("descriptionModal")) {
        closeDescriptionModal();
    }
}

// Función para abrir el modal de edición del producto específico
function openEditModal(productId) {
    // Obtener el modal específico usando el ID del producto
    let modal = document.getElementById('editModal_' + productId);
    modal.style.display = 'block';
}

// Función para cerrar el modal de edición del producto específico
function closeEditModal(productId) {
    // Obtener el modal específico usando el ID del producto
    let modal = document.getElementById('editModal_' + productId);
    modal.style.display = 'none';
}

function openAddSizeModal(productId) {
    const modal = document.getElementById('addSizeModal_' + productId);
    if (modal) {
        modal.style.display = 'block';
    }
}

function openEditSizeModal(productId) {
    const modal = document.getElementById('editSizeModal_' + productId);
    if (modal) {
        modal.style.display = 'block';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none'; // Oculta el modal
    }
}

