function validarFormulario() {
    const telefono = document.getElementById('telefono').value;
    const numeroDocumento = document.getElementById('numero_documento').value;

    if (telefono.length !== 10 || isNaN(telefono)) {
        alert('El número de teléfono debe tener exactamente 10 dígitos.');
        return false; // Evitar el envío del formulario
    }

    if (numeroDocumento.length !== 10 || isNaN(numeroDocumento)) {
        alert('El número de documento debe tener exactamente 10 dígitos.');
        return false; // Evitar el envío del formulario
    }

    return true; // Permitir el envío del formulario
}