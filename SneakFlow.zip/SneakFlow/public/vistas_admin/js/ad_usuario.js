
// Función para abrir el modal
function openEditModal(userId) {
    // Encuentra el modal correspondiente
    var modal = document.getElementById('editUsuario_' + userId);
    if (modal) {
        modal.style.display = 'block'; // Muestra el modal
    }
}

// Función para cerrar el modal
function closeEditModal(userId) {
    var modal = document.getElementById('editUsuario_' + userId);
    if (modal) {
        modal.style.display = 'none'; // Oculta el modal
    }
}

// Cierra el modal cuando se hace clic fuera del contenido del modal
window.onclick = function(event) {
    var modals = document.querySelectorAll('.modal');
    modals.forEach(function(modal) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    });
}

