
    <!-- Enlace a la hoja de estilos específica para la administración de usuarios -->
    <link rel="stylesheet" href="/SneakFlow/public/vistas_admin/css/ad_pedido.css">
    <style>
        /* Estilo para el contenedor principal */
        display: <?php echo isset($mostrarPopup) && $mostrarPopup ? 'none' : 'flex'; ?>; /* Oculta el contenido principal si el popup está visible */
    </style>
    <!-- Contenedor principal que incluye menús y contenido -->
    <div class="main-container">
        <div class="content-container mt-16 bg-gray-900">
            <?php
            // Incluye el menú de administración
            require_once '../public/vistas_admin/menu.php'; ?>            
            <h1 class="text-3xl font-bold text-center text-white mb-6 relative">
                Administrar Pedidos
                <div class="border-b border-green-500 absolute w-full top-full left-0"></div>
            </h1>

            <div class="overflow-x-auto">
                <table class="min-w-full  bg-gray-800 rounded-lg shadow-lg table ">
                    <thead class=" text-white uppercase text-xs">
                        <tr>
                            <th>ID del pedido</th>
                            <th>Usuario</th>
                            <th>Método de pago</th>
                            <th>Dirección</th>
                            <th>Total</th>
                            <th>Fecha</th>
                            <th>Estado</th>
                            <th>Repartidor</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="text-white text-xs">
                        <?php foreach ($pedidos as $pedido): ?>
                            <tr class="border-b hover:bg-gray-500 text-center">
                                <td><?php echo htmlspecialchars($pedido['id']); ?></td>
                                <td><?php echo htmlspecialchars($pedido['nombre_usuario']); ?></td>
                                <td><?php echo htmlspecialchars($pedido['metodo_pago']); ?></td>
                                <td><?php echo htmlspecialchars($pedido['direccion_producto']); ?></td>
                                <td><?php echo htmlspecialchars($pedido['total']); ?> </td>
                                <td><?php echo htmlspecialchars($pedido['fecha']); ?></td>
                                <td>
                                    <span class="<?php echo $pedido['estado'] === 'procesado' ? 'bg-green-200 text-green-800' : 'bg-yellow-200 text-yellow-800'; ?> py-1 px-3 rounded-full text-xs font-semibold">
                                        <?php echo htmlspecialchars(ucfirst($pedido['estado'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if (empty($pedido['nombre_repartidor'])): ?>
                                        <span class="text-yellow-600">En Espera</span>
                                    <?php else: ?>
                                        <?php echo htmlspecialchars($pedido['nombre_repartidor']); ?>
                                    <?php endif; ?>
                                </td>
                                <td class="acciones">
                                    <form action="ActualizarEstado" method="POST" style="display:inline;">
                                        <input type="hidden" name="pedido_id" value="<?php echo $pedido['id']; ?>">
                                        <input type="hidden" name="nuevo_estado" value="entregado">
                                        <button type="submit" class="text-green-500 hover:text-green-700 ml-4 text-sm">Marcar como Entregado</button>
                                    </form>
                                    <form action="Eliminar-Pedido" method="POST" style="display:inline;">
                                        <input type="hidden" name="pedido_id" value="<?php echo $pedido['id']; ?>">
                                        <button type="submit" class="text-red-500 hover:text-red-700 ml-4 text-sm">Cancelar Pedido</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
    <?php 
        if (isset($_SESSION['mensaje'])) {
         echo '<div class="alert ' . $_SESSION['mensaje']['tipo'] . '">' . $_SESSION['mensaje']['texto'] . '</div>';
            unset($_SESSION['mensaje']);
        }
    ?>  
