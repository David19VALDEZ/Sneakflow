<?php 
    $productoControlador = new ProductoControlador(); // Instanciar el controlador
    $data = $productoControlador->mostrarProductos(); // Llamar a la función para obtener los productos
    $marcas = $data['marcas'];
    $colores = $data['colores'];
    require_once '../public/vistas_admin/menu.php'; 
?>
<link rel="stylesheet" href="/SneakFlow/public/vistas_admin/css/crear_producto.css">

<style>
    .flex {
        display: <?php echo isset($mostrarPopup) && $mostrarPopup ? 'none' : 'flex'; ?>; /* Oculta el contenido principal si el popup está visible */
        justify-content: center; /* Centrar el contenido */
    }
</style>

<div class="flex items-center">
    <div class="content text-white shadow-lg bg-gray-900 p-6 mt-16 rounded-lg">
        <h2 id="titulo" class="text-3xl font-bold mb-6">Agregar Producto</h2>
        <form action="Crear-Producto" method="POST" enctype="multipart/form-data">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">

                <!-- Nombre del Producto -->
                <div class="form-group">
                    <label for="nombre" class="block text-sm font-medium">Nombre del Producto</label>
                    <input type="text" id="nombre" name="nombre" required class="block w-full p-2 bg-gray-600 border-2 border-green-500 text-white rounded focus:ring focus:ring-green-300">
                </div>

                <!-- Descripción -->
                <div class="form-group col-span-2 md:col-span-1"> <!-- Cambia a col-span-1 en pantallas medianas -->
                    <label for="descripcion" class="block text-sm font-medium">Descripción</label>
                    <textarea id="descripcion" name="descripcion" rows="1" required class="block w-full p-2 bg-gray-600 border-2 border-green-500 text-white rounded focus:ring focus:ring-green-300"></textarea>
                </div>

                <!-- Cantidad -->
                <div class="form-group">
                    <label for="cantidad" class="block text-sm font-medium">Cantidad</label>
                    <input type="number" id="cantidad" name="cantidad" required class="block w-full p-2 bg-gray-600 border-2 border-green-500 text-white rounded focus:ring focus:ring-green-300">
                </div>

                <!-- ID de Marca -->
                <div class="form-group">
                    <label for="marca" class="mr-2 block text-sm font-medium">Marcas:</label>
                    <select id="marca" name="marca" required class="block w-full p-2 bg-gray-600 border-2 border-green-500 text-white rounded focus:ring focus:ring-green-300">
                        <option value="">Marcas</option>
                        <?php foreach ($marcas as $marca): ?>
                            <option value="<?= htmlspecialchars($marca['id']); ?>" <?= isset($_GET['marca']) && $_GET['marca'] == $marca['id'] ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($marca['marca']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Género -->
                <div class="form-group">
                    <label for="genero" class="block text-sm font-medium">Género</label>
                    <select id="genero" name="genero" required class="block w-full p-2 bg-gray-600 border-2 border-green-500 text-white rounded focus:ring focus:ring-green-300">
                        <option value="">Selecciona Género</option>
                        <option value="Hombre">Hombre</option>
                        <option value="Mujer">Mujer</option>
                        <option value="Unisex">Unisex</option>
                    </select>
                </div>

                <!-- ID de Color -->
                <div class="form-group">
                    <label for="color" class="mr-2 block text-sm font-medium">Color:</label>
                    <select id="color" name="color" required class="block w-full p-2 bg-gray-600 border-2 border-green-500 text-white rounded focus:ring focus:ring-green-300">
                        <option value="">Selecciona un color</option>
                        <?php foreach ($colores as $color): ?>
                            <option value="<?= htmlspecialchars($color['id']); ?>" <?= isset($_GET['color']) && $_GET['color'] == $color['id'] ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($color['color']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Precio -->
                <div class="form-group">
                    <label for="precio" class="block text-sm font-medium">Precio</label>
                    <input type="number" step="0.01" id="precio" name="precio" required class="block w-full p-2 bg-gray-600 border-2 border-green-500 text-white rounded focus:ring focus:ring-green-300">
                </div>

                <!-- Descuento -->
                <div class="form-group">
                    <label for="descuento" class="block text-sm font-medium">Descuento (%)</label>
                    <select id="descuento" name="descuento" required class="block w-full p-2 bg-gray-600 border-2 border-green-500 text-white rounded focus:ring focus:ring-green-300">
                        <option value="">Seleccione un descuento</option>
                        <option value="0">No aplica</option>
                        <option value="5">5%</option>
                        <option value="10">10%</option>
                        <option value="15">15%</option>
                        <option value="20">20%</option>
                    </select>
                </div>

                <!-- Talla -->
                <div class="form-group">
                    <label for="talla" class="block text-sm font-medium">Talla</label>
                    <input type="text" id="talla" name="talla" required class="block w-full p-2 bg-gray-600 border-2 border-green-500 text-white rounded focus:ring focus:ring-green-300">
                </div>
                
                <!-- Promocion -->
                <div class="form-group">
                    <label for="promocion" class="block text-sm font-medium">Promoción 2x1</label>
                    <select id="promocion" name="promocion" required class="block w-full p-2 bg-gray-600 border-2 border-green-500 text-white rounded focus:ring focus:ring-green-300">
                        <option value="0">No</option>
                        <option value="1">Sí</option>
                    </select>
                </div>

                <!-- Subir Imágenes -->
                <div class="form-group">
                    <label for="imagen" class="block text-sm font-medium">Subir Imágenes</label>
                    <input type="file" id="imagen" name="imagenes[]" accept="image/*" multiple required class="block w-full p-2 bg-gray-600 border-2 border-green-500 text-white rounded focus:ring focus:ring-green-300">
                </div>

            </div>

            <!-- Botón Agregar Producto -->
            <button type="submit" class="mt-6 w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg shadow-md transition duration-300 ease-in-out focus:outline-none focus:ring focus:ring-green-300">
                Agregar Producto
            </button>
        </form>
    </div>
</div>
