<?php
// Se incluye el modelo de productos y el controlador
require_once __DIR__ . '/../../../app/modelos/ProductoModelo.php';
require_once __DIR__ . '/../../../app/controladores/ProductoControlador.php';

// Instancia el controlador de productos
$productoControlador = new ProductoControlador();
$productosData = []; // Array para productos

// Muestra los productos utilizando el método del controlador
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $productosData = $productoControlador->mostrarProductos();
    $producto = $productosData['productos']; // Asigna los productos
    $colores = $productosData['colores']; // Colores disponibles
}

require_once '../public/vistas_admin/menu.php'; 

include 'alertas/eliminar.php';

// Función para truncar el texto
function truncateText($text, $limit = 10) {
    $words = explode(' ', $text);
    if (count($words) > $limit) {
        return implode(' ', array_slice($words, 0, $limit)) . '...'; // Añadir "..." al final
    }
    return $text;
}
?>

<link rel="stylesheet" href="/SneakFlow/public/vistas_admin/css/ad_productos.css">

<style>
    .flex {
        display: <?php echo isset($mostrarPopup) && $mostrarPopup ? 'none' : 'flex'; ?>; /* Oculta el contenido principal si el popup está visible */
    }

</style>

<div class="flex justify bg-gray-600">
    <div class="content-container flex-1 p-5 bg-gray-900 mt-16"> 
        <h1 class="text-4xl font-bold mb-5 text-white text-center">Administrar Productos</h1>
        <div class="border-b-2 border-green-500 mb-5"></div>

        <div class="table-container p-2">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Precio</th>
                        <th>Imagen</th>
                        <th>Marca</th>
                        <th>Color</th>
                        <th>Género</th>
                        <th>Desc</th>
                        <th>Tallas</th>
                        <th>Exist</th>
                        <th>Prom</th> <!-- Nueva columna -->
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($producto)): ?>
                        <?php foreach ($producto as $prod): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($prod['id']); ?></td>
                                <td><?php echo htmlspecialchars($prod['nombre']); ?></td>
                                <td class='cursor-pointer' onclick="openDescriptionModal('<?php echo htmlspecialchars($prod['descripcion']); ?>')">
                                    <?php echo htmlspecialchars(truncateText($prod['descripcion'], 10)); // Muestra solo 10 palabras ?>
                                </td>
                                <td>$<?php echo htmlspecialchars($prod['precio']); ?></td>
                                <td><img src='/SneakFlow/public/vistas/img/<?php echo htmlspecialchars($prod['imagen']); ?>' alt='<?php echo htmlspecialchars($prod['nombre']); ?>' class='w-20 h-20 object-cover'></td>
                                <td><?php echo htmlspecialchars($prod['marca']); ?></td>
                                <td><?php echo htmlspecialchars($prod['color']); ?></td>
                                <td><?php echo htmlspecialchars($prod['genero']); ?></td>
                                <td><?php echo htmlspecialchars($prod['descuento']); ?>%</td>
                                <td>
                                    <?php 
                                    // Verificamos si hay tallas disponibles
                                    if (isset($prod['tallas_assoc']) && !empty($prod['tallas_assoc'])): 
                                        // Obtenemos las tallas como un array de nombres
                                        $tallasArray = array_map(function($tallaData) {
                                            return htmlspecialchars($tallaData['nombre']);
                                        }, $prod['tallas_assoc']);
                                        
                                        // Unimos las tallas en una cadena separada por comas
                                        echo implode(', ', $tallasArray);
                                    else: 
                                        echo 'No hay tallas disponibles'; // Mensaje alternativo si no hay tallas
                                    endif; 
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($prod['existencias']); ?></td>
                                <td>
                                    <?php 
                                    // Verifica el valor de descuento para mostrar el texto correspondiente
                                    if ($prod['promocion'] == 1) {
                                        echo "2x1";
                                    } else {
                                        echo "No aplica";
                                    }
                                    ?>
                                </td>
                                <td>
                                    <div class='flex flex-col space-y-1'>
                                        <!-- Botón Editar Producto -->
                                        <button onclick="openEditModal(<?php echo $prod['id']; ?>)" class="action-btn edit-btn">
                                            Editar
                                        </button>

                                        <!-- Botón Editar Tallas -->
                                        <button onclick="openEditSizeModal(<?php echo $prod['id']; ?>)" class="action-btn size-edit-btn">
                                            Editar-T
                                        </button>

                                        <!-- Botón Agregar Talla -->
                                        <button onclick="openAddSizeModal(<?php echo $prod['id']; ?>)" class="action-btn add-size-btn">
                                            Agregar
                                        </button>

                                        <!-- Botón Eliminar Producto -->
                                        <form action='eliminar-Producto' method='post' class='inline-block'>
                                            <input type='hidden' name='producto_id' value='<?php echo htmlspecialchars($prod['id']); ?>'>
                                            <button type="button" class="action-btn delete-btn" onclick="confirmDelete(this)">
                                                Eliminar
                                            </button>
                                        </form>

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan='13' class='text-center'>No hay productos disponibles.</td> <!-- Ajustar el colspan -->
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal de descripción completa -->
<?php include 'modales/description.php'; ?>

<!-- Modal para editar un producto -->
<?php include 'modales/editar.php'; ?>

<?php include 'modales/agregar-talla.php'; ?>

<!-- Modal para editar un producto -->
<?php include 'modales/editar-tallas.php'; ?>

<script src="/SneakFlow/public/vistas_admin/js/ad_producto.js"></script>
