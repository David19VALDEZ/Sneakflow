
<?php foreach ($producto as $prod): ?>
    <div id="addSizeModal_<?php echo $prod['id']; ?>" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close" onclick="closeModal('addSizeModal_<?php echo $prod['id']; ?>')">&times;</span>
            <h2>Agregar Talla</h2>
            <form id="addSizeForm" action="NuevaTalla" method="POST">
                <input type="hidden" name="producto_id" value='<?php echo htmlspecialchars($prod['id']); ?>'> <!-- Asegúrate de establecer el producto_id -->

                <div>
                    <label for="talla">Talla:</label>
                    <input type="text" id="talla" name="talla" required>
                </div>

                <div>
                    <label for="cantidad">Cantidad:</label>
                    <input type="number" id="cantidad" name="cantidad" min="0" required>
                </div>

                <button type="submit">Agregar Talla</button>
            </form>
        </div>
    </div>
<?php endforeach; ?>
