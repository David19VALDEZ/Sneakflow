<?php foreach ($producto as $prod): ?>
    <!-- Modal de Edición de Producto -->
    <div id="editModal_<?php echo $prod['id']; ?>" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal(<?php echo $prod['id']; ?>)">&times;</span>
            <h2>Editar Producto: <?php echo htmlspecialchars($prod['nombre']); ?></h2>
            <form id="editForm_<?php echo $prod['id']; ?>" action="Editar-Producto" method="POST">
                <input type="hidden" name="id" value="<?php echo $prod['id']; ?>">
                <div class="form-flex">
                    <!-- Nombre del producto -->
                    <div>
                        <label for="nombre">Nombre:</label>
                        <input type="text" name="nombre" value="<?php echo htmlspecialchars($prod['nombre']); ?>" >
                    </div>

                    <!-- Descripción -->
                    <div>
                        <label for="descripcion">Descripción:</label>
                        <textarea name="descripcion"><?php echo htmlspecialchars($prod['descripcion']); ?></textarea>
                    </div>

                    <!-- Imagen -->
                    <div class="file-upload">
                        <label for="imagen">Imagen:</label>
                        <input type="text" id="imagen" name="imagen" value="<?php echo htmlspecialchars($prod['imagen']); ?>" >
                    </div>

                    <!-- Marca -->
                    <div>
                        <label for="marca_id">Marca:</label>
                        <select name="marca_id" id="marca_id">
                            <option value="">Selecciona una marca</option>
                            <?php foreach ($marcas as $marca): ?>
                                <option value="<?php echo htmlspecialchars($marca['id']); ?>"
                                    <?php if (isset($prod['marca']) && (int)$prod['marca'] === (int)$marca['id']) echo 'selected'; ?>>
                                    <?php echo htmlspecialchars($marca['marca']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Color -->
                    <div>
                        <label for="color_id">Color:</label>
                        <select name="color_id" id="color_id">
                            <option value="">Selecciona un color</option>
                            <?php foreach ($colores as $color): ?>
                                <option value="<?php echo htmlspecialchars($color['id']); ?>"
                                    <?php if (isset($prod['color']) && (int)$prod['color'] === (int)$color['id']) echo 'selected'; ?>>
                                    <?php echo htmlspecialchars($color['color']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Género -->
                    <div>
                        <label for="genero">Género:</label>
                        <select name="genero">
                            <option value="<?php echo htmlspecialchars($prod['genero']); ?>"><?php echo htmlspecialchars($prod['genero']); ?></option>
                            <option value="hombre">Hombre</option>
                            <option value="mujer">Mujer</option>
                            <option value="unisex">Unisex</option>
                        </select>
                    </div>

                    <!-- Precio -->
                    <div>
                        <label for="precio">Precio:</label>
                        <input type="number" name="precio" value="<?php echo htmlspecialchars($prod['precio']); ?>" step="0.01" >
                    </div>

                    <!-- Descuento -->
                    <div>
                        <label for="descuento">Descuento:</label>
                        <input type="number" name="descuento" value="<?php echo htmlspecialchars($prod['descuento']); ?>">
                    </div>

                    <!-- Promoción -->
                    <div>
                        <label for="promocion">Promoción:</label>
                        <select name="promocion" id="promocion">
                            <option value="0" <?php echo isset($prod['promocion']) && $prod['promocion'] == 0 ? 'selected' : ''; ?>>No aplica</option>
                            <option value="1" <?php echo isset($prod['promocion']) && $prod['promocion'] == 1 ? 'selected' : ''; ?>>2x1</option>
                        </select>
                    </div>


                    <!-- Sección de Cantidades -->
                    <div>
                        <label for="tallaSelect_<?php echo $prod['id']; ?>">Selecciona una talla:</label>
                        <select id="tallaSelect_<?php echo $prod['id']; ?>" name="tallas[]" onchange="mostrarCantidad(<?php echo $prod['id']; ?>)">
                            <option value="">Selecciona una talla</option>
                            <?php if (isset($prod['tallas_assoc']) && !empty($prod['tallas_assoc'])): ?>
                                <?php foreach ($prod['tallas_assoc'] as $tallaId => $tallaData): ?>
                                    <option value="<?php echo $tallaId; ?>"><?php echo htmlspecialchars($tallaData['nombre']); ?></option>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <option disabled>No hay tallas disponibles</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <!-- Cantidades por talla (ocultas inicialmente) -->
                    <div id="cantidadContainer_<?php echo $prod['id']; ?>">
                        <?php if (isset($prod['tallas_assoc']) && !empty($prod['tallas_assoc'])): ?>
                            <?php foreach ($prod['tallas_assoc'] as $tallaId => $tallaData): ?>
                                <div class="cantidad-item" id="cantidad_<?php echo $tallaId; ?>_<?php echo $prod['id']; ?>" style="display: none;">
                                    <label for="cantidadInput_<?php echo $tallaId; ?>">Cantidad para talla <?php echo htmlspecialchars($tallaData['nombre']); ?>:</label>
                                    <input type="number" id="cantidadInput_<?php echo $tallaId; ?>" name="cantidades[<?php echo $tallaId; ?>]" value="<?php echo htmlspecialchars($tallaData['cantidad']); ?>" min="0">
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>No hay cantidades disponibles para este producto.</p>
                        <?php endif; ?>
                    </div>
                    <button type="submit">Guardar Cambios</button>
                </div>
            </form>
        </div>
    </div>
<?php endforeach; ?>


<script>
function mostrarCantidad(productId) {
    // Ocultar todas las cantidades inicialmente
    document.querySelectorAll('.cantidad-item').forEach(function(el) {
        el.style.display = 'none';
    });

    // Obtener la talla seleccionada
    var tallaSelect = document.getElementById('tallaSelect_' + productId);
    var tallaId = tallaSelect.value;

    // Mostrar el campo de cantidad correspondiente a la talla seleccionada
    if (tallaId) {
        var cantidadDiv = document.getElementById('cantidad_' + tallaId + '_' + productId);
        if (cantidadDiv) {
            cantidadDiv.style.display = 'block';
        }
    }
}
</script>
