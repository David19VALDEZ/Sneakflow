<?php foreach ($producto as $prod): ?>
    <div id="editSizeModal_<?php echo $prod['id']; ?>" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close" onclick="closeModal('editSizeModal_<?php echo $prod['id']; ?>')">&times;</span>
            <h2>Editar Talla</h2>

            <form id="editSizeForm_<?php echo $prod['id']; ?>" action="editarTalla" method="POST">
                <input type="hidden" name="producto_id" value="<?php echo htmlspecialchars($prod['id']); ?>">

                <div class="tallas-container">
                    <?php if (isset($prod['tallas_assoc']) && !empty($prod['tallas_assoc'])): ?>
                        <?php 
                        $count = 0; // Contador para las filas
                        foreach ($prod['tallas_assoc'] as $tallaId => $tallaData): 
                            if ($count % 4 === 0): // Abre un nuevo contenedor cada 4 tallas
                        ?>
                            <div class="row">
                        <?php endif; ?>
                                <div class="talla-cantidad-item mb-2" style="margin-right: 10px; width: 23%;">
                                    <label>
                                        Talla:
                                        <input type="text" id="talla_<?php echo $tallaId; ?>" name="tallas[<?php echo $tallaId; ?>]" 
                                            value="<?php echo htmlspecialchars($tallaData['nombre']); ?>" class="border rounded px-2 mx-1 w-24" required>
                                    </label>
                                    <label>
                                        Cantidad:
                                        <input type="number" name="cantidades[<?php echo $tallaId; ?>]" 
                                            value="<?php echo htmlspecialchars($tallaData['cantidad']); ?>" min="0" class="border rounded px-2 mx-1 w-24" required>
                                    </label>
                                </div>
                        <?php 
                            $count++;
                            if ($count % 4 === 0 || $count === count($prod['tallas_assoc'])): // Cierra el contenedor si se llegó a 4 o al final
                        ?>
                            </div>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No hay tallas disponibles para este producto.</p>
                    <?php endif; ?>
                </div>

                <button type="submit">Actualizar Tallas</button>
            </form>
        </div>
    </div>
<?php endforeach; ?>
