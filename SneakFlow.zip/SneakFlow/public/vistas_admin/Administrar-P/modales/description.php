<style>
    /* Estilo del modal */
    .modales {
        display: none; 
        position: fixed; 
        z-index: 1; 
        left: 0;
        top: 0;
        width: 100%; 
        height: 100%; 
        overflow: auto; 
        background-color: rgba(0, 0, 0, 0.7); /* Fondo más oscuro */
        padding-top: 60px; 
    }

    .modales-content {
        background-color: #ffffff; /* Fondo blanco para el contenido */
        margin: 10% auto; 
        padding: 20px;
        border-radius: 8px; /* Bordes redondeados */
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3); /* Sombra suave */
        width: 80%; 
    }

    .close {
        color: #e63946; /* Color rojo para el botón de cerrar */
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: #d62839; /* Color un poco más oscuro al pasar el mouse */
        text-decoration: none;
        cursor: pointer;
    }

</style>
<div id="descriptionModal" class="modales fixed z-50 inset-0 overflow-auto bg-black bg-opacity-70 flex items-center justify-center">
    <div class="modal-content bg-white rounded-lg shadow-lg p-6 w-11/12 md:w-2/3 lg:w-1/2">
        <span class="close text-red-600 float-right text-2xl font-bold cursor-pointer" onclick="closeDescriptionModal()">&times;</span>
        <h2 class="text-xl font-semibold   mb-4">Descripción Completa</h2>
        <p id="fullDescription" class="text-white"></p>
    </div>
</div>