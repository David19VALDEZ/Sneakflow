<?php 
    require_once '../public/vistas_admin/menu.php'; 
?>

<link rel="stylesheet" href="/SneakFlow/public/vistas_admin/css/ad_usuario.css">

<style>

    .flex {
        display: <?php echo isset($mostrarPopup) && $mostrarPopup ? 'none' : 'flex'; ?>; /* Oculta el contenido principal si el popup está visible */
    }
</style>
<div class="flex justify-center items-center  min-h-screen " >
    <div class="flex-1 bg-gray-900 rounded-lg shadow-lg w-full max-w-10xl mx-auto content"> <!-- Agregando margen superior -->
        <!-- Título -->
        <h1 class="text-white text-3xl mb-3 text-center ">Lista de Usuarios</h1>
        <hr class="border-t-4 border-green-500 mb-6">

        <!-- Tabla -->
        <table class="table-auto w-full bg-gray-800 rounded-lg overflow-hidden shadow-lg border-separate border-spacing-0 m">
            <thead>
                <tr class="bg-gray-700 text-left text-white">
                    <th class="p-4 border-b border-gray-600 text-white">ID</th>
                    <th class="p-4 border-b border-gray-600 text-white">Usuario</th>
                    <th class="p-4 border-b border-gray-600 text-white">Correo</th>
                    <th class="p-4 border-b border-gray-600 text-white">Tipo de documento</th>
                    <th class="p-4 border-b border-gray-600 text-white">Numero de documento</th>
                    <th class="p-4 border-b border-gray-600 text-white">Teléfono</th>
                    <th class="p-4 border-b border-gray-600 text-white">Dirección</th>
                    <th class="p-4 border-b border-gray-600 text-white">Rol</th>
                    <th class="p-4 border-b border-gray-600 text-white">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($datos['usuarios'] as $usuario): ?>
                    <tr class="hover:bg-gray-700 transition duration-200">
                        <td class="p-4 border-b border-gray-600 text-white"><?php echo $usuario['id']; ?></td>
                        <td class="p-4 border-b border-gray-600 text-white"><?php echo $usuario['usuario']; ?></td>
                        <td class="p-4 border-b border-gray-600 text-white"><?php echo $usuario['correo']; ?></td>
                        <td class="p-4 border-b border-gray-600 text-white"><?php echo $usuario['tipo_documento']; ?></td>
                        <td class="p-4 border-b border-gray-600 text-white"><?php echo $usuario['numero_documento']; ?></td>
                        <td class="p-4 border-b border-gray-600 text-white"><?php echo $usuario['telefono']; ?></td>
                        <td class="p-4 border-b border-gray-600 text-white"><?php echo $usuario['direccion']; ?></td>
                        <td class="p-4 border-b border-gray-600 text-white"><?php echo $usuario['rol']; ?></td>
                        <td class="p-4 border-b border-gray-600 text-white">
                            <a href="#" class="text-green-500 hover:text-green-700 ml-5 edit-user" data-id="<?php echo $usuario['id']; ?>" onclick="openEditModal(<?php echo $usuario['id']; ?>)">Editar</a>
                            <form action="Eliminar-Usuario" method="POST" style="display:inline;">
                                <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">
                                <button type="submit" class="text-red-500 hover:text-red-700 ml-4" onclick="return confirm('¿Estás seguro de que deseas eliminar este usuario?');">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

    <?php include 'editar-usuario.php'; ?>
    <script src="/SneakFlow/public/vistas_admin/js/ad_usuario.js"></script>
