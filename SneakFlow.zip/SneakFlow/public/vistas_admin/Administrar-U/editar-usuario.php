<?php foreach ($datos['usuarios'] as $usuario): ?>
    <div id="editUsuario_<?php echo $usuario['id']; ?>" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal(<?php echo $usuario['id']; ?>)">&times;</span>
            <h2>Editar Usuario: <?php echo htmlspecialchars($usuario['usuario'] ?? ''); ?></h2>
            <form id="editForm_<?php echo $usuario['id']; ?>" action="Editar-Usuarios" method="POST">
                <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">

                <div class="form-flex">
                    <div>
                        <label for="usuario_<?php echo $usuario['id']; ?>">Usuario:</label>
                        <input type="text" id="usuario_<?php echo $usuario['id']; ?>" name="usuario" value="<?php echo htmlspecialchars($usuario['usuario'] ?? ''); ?>" >
                    </div>

                    <div>
                        <label for="correo_<?php echo $usuario['id']; ?>">Correo:</label>
                        <input type="email" id="correo_<?php echo $usuario['id']; ?>" name="correo" value="<?php echo htmlspecialchars($usuario['correo'] ?? ''); ?>" >
                    </div>

                    <div>
                        <label for="tipo_documento_<?php echo $usuario['id']; ?>">Tipo de documento:</label>
                        <input type="text" id="tipo_documento_<?php echo $usuario['id']; ?>" name="tipo_documento" value="<?php echo htmlspecialchars($usuario['tipo_documento'] ?? ''); ?>" >
                    </div>
                    
                    <div>
                        <label for="numero_documento_<?php echo $usuario['id']; ?>">Número de documento:</label>
                        <input type="text" id="numero_documento_<?php echo $usuario['id']; ?>" name="numero_documento" value="<?php echo htmlspecialchars($usuario['numero_documento'] ?? ''); ?>">
                    </div>

                    <div>
                        <label for="telefono_<?php echo $usuario['id']; ?>">Teléfono:</label>
                        <input type="text" id="telefono_<?php echo $usuario['id']; ?>" name="telefono" value="<?php echo htmlspecialchars($usuario['telefono'] ?? ''); ?>" >
                    </div>

                    <div>
                        <label for="direccion_<?php echo $usuario['id']; ?>">Dirección:</label>
                        <input type="text" id="direccion_<?php echo $usuario['id']; ?>" name="direccion" value="<?php echo htmlspecialchars($usuario['direccion'] ?? ''); ?>" >
                    </div>
                </div>

                <div class="flex justify-center">
                    <button type="submit" name="guardar" class="bg-blue-600 text-white font-bold py-2 px-4 rounded w-full hover:bg-blue-500 transition duration-300 ease-in-out transform hover:scale-105">
                        Guardar
                    </button>
                </div>

            </form>
        </div>
    </div>
<?php endforeach; ?>
