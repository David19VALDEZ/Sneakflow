<?php require_once '../public/vistas/header.php'; ?>
<link rel="stylesheet" href="/SneakFlow/public/vistas/css/product_marca.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<div class="container mx-auto mt-20"> <!-- Contenedor principal -->
    <h1 class="text-4xl font-bold mb-2 text-center shadow-title"><?php echo htmlspecialchars($producto_marca['marca']); ?></h1> <!-- Título con el nombre de la marca -->
    <p class="mb-4 ml-6 text-description"><?php echo htmlspecialchars($producto_marca['descripcion']); ?></p> <!-- Descripción de la marca -->

    <div class="flex items-start"> <!-- Contenedor flexible para los filtros y productos -->
        <div class="filtros w-full  p-4 rounded-lg shadow-lg ml-4"> <!-- Contenedor para los filtros -->
            <?php include 'filtro_marca.php'; ?>
        </div>
        <div class="productos flex-grow p-4"> <!-- Sección de productos -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php if (!empty($productos)): ?>
                    <?php foreach ($productos as $producto): ?>
                        <div class="producto w-full rounded-lg p-4 h-auto relative"> <!-- Contenedor del producto -->
                            <div class="relative"> <!-- Contenedor relativo para la imagen y etiqueta -->
                                <img src="/SneakFlow/public/vistas/img/<?php echo htmlspecialchars($producto['imagen']); ?>" 
                                    alt="<?php echo htmlspecialchars($producto['nombre']); ?>" 
                                    class="w-full h-auto object-cover rounded-md"> <!-- Asegúrate de que la imagen ocupe el ancho total -->
                                
                                <!-- Etiqueta de descuento -->
                                <?php if (!empty($producto['descuento']) && $producto['descuento'] > 0): ?>
                                    <?php 
                                        $precioOriginal = $producto['precio'];
                                        $precioConDescuento = $precioOriginal - ($precioOriginal * $producto['descuento'] / 100);
                                    ?>
                                    <span class="discount-tag absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded">-<?php echo $producto['descuento']; ?>%</span>
                                <?php endif; ?>
                            </div>

                            <h3 class="text-lg font-semibold"><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                            <p>
                                <?php
                                // Dividir la descripción en palabras
                                $palabras = explode(' ', htmlspecialchars($producto['descripcion']));
                                
                                // Obtener solo las primeras 11 palabras
                                $primerasPalabras = array_slice($palabras, 0, 11);
                                
                                // Unir las palabras en una cadena
                                $descripcionCorta = implode(' ', $primerasPalabras);
                                
                                // Mostrar la descripción corta
                                echo $descripcionCorta . (count($palabras) > 11 ? '...' : '');
                                ?>
                            </p>

                            <p class="font-bold">
                                <?php
                                if ($producto['descuento'] > 0) {
                                    echo "<span class='line-through text-red-500 mr-4'>$$precioOriginal</span>"; // Precio original tachado
                                    echo "<span class='text-black'>$$precioConDescuento.00</span>"; // Precio con descuento
                                } else {
                                    echo "$$precioOriginal"; // Precio sin descuento
                                }
                                ?>
                            </p>

                            <!-- Menú desplegable para tallas -->
                            <div class="detalles mt-4 bg-white shadow-lg rounded-lg p-4 transition-transform duration-300 detalles-expandible" style="display:none;">
                                <form class="agregar-carrito" data-producto-id="<?php echo htmlspecialchars($producto['id']); ?>">
                                    <input type="hidden" name="producto_id" value="<?php echo htmlspecialchars($producto['id']); ?>">
                                    <select name="talla_id" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300">
                                        <option value="" disabled selected>Selecciona una talla:</option>
                                        <?php if (!empty($producto['tallaproducto'])): ?>
                                            <?php foreach ($producto['tallaproducto'] as $talla): ?>
                                                <option value="<?= htmlspecialchars($talla['id']); ?>"><?= htmlspecialchars($talla['talla']); ?></option>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <option value="">No hay tallas disponibles</option>
                                        <?php endif; ?>
                                    </select>
                                    <input type="hidden" name="cantidad" value="1"> <!-- Cantidad fija en 1 -->
                                    <button type="submit" class="w-full bg-blue-600 text-white font-semibold px-4 py-2 rounded-lg hover:bg-blue-500 transition duration-300 transform hover:scale-105 mt-3">
                                        Agregar al carrito
                                    </button>
                                    <div class="respuesta" style="display:none;"></div>
                                </form>                                
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No hay productos disponibles para esta marca.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>

    document.querySelectorAll('.agregar-carrito').forEach(form => {
        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Prevenir el envío normal del formulario

            const formData = new FormData(this); // Obtener datos del formulario
            const productoId = this.getAttribute('data-producto-id'); // Obtener el ID del producto

            fetch('agregar-al-carrito', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // Mostrar el mensaje por unos segundos
                const respuestaDiv = this.querySelector('.respuesta');
                if (respuestaDiv) {
                    respuestaDiv.style.display = 'block'; // Mostrar el área de respuesta
                    respuestaDiv.innerHTML = `<div class='p-2 ${data.status === 'success' ? 'bg-green-200 text-green-800 border-green-400' : 'bg-red-200 text-red-800 border-red-400'} rounded'>${data.message}</div>`;
                    setTimeout(() => {
                        respuestaDiv.style.display = 'none'; // Ocultar el área de respuesta después de 3 segundos
                    }, 3000);
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });
</script>
<script src="/SneakFlow/public/vistas/js/producto_marca.js"></script> <!-- Script de productos marcas -->

<?php require_once '../public/vistas/footer.php'; ?>
