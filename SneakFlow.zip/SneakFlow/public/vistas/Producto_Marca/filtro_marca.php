 <form action="marca" method="GET"> <!-- Agregar el formulario aquí -->
    
    <input type="hidden" name="id" value="<?php echo htmlspecialchars($id_marca); ?>"> <!-- Campo oculto para el ID de la marca -->

    <!-- Filtro de Género -->
    <div class="filtro border border-gray-300 p-4 rounded-lg mb-4">
        <h3 class="font-semibold mb-2">Género</h3>
        <hr class="mb-2">
        <div class="max-h-32 overflow-y-auto">
            <ul>
                <li class="flex items-center mb-2">
                    <input type="checkbox" name="genero[]" value="Hombre" id="genero_hombre" class="h-5 w-5 text-blue-600 border-gray-300 rounded mr-2">
                    <label for="genero_hombre" class="text-gray-700">Hombre</label>
                </li>
                <li class="flex items-center mb-2">
                    <input type="checkbox" name="genero[]" value="Mujer" id="genero_mujer" class="h-5 w-5 text-blue-600 border-gray-300 rounded mr-2">
                    <label for="genero_mujer" class="text-gray-700">Mujer</label>
                </li>
                <li class="flex items-center mb-2">
                    <input type="checkbox" name="genero[]" value="Unisex" id="genero_unisex" class="h-5 w-5 text-blue-600 border-gray-300 rounded mr-2">
                    <label for="genero_unisex" class="text-gray-700">Unisex</label>
                </li>
            </ul>
        </div>
        <button type="submit" class="mt-4 w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-500 transition duration-300">Aplicar</button>
    </div>

    <!-- Filtro de Talla -->
    <div class="filtro border border-gray-300 p-4 rounded-lg mb-4">
        <h3 class="font-semibold mb-2">Talla</h3>
        <hr class="mb-2">
        <div class="max-h-32 overflow-y-auto">
            <?php
                // $tallas es un array asociativo con los valores de las tallas.
                usort($tallas, function($a, $b) {
                    return $a['talla'] - $b['talla'];
                });
            ?>
            <ul>
                <?php foreach ($tallas as $talla): ?>
                    <li class="flex items-center mb-2">
                        <input type="checkbox" name="talla[]" value="<?php echo htmlspecialchars($talla['talla']); ?>" id="talla_<?php echo htmlspecialchars($talla['talla']); ?>" class="h-5 w-5 text-blue-600 border-gray-300 rounded mr-2">
                        <label for="talla_<?php echo htmlspecialchars($talla['talla']); ?>" class="text-gray-700"><?php echo htmlspecialchars($talla['talla']); ?></label>
                    </li>
                <?php endforeach; ?>
            </ul>

        </div>
        <button type="submit" class="mt-4 w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-500 transition duration-300">Aplicar</button>
    </div>

    <!-- Filtro de Color -->
    <div class="filtro border border-gray-300 p-4 rounded-lg mb-4">
        <h3 class="font-semibold mb-2">Color</h3>
        <hr class="mb-2">
        <div class="max-h-32 overflow-y-auto">
            <ul>
                <?php if (!empty($colores)): ?>
                    <?php foreach ($colores as $color): ?>
                        <li class="flex items-center mb-2">
                            <input type="checkbox" name="color[]" value="<?php echo htmlspecialchars($color['color']); ?>" id="color_<?php echo htmlspecialchars($color['color']); ?>" class="h-5 w-5 text-blue-600 border-gray-300 rounded mr-2">
                            <label for="color_<?php echo htmlspecialchars($color['color']); ?>" class="text-gray-700"><?php echo htmlspecialchars($color['color']); ?></label>
                        </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <li class="text-gray-500">No hay colores disponibles.</li>
                <?php endif; ?>
            </ul>
        </div>
        <button type="submit" class="mt-4 w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-500 transition duration-300">Aplicar</button>
    </div>

    <!-- Filtro de Descuento -->
    <div class="filtro border border-gray-300 p-4 rounded-lg mb-4">
        <h3 class="font-semibold mb-2">Descuento</h3>
        <hr class="mb-2">
        <div class="max-h-32 overflow-y-auto">
            <ul>
                <li class="flex items-center mb-2">
                    <input type="checkbox" name="descuento[]" value="5" id="descuento_5" class="h-5 w-5 text-blue-600 border-gray-300 rounded mr-2">
                    <label for="descuento_5" class="text-gray-700">5%</label>
                </li>
                <li class="flex items-center mb-2">
                    <input type="checkbox" name="descuento[]" value="10" id="descuento_10" class="h-5 w-5 text-blue-600 border-gray-300 rounded mr-2">
                    <label for="descuento_10" class="text-gray-700">10%</label>
                </li>
                <li class="flex items-center mb-2">
                    <input type="checkbox" name="descuento[]" value="15" id="descuento_15" class="h-5 w-5 text-blue-600 border-gray-300 rounded mr-2">
                    <label for="descuento_15" class="text-gray-700">15%</label>
                </li>
                <li class="flex items-center mb-2">
                    <input type="checkbox" name="descuento[]" value="20" id="descuento_20" class="h-5 w-5 text-blue-600 border-gray-300 rounded mr-2">
                    <label for="descuento_20" class="text-gray-700">20%</label>
                </li>
            </ul>
        </div>
        <button type="submit" class="mt-4 w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-500 transition duration-300">Aplicar</button>
    </div>

    <!-- Filtro de Precio -->
    <div class="filtro border border-gray-300 p-4 rounded-lg mb-4">
        <h3 class="font-semibold mb-2">Precio</h3>
        <hr class="mb-2">
        <div class="max-h-32 overflow-y-auto">
            <label for="precio_min" class="block text-gray-700">Mínimo: <span id="min_value" class="font-semibold">50,000</span></label>
            <input type="range" id="precio_min" name="precio_min" class="mb-2 w-full" min="50000" max="500000" step="1000" value="50000" oninput="updateMinValue(this.value)">
            
            <label for="precio_max" class="block text-gray-700">Máximo: <span id="max_value" class="font-semibold">500,000</span></label>
            <input type="range" id="precio_max" name="precio_max" class="w-full" min="50000" max="500000" step="1000" value="500000" oninput="updateMaxValue(this.value)">
        </div>
        <button type="submit" class="mt-4 w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-500 transition duration-300">Aplicar</button>
    </div>
</form> <!-- Cierre del formulario -->