        <footer>
            <script src="/SneakFlow/public/vistas/js/general.js"></script>
        </footer>
    </body>
</html>
