
<script src="https://cdn.tailwindcss.com"></script>

<body class="bg-gray-100 p-6 font-sans leading-normal tracking-normal">
    <form id="filter-form" method="GET" action="productos" class="bg-white p-6 rounded-lg shadow-md">
        <div class="flex flex-wrap items-start gap-4">
            <!-- Contenedor de Filtros -->
            <div class="flex flex-wrap gap-4 flex-grow">
                <!-- Filtro de Marca -->
                <div class="relative flex-grow filter-item">
                    <button type="button" class="filter-btn bg-gray-200 text-gray-700 font-semibold py-2 px-4 rounded-md hover:bg-gray-300 transition-all w-full text-left" onclick="toggleFilter(this)">
                        Marca
                    </button>
                    <div class="filter-content bg-white border border-gray-300 rounded-lg p-4 shadow-lg mt-2">
                        <ul class="space-y-2">
                            <?php foreach ($marcas as $marca): ?>
                                <li>
                                    <label>
                                        <input type="checkbox" name="marca[]" value="<?php echo htmlspecialchars($marca['marca']); ?>" class="mr-2">
                                        <?php echo htmlspecialchars($marca['marca']); ?>
                                    </label>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>

                <!-- Filtro de Género -->
                <div class="relative flex-grow filter-item">
                    <button type="button" class="filter-btn bg-gray-200 text-gray-700 font-semibold py-2 px-4 rounded-md hover:bg-gray-300 transition-all w-full text-left" onclick="toggleFilter(this)">
                        Género
                    </button>
                    <div class="filter-content bg-white border border-gray-300 rounded-lg p-4 shadow-lg mt-2">
                        <ul class="space-y-2">
                            <li><label><input type="checkbox" name="genero[]" value="Hombre" class="mr-2">Hombre</label></li>
                            <li><label><input type="checkbox" name="genero[]" value="Mujer" class="mr-2">Mujer</label></li>
                            <li><label><input type="checkbox" name="genero[]" value="Unisex" class="mr-2">Unisex</label></li>
                        </ul>
                    </div>
                </div>

                 <!-- Filtro de Talla -->
                 <div class="relative flex-grow filter-item">
                    <button type="button" class="filter-btn bg-gray-200 text-gray-700 font-semibold py-2 px-4 rounded-md hover:bg-gray-300 transition-all w-full text-left" onclick="toggleFilter(this)">
                        Talla
                    </button>
                    <div class="filter-content bg-white border border-gray-300 rounded-lg p-4 shadow-lg mt-2">
                        <?php
                            // Ordenamos el array $tallas de menor a mayor
                            usort($tallas, function($a, $b) {
                                return $a['talla'] - $b['talla'];
                            });
                        ?>  

                        <table id="tallas-table" class="w-full">
                            <?php
                            $num_columns = 4; // Número de columnas deseadas en la tabla
                            $column_count = 0;

                            foreach ($tallas as $talla) {
                                if ($column_count % $num_columns == 0) {
                                    if ($column_count > 0) {
                                        echo '</tr>';
                                    }
                                    echo '<tr class="table-row">';
                                }

                                echo '<td class="py-2 px-3">';
                                echo '<input type="checkbox" name="talla[]" value="' . htmlspecialchars($talla['talla']) . '" class="tallas-checkbox">';
                                echo htmlspecialchars($talla['talla']);
                                echo '</td>';

                                $column_count++;
                            }

                            // Cierra la última fila si no está completa
                            if ($column_count % $num_columns != 0) {
                                while ($column_count % $num_columns != 0) {
                                    echo '<td class="py-2 px-3"></td>';
                                    $column_count++;
                                }
                                echo '</tr>';
                            }
                            ?>
                        </table>
                    </div>
                </div>

                <!-- Filtro de Color -->
                <div class="relative flex-grow filter-item">
                    <button type="button" class="filter-btn bg-gray-200 text-gray-700 font-semibold py-2 px-4 rounded-md hover:bg-gray-300 transition-all w-full text-left" onclick="toggleFilter(this)">
                        Color
                    </button>
                    <div class="filter-content bg-white border border-gray-300 rounded-lg p-4 shadow-lg mt-2">
                        <ul class="space-y-2">
                            <?php if (!empty($colores)): ?>
                                <?php foreach ($colores as $color): ?>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="color[]" value="<?php echo htmlspecialchars($color['color']); ?>" class="mr-2">
                                            <?php echo htmlspecialchars($color['color']); ?>
                                        </label>
                                    </li>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <li>No hay colores disponibles.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

                <!-- Filtro de Descuento -->
                <div class="relative flex-grow filter-item">
                    <button type="button" class="filter-btn bg-gray-200 text-gray-700 font-semibold py-2 px-4 rounded-md hover:bg-gray-300 transition-all w-full text-left" onclick="toggleFilter(this)">
                        Descuento
                    </button>
                    <div class="filter-content bg-white border border-gray-300 rounded-lg p-4 shadow-lg mt-2">
                        <ul class="space-y-2">
                            <li><label><input type="checkbox" name="descuento[]" value="5" class="mr-2">5%</label></li>
                            <li><label><input type="checkbox" name="descuento[]" value="10" class="mr-2">10%</label></li>
                            <li><label><input type="checkbox" name="descuento[]" value="15" class="mr-2">15%</label></li>
                            <li><label><input type="checkbox" name="descuento[]" value="20" class="mr-2">20%</label></li>
                        </ul>
                    </div>
                </div>

                <!-- Filtro de Precio -->
                <div class="relative flex-grow filter-item">
                    <button type="button" class="filter-btn bg-gray-200 text-gray-700 font-semibold py-2 px-4 rounded-md hover:bg-gray-300 transition-all w-full text-left" onclick="toggleFilter(this)">
                        Precio
                    </button>
                    <div class="filter-content bg-white border border-gray-300 rounded-lg p-6 shadow-lg mt-2">
                        <div class="flex flex-col gap-4">
                            <div class="flex justify-between text-lg font-semibold">
                                <span>$</span>
                                <span id="min-label">50,000</span>
                                <span>~~</span>
                                <span>$</span>
                                <span id="max-label">500,000</span>
                            </div>
                            <input type="range" id="precio-min" name="precio_min" min="50000" max="500000" value="50000" step="1000" class="w-full">
                            <input type="range" id="precio-max" name="precio_max" min="50000" max="500000" value="500000" step="1000" class="w-full">
                            <div class="range-slider" id="slider-range"></div>
                        </div>
                    </div>
                </div>

                <!-- Botón de Aplicar Filtros -->
                <div class="flex-grow">
                    <button type="submit" class="bg-gradient-to-r from-gray-700 via-gray-900 to-black text-white font-semibold py-3 rounded-lg hover:bg-gradient-to-r hover:from-blue-500 hover:via-blue-700 hover:to-blue-900 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 shadow-lg hover:shadow-xl w-full">
                        Aplicar Filtros
                    </button>         
                </div>
            </div>
        </div>
    </form>

    <script>
        // Función para mostrar/ocultar el contenido del filtro
        function toggleFilter(button) {
            const filterItem = button.parentElement;
            filterItem.classList.toggle('open');
        }

        document.addEventListener('DOMContentLoaded', function() {
            const cells = document.querySelectorAll('#tallas-table td');
            const hiddenInput = document.getElementById('tallas-seleccionadas');

            cells.forEach(cell => {
                const checkbox = cell.querySelector('input.tallas-checkbox');

                cell.addEventListener('click', () => {
                    if (checkbox) {
                        checkbox.checked = !checkbox.checked; // Alterna el estado del checkbox
                        cell.classList.toggle('selected', checkbox.checked);
                        updateSelectedValues();
                    }
                });
            });

            function updateSelectedValues() {
                const selectedValues = [];
                document.querySelectorAll('#tallas-table td.selected input.tallas-checkbox:checked').forEach(checkbox => {
                    selectedValues.push(checkbox.value);
                });
                hiddenInput.value = selectedValues.join(',');
            }
        });


        // Actualizar el rango del slider de precio
        function updateSliderRange() {
            const min = parseInt(document.getElementById('precio-min').value);
            const max = parseInt(document.getElementById('precio-max').value);
            const slider = document.getElementById('slider-range');
            slider.style.width = ((max - min) / 500000) * 100 + '%';
            document.getElementById('min-label').textContent = min.toLocaleString();
            document.getElementById('max-label').textContent = max.toLocaleString();
        }

        // Inicializar los valores del slider
        updateSliderRange();

        // Escuchar eventos de cambio en los rangos
        document.getElementById('precio-min').addEventListener('input', updateSliderRange);
        document.getElementById('precio-max').addEventListener('input', updateSliderRange);
    </script>
</body>
</html>
