function mostrarPrimeraParte() {
    // Muestra la primera parte y oculta la segunda y tercera
    document.getElementById('parte2').style.display = 'none';
    document.getElementById('parte1').style.display = 'block';
    document.getElementById('parte3').style.display = 'none';
}

function mostrarSegundaParte() {
    // Muestra la segunda parte y oculta la primera
    document.getElementById('parte1').style.display = 'none';
    document.getElementById('parte2').style.display = 'block';
}

function mostrarNumeroMetodoPago() {
    const metodoPago = document.getElementById('metodo_pago').value;
    const labelNumeroPago = document.getElementById('label_numero_pago');
    const inputNumeroPago = document.getElementById('numero_pago');
    const labelClaveDinamica = document.getElementById('label_clave_dinamica');
    const inputClaveDinamica = document.getElementById('clave_dinamica');

    // Mostrar u ocultar el campo de número de pago según el método seleccionado
    if (metodoPago === 'Daviplata') {
        labelNumeroPago.style.display = 'block';
        inputNumeroPago.style.display = 'block';
        labelClaveDinamica.style.display = 'none';
        inputClaveDinamica.style.display = 'none';
    } else if (metodoPago === 'Nequi') {
        labelNumeroPago.style.display = 'block';
        inputNumeroPago.style.display = 'block';
        labelClaveDinamica.style.display = 'block';
        inputClaveDinamica.style.display = 'block';
    } else {
        labelNumeroPago.style.display = 'none';
        inputNumeroPago.style.display = 'none';
        labelClaveDinamica.style.display = 'none';
        inputClaveDinamica.style.display = 'none';
    }
}



