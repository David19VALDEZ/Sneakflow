// Almacenar la última tarjeta de producto mostrada
let ultimaTarjeta = null;

document.querySelectorAll('.producto').forEach(producto => {
    const detalles = producto.querySelector('.detalles-expandible');

    // Al pasar el ratón por encima de la tarjeta del producto
    producto.addEventListener('mouseenter', function() {
        // Cerrar detalles de la última tarjeta mostrada si es diferente
        if (ultimaTarjeta && ultimaTarjeta !== producto) {
            ultimaTarjeta.querySelector('.detalles-expandible').style.display = 'none'; // Ocultar el detalle de la última tarjeta
        }
        detalles.style.display = 'block'; // Mostrar detalles del producto actual
        ultimaTarjeta = producto; // Actualizar la última tarjeta mostrada
    });

    // Al salir el ratón de la tarjeta del producto
    producto.addEventListener('mouseleave', function() {
        detalles.style.display = 'none'; // Ocultar detalles del producto actual
        // Limpiar la última tarjeta mostrada si no hay mouse sobre ella
        if (ultimaTarjeta === producto) {
            ultimaTarjeta = null; // Reiniciar última tarjeta
        }
    });
});

