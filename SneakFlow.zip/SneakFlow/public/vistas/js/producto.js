// Función para inicializar los filtros
function initializeFilter() {
    // Selecciona los elementos del botón de filtro, popup de filtro, y los elementos de cierre
    const filterBtn = document.querySelector('.filter-btn');
    const filterPopup = document.querySelector('.filter-popup');
    const closePopup = document.querySelector('.close-popup');


    document.querySelectorAll('.filter-select').forEach(select => {
        select.addEventListener('focus', () => {
            select.classList.add('open');
        });
        
        select.addEventListener('blur', () => {
            select.classList.remove('open');
        });
    });
    
    // Evento para abrir el popup de filtro al hacer clic en el botón
    filterBtn.addEventListener('click', function() {
        toggleFilterPopup(true);
    });

    // Evento para cerrar el popup de filtro al hacer clic en el ícono de cierre
    closePopup.addEventListener('click', function() {
        toggleFilterPopup(false);
    });

    // Evento para cerrar el popup de filtro al hacer clic fuera del popup
    document.addEventListener('click', function(event) {
        if (!filterBtn.contains(event.target) && !filterPopup.contains(event.target)) {
            toggleFilterPopup(false);
        }
    });

    // Añadir eventos a los títulos de los filtros
    document.querySelectorAll('.filter-title').forEach(function(title) {
        title.addEventListener('click', toggleOptions);
    });
}


function updateFilter(name, value) {
    const url = new URL(window.location.href);
    if (value) {
        url.searchParams.set(name, value);
    } else {
        url.searchParams.delete(name);
    }
    window.location.href = url.toString();
}


document.addEventListener('DOMContentLoaded', function () {
    const priceSelect = document.getElementById('precio-select');
    const filterContent = document.getElementById('precio-menu');
    const minPriceInput = document.getElementById('precio-min');
    const maxPriceInput = document.getElementById('precio-max');
    const minLabel = document.getElementById('min-label');
    const maxLabel = document.getElementById('max-label');
    const sliderRange = document.getElementById('slider-range');

    function updateSlider() {
        const minVal = parseFloat(minPriceInput.value);
        const maxVal = parseFloat(maxPriceInput.value);

        minLabel.textContent = minVal.toLocaleString();
        maxLabel.textContent = maxVal.toLocaleString();

        const minPercent = ((minVal - 50000) / (500000 - 50000)) * 100;
        const maxPercent = ((maxVal - 50000) / (500000 - 50000)) * 100;

        sliderRange.style.left = `${minPercent}%`;
        sliderRange.style.width = `${maxPercent - minPercent}%`;
    }

    document.addEventListener('DOMContentLoaded', function () {
        const priceSelect = document.querySelector('#priceSelect'); // Ajusta el selector según el elemento
        const filterContent = document.querySelector('.filter-content'); // Ajusta según tu clase o id
        const minPriceInput = document.querySelector('#minPriceInput'); // Ajusta el selector según el elemento
        const maxPriceInput = document.querySelector('#maxPriceInput'); // Ajusta el selector según el elemento
    
        // Verifica si los elementos existen
        if (priceSelect && filterContent && minPriceInput && maxPriceInput) {
            priceSelect.addEventListener('change', function () {
                if (priceSelect.value === 'custom') {
                    filterContent.style.display = 'block';
                    updateSlider();
                } else {
                    filterContent.style.display = 'none';
                    // Resetear los valores del slider si es necesario
                    minPriceInput.value = 50000;
                    maxPriceInput.value = 500000;
                    updateSlider();
                }
            });
        } else {
            console.error('Uno o más elementos no encontrados. Verifica los selectores y la estructura del DOM.');
        }
    });
    

    minPriceInput.addEventListener('input', updateSlider);
    maxPriceInput.addEventListener('input', updateSlider);

    // Initialize the slider position on page load
    updateSlider();
});


function toggleOptions(menuId) {
    var menu = document.getElementById(menuId);
    var filterTitle = menu.previousElementSibling;

    // Alterna la visibilidad del menú y actualiza el título
    if (menu.style.display === "block") {
        menu.style.display = "none";
        filterTitle.classList.remove("active");
    } else {
        menu.style.display = "block";
        filterTitle.classList.add("active");
    }
}

// Función para alternar la previsualización del producto
function toggleProductPreview(productId) {
    let previewContainer = document.querySelector('.products-preview');
    let previewBoxes = previewContainer.querySelectorAll('.preview');

    previewContainer.style.display = 'flex';

    previewBoxes.forEach(preview => {
        let targetId = preview.getAttribute('data-target');
        if (productId === targetId) {
            preview.classList.add('active');
        } else {
            preview.classList.remove('active');
        }
    });
}

// Función para cerrar la previsualización del producto
function closePreview() {
    let previewContainer = document.querySelector('.products-preview');
    let previewBoxes = previewContainer.querySelectorAll('.preview');

    // Oculta la previsualización activa
    previewBoxes.forEach(preview => {
        preview.classList.remove('active');
    });

    // Oculta el contenedor de previsualización
    previewContainer.style.display = 'none';
}

// Asigna la función closePreview al icono de cerrar en cada tarjeta de previsualización
document.querySelectorAll('.preview .fa-times').forEach(closeIcon => {
    closeIcon.addEventListener('click', closePreview);
});


document.querySelectorAll('.size-table-table .selectable').forEach(cell => {
    cell.addEventListener('click', function() {
        document.querySelectorAll('.size-table-table .selectable').forEach(c => c.classList.remove('selected'));
        this.classList.add('selected');
    });
});

function actualizarCantidad(productId) {
    // Obtener el input de cantidad y el stock máximo disponible
    const cantidadInput = document.getElementById(`cantidad-${productId}`);
    const tallaSeleccionada = document.getElementById(`talla-${productId}`).value;
    const cantidadDisponible = tallaSeleccionada ? parseInt(cantidadInput.getAttribute('max')) : 1;

    // Verificar si la cantidad ingresada es mayor que la disponible
    if (parseInt(cantidadInput.value) > cantidadDisponible) {
        // Ajustar la cantidad al máximo disponible
        cantidadInput.value = cantidadDisponible;
    }
}

// Función que se llama al seleccionar una talla para ajustar el max disponible en el input de cantidad
// Función que se llama al seleccionar una talla para ajustar el máximo disponible en el input de cantidad
function selectTalla(element, productId) {
    const tallaId = element.getAttribute('data-talla-id');
    const cantidadDisponible = parseInt(element.getAttribute('data-cantidad'));

    // Actualiza el campo oculto de la talla seleccionada del carrito
    document.getElementById(`talla-${productId}`).value = tallaId;
    // Actualiza el campo oculto de la talla seleccionada del pedido
    document.getElementById(`talla-pedido-${productId}`).value = tallaId;
    // Actualiza el valor máximo permitido en el input de cantidad basado en la talla seleccionada
    const cantidadInput = document.getElementById(`cantidad-${productId}`);
    cantidadInput.max = cantidadDisponible;

    // Si la cantidad seleccionada actualmente es mayor que la disponible, ajusta al máximo
    if (parseInt(cantidadInput.value) > cantidadDisponible) {
        cantidadInput.value = cantidadDisponible;
    }

    // Actualiza la visualización de la talla seleccionada
    document.getElementById(`selected-talla-display-${productId}`).innerText = element.innerText;

    // Selecciona y desmarca todas las tallas del grupo actual de producto
    const tallaRows = document.querySelectorAll(`#tallas-table-${productId} .talla-row`);
    tallaRows.forEach(row => row.classList.remove('selected', 'bg-blue-100', 'text-blue-500'));

    // Marca la talla actual como seleccionada
    element.classList.add('selected', 'bg-blue-100', 'text-blue-500');
}


// Event listeners para ajustar automáticamente la cantidad
document.querySelectorAll('input[type="number"]').forEach(input => {
    input.addEventListener('input', function() {
        actualizarCantidad(this.id.split('-')[1]); // Obtener el id del producto desde el id del input
    });
});

function actualizarCantidad(productoId) {
    const cantidadInput = document.getElementById(`cantidad-${productoId}`);
    const cantidadCarrito = document.getElementById(`cantidad-carrito-${productoId}`);
    const cantidadComprar = document.getElementById(`cantidad-comprar-${productoId}`);

    // Actualizar los campos ocultos con el valor actual del input
    cantidadCarrito.value = cantidadInput.value;
    cantidadComprar.value = cantidadInput.value;
}

document.addEventListener("DOMContentLoaded", function() {
    function toggleDescripcion(enlace) {
        const productoId = enlace.getAttribute('data-producto-id');
        const descripcionParrafo = document.getElementById('desc-' + productoId);
        const descripcionCompleta = descripcionParrafo.getAttribute('data-full-description');

        if (enlace.textContent === "Ver Más") {
            descripcionParrafo.innerHTML = descripcionCompleta + ' <a href="#" class="text-blue-500 cursor-pointer ver-mas" data-producto-id="' + productoId + '">Ver Menos</a>';
        } else {
            const descripcionResumida = descripcionCompleta.substr(0, 100) + '...';
            descripcionParrafo.innerHTML = descripcionResumida + ' <a href="#" class="text-blue-500 cursor-pointer ver-mas" data-producto-id="' + productoId + '">Ver Más</a>';
        }

        // Reasigna el evento al nuevo enlace después de cada clic
        descripcionParrafo.querySelector('.ver-mas').addEventListener('click', function(evento) {
            evento.preventDefault();
            toggleDescripcion(this);
        });
    }

    // Agrega el evento click inicial para todos los enlaces "Ver Más"
    document.querySelectorAll('.ver-mas').forEach(function(enlace) {
        enlace.addEventListener('click', function(evento) {
            evento.preventDefault();
            toggleDescripcion(this);
        });
    });
});

// Escucha el evento DOMContentLoaded para asegurarse de que el DOM esté completamente cargado
document.addEventListener("DOMContentLoaded", function() {
    // Selecciona todas las tablas de tallas
    const sizeTables = document.querySelectorAll(".filtro-tallas table");

    sizeTables.forEach(table => {
        // Cuenta el número de filas en el cuerpo de la tabla (excluyendo la fila de encabezado)
        const rows = table.querySelectorAll("tbody tr").length;
        // Selecciona la imagen que está más cerca de la tabla actual (dentro del mismo contenedor)
        const image = table.closest(".preview-image").querySelector("img");

        // Remueve cualquier clase existente antes de aplicar la nueva
        image.classList.remove("img-max-75", "img-max-85", "img-max-90");

        // Aplica la clase en función del número de filas
        if (rows >= 3) {
            image.classList.add("img-max-75"); // Aplica max-height del 75%
        } else if (rows === 2) {
            image.classList.add("img-max-85"); // Aplica max-height del 85%
        } else if (rows === 1) {
            image.classList.add("img-max-90"); // Aplica max-height del 90%
        }
    });
});
