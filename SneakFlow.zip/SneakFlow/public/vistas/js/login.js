document.addEventListener('DOMContentLoaded', () => {
    const loginsec = document.querySelector('.login-section');
    const loginlink = document.querySelector('.login-link');
    const registerlink = document.querySelector('.register-link');

    console.log('loginsec:', loginsec);
    console.log('loginlink:', loginlink);
    console.log('registerlink:', registerlink);

    if (loginlink && registerlink && loginsec) {
        registerlink.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('Registro seleccionado.');
            loginsec.classList.add('active');
        });

        loginlink.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('Inicio de sesión seleccionado.');
            loginsec.classList.remove('active');
        });
    } else {
        console.error('No se encontraron los elementos necesarios.');
    }
});


document.addEventListener('DOMContentLoaded', function() {
    function togglePasswordVisibility(toggleButtonId, inputId, iconId) {
        const toggleButton = document.getElementById(toggleButtonId);
        const passwordInput = document.getElementById(inputId);
        const passwordIcon = document.getElementById(iconId);

        toggleButton.addEventListener('click', function() {
            // Cambiar el tipo de input entre 'password' y 'text'
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);

            // Cambiar el icono según el estado
            if (type === 'password') {
                passwordIcon.classList.remove('bxs-lock-open'); // Cambia a tu icono para 'cerrado'
                passwordIcon.classList.add('bxs-lock-alt'); // Icono de 'cerrado'
            } else {
                passwordIcon.classList.remove('bxs-lock-alt'); // Cambia a tu icono para 'abierto'
                passwordIcon.classList.add('bxs-lock-open'); // Icono de 'abierto'
            }
        });
    }

    // Llama a la función para cada campo de contraseña
    togglePasswordVisibility('toggle-password-contraseña', 'contraseña', 'password-icon-contraseña');
    togglePasswordVisibility('toggle-password-password', 'password', 'password-icon-password');
});
