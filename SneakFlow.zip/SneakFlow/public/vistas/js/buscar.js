function toggleProductPreview(productId) {
    let previewContainer = document.querySelector('.products-preview');
    let previewBoxes = previewContainer.querySelectorAll('.preview');

    previewContainer.style.display = 'flex';

    previewBoxes.forEach(preview => {
        let targetId = preview.getAttribute('data-target');
        if (productId === targetId) {
            preview.classList.add('active');
        } else {
            preview.classList.remove('active');
        }
    });
}

// Función para cerrar la previsualización del producto
function closePreview() {
    const previews = document.querySelectorAll('.products-preview > div');
    previews.forEach(preview => {
        preview.classList.add('hidden');
    });
}


document.querySelectorAll('.ver-mas').forEach(button => {
button.addEventListener('click', function(event) {
    event.preventDefault();
    const productId = this.getAttribute('data-producto-id');
    document.getElementById(`desc-${productId}`).classList.add('hidden');
    document.getElementById(`full-desc-${productId}`).classList.remove('hidden');
});
});

document.querySelectorAll('.ver-menos').forEach(button => {
    button.addEventListener('click', function(event) {
        event.preventDefault();
        const productId = this.getAttribute('data-producto-id');
        document.getElementById(`desc-${productId}`).classList.remove('hidden');
        document.getElementById(`full-desc-${productId}`).classList.add('hidden');
    });
});