const estadoCompra = {}; // Objeto para controlar el estado de cada botón

function gestionarCompra(productId) {
    const tallaSelect = document.getElementById(`tallaSelect-${productId}`);
    const tallaIdInput = document.getElementById(`tallaId-${productId}`);
    const tallasLabel = document.getElementById(`tallasLabel-${productId}`);
    const botonComprar = document.getElementById(`botonComprar-${productId}`);

    // Si el botón no ha sido presionado antes, mostramos el select
    if (!tallaSelect.classList.contains('hidden')) {
        // Actualiza el ID de la talla al cambiar la selección
        tallaIdInput.value = tallaSelect.value;

        // Enviar el formulario al confirmar
        const formulario = tallaSelect.closest('form');
        formulario.submit();
    } else {
        tallaSelect.classList.remove('hidden');
        tallasLabel.classList.remove('hidden');
        botonComprar.textContent = 'Confirmar compra';
    }
}

function validarTallaSeleccionada() {
    const tallaSeleccionada = document.querySelector('select[name="talla"]:not(.hidden)');
    if (tallaSeleccionada && tallaSeleccionada.value === "") {
        alert("Por favor, selecciona una talla antes de continuar.");
        return false;
    }
    return true;
}

function abrirPopup(productoJson) {
    const producto = JSON.parse(productoJson);
    
    // Asignar valores a los elementos del popup
    document.getElementById('popupImagen').src = "/SneakFlow/public/vistas/img/" + producto.imagen;
    document.getElementById('popupNombre').textContent = producto.nombre;
    document.getElementById('popupPrecio').textContent = "$" + producto.precio;

    // Asignar el nombre del producto al input oculto
    document.getElementById('nombre_producto').value = producto.nombre; // Cambia esto según la estructura de tu objeto

    // Manejo de la descripción
    const descripcion = producto.descripcion || "Descripción no disponible.";
    document.getElementById('popupDescripcion').textContent = descripcion.substring(0, 129); // Muestra un resumen
    descripcionCompleta = descripcion; // Guarda la descripción completa
    
    // Mostrar 'Ver más' botón si la descripción es larga
    const longitudDescripcion = descripcion.split(' ').length;
    document.getElementById('verMasBtnContainer').style.display = (longitudDescripcion > 25) ? 'inline' : 'none';

    // Mostrar género y marca
    document.getElementById('popupGenero').textContent = producto.genero || "Género no disponible.";
    document.getElementById('popupMarca').textContent = producto.marca_nombre || "Marca no disponible.";

    const popupColoresContainer = document.getElementById('popupColores');
    popupColoresContainer.textContent = producto.colores.join(", ") || "Colores no disponibles.";
    
    // Mostrar el popup
    document.getElementById('popup').classList.remove('hidden');

    // Evitar que los clics en el contenido del popup se propaguen
    const popupContent = document.querySelector('#popup .bg-white');
    popupContent.addEventListener('click', function(event) {
        event.stopPropagation(); // Previene que el clic se propague al fondo
    });

      const tallaSelect = document.getElementById('tallaSelect');
    tallaSelect.innerHTML = ''; // Limpiar opciones anteriores
    if (producto.tallas_assoc && Object.keys(producto.tallas_assoc).length > 0) {
        for (const tallaId in producto.tallas_assoc) {
            const talla = producto.tallas_assoc[tallaId];
            const option = document.createElement('option');
            option.value = tallaId;
            option.textContent = talla.nombre;
            tallaSelect.appendChild(option);
        }
    } else {
        const option = document.createElement('option');
        option.textContent = "No hay tallas disponibles";
        tallaSelect.appendChild(option);
    }

    // Desactivar clics en el fondo
    document.getElementById('popup').style.pointerEvents = 'auto'; // Permitir interacciones con el fondo
}

function cerrarPopup() {

}
function cerrarPopup(event) {
    const popup = document.getElementById('popup');

    // Verifica si el clic fue en el fondo oscuro (fuera del contenido del modal)
    if (event.target === popup) {
        popup.classList.add('hidden');
        descripcionCompleta = ""; // Resetea la descripción al cerrar
    }else {
        document.getElementById('popup').classList.add('hidden');
        descripcionCompleta = ""; // Resetear descripción al cerrar4
    }
}

// Agregar evento para cerrar el popup al hacer clic en el fondo
document.getElementById('popup').addEventListener('click', cerrarPopup);



function verMas() {
    document.getElementById('popupDescripcion').textContent = descripcionCompleta; // Show full description
    document.getElementById('verMasBtn').classList.add('hidden'); // Hide 'ver más' button
    document.getElementById('verMenosBtn').classList.remove('hidden'); // Show 'ver menos' button
}

function verMenos() {
    const descripcionResumen = descripcionCompleta.substring(0, 129); // Show summary without ellipsis
    document.getElementById('popupDescripcion').textContent = descripcionResumen; // Show brief description
    document.getElementById('verMasBtn').classList.remove('hidden'); // Show 'ver más' button
    document.getElementById('verMenosBtn').classList.add('hidden'); // Hide 'ver menos' button
}

// Selecciona el <select> y el campo oculto talla_id
const tallaSelect = document.getElementById('tallaSelect');
const tallaIdInput = document.getElementById('tallaId');

// Actualiza el campo oculto con el ID de la talla seleccionada
tallaSelect.addEventListener('change', function() {
    tallaIdInput.value = tallaSelect.value;
});

// Inicializa el campo oculto con el valor seleccionado por defecto
tallaIdInput.value = tallaSelect.value;
