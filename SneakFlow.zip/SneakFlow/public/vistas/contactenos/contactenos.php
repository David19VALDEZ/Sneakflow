<?php require_once '../public/vistas/header.php'; ?> <!-- Incluye el encabezado de la página -->
<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet"> <!-- Enlace a la fuente Quicksand -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous"> <!-- Enlace a FontAwesome para iconos -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css"> <!-- Enlace a Animate.css para efectos de animación -->
<link rel="stylesheet" href="/SneakFlow/public/vistas/css/contacto.css"> <!-- Enlace al CSS específico de la página de contacto -->

<div class="text-gray-800 min-h-screen flex items-center justify-center "> <!-- Contenedor principal -->
    <div class="bg-gray-900 rounded-lg p-10 shadow-lg w-full max-w-3xl flex"> <!-- Aumentar el ancho máximo a 3xl -->
        <div class="w-full"> <!-- Div que ocupa todo el ancho -->
            <h1 class="text-4xl font-bold text-center mb-6 text-green-400">Contáctanos <span class="text-white">Us</span></h1> <!-- Título de la sección -->
            <div class="animated bounceInUp"> <!-- Div para aplicar la animación de entrada -->
                <div class="contact-form"> <!-- Contenedor del formulario de contacto -->
                    <h3 class="text-2xl mb-4 text-white">Contáctanos</h3> <!-- Subtítulo -->

                    <!-- Mensaje de éxito o error (ocultos por defecto) -->
                    <div class="alert alert-success" style="display: none;"></div>
                    <div class="alert alert-danger" style="display: none;"></div>

                    <!-- Formulario de contacto -->
                    <form id="contactoForm" action="enviar-contacto" method="POST" class="space-y-4"> <!-- Formulario con método POST -->
                        <input type="text" name="nombre_completo" placeholder="Nombre Completo" class="w-full p-3 rounded bg-gray-800 text-white border border-green-500 focus:outline-none focus:ring-2 focus:ring-green-500 transition duration-200" required>
                        <input type="email" name="email" placeholder="Correo Electrónico" class="w-full p-3 rounded bg-gray-800 text-white border border-green-500 focus:outline-none focus:ring-2 focus:ring-green-500 transition duration-200" required>
                        <input type="text" name="asunto" placeholder="Asunto" class="w-full p-3 rounded bg-gray-800 text-white border border-green-500 focus:outline-none focus:ring-2 focus:ring-green-500 transition duration-200" required>
                        <textarea name="mensaje" rows="4" placeholder="Mensaje" class="w-full p-3 rounded bg-gray-800 text-white border border-green-500 focus:outline-none focus:ring-2 focus:ring-green-500 transition duration-200" required></textarea>
                        <button class="w-full bg-green-600 hover:bg-green-700 p-3 rounded text-white font-bold transition duration-200">Enviar</button> <!-- Botón para enviar el formulario -->
                    </form>
                </div>
            </div>
        </div>
        <div class="w-1/2 pl-6 mt-8"> <!-- Segunda mitad del contenedor -->
            <div class="contact-info mt-8 bg-gray-800 rounded-lg p-6 shadow-md"> <!-- Contenedor para la información de contacto con fondo y sombra -->
                <h4 class="text-2xl font-semibold text-green-400 mb-4">Más Información</h4> <!-- Subtítulo mejorado -->
                <ul class="mt-2 space-y-3 text-gray-300"> <!-- Lista de información de contacto con espaciado mejorado -->
                    <li class="flex items-center"><i class="fas fa-map-marker-alt mr-2"></i> Villeta</li> <!-- Ubicación con ícono -->
                    <li class="flex items-center"><i class="fas fa-envelope-open-text mr-2"></i> sn3akflow@gmail.com</li> <!-- Correo electrónico con ícono -->
                </ul>
                <p class="mt-4 text-gray-400">Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero provident ipsam necessitatibus repellendus, cumque voluptatibus.</p> <!-- Texto descriptivo más completo -->
            </div>
        </div>
    </div>
</div>

<script>
    // Función para mostrar la alerta y luego recargar la página
    function mostrarAlerta(tipo, mensaje) {
        const alertDiv = document.querySelector(`.alert-${tipo}`); // Selecciona el div de alerta según el tipo (éxito o error)
        alertDiv.innerHTML = mensaje; // Establece el mensaje de alerta
        alertDiv.style.display = 'block'; // Muestra la alerta

        // Esperar 3 segundos y recargar la página
        setTimeout(() => {
            alertDiv.style.display = 'none'; // Oculta la alerta
            window.location.reload(); // Recarga la página
        }, 3000); // Tiempo de espera de 3 segundos
    }

    // Función para manejar el envío del formulario mediante AJAX
    function enviarFormulario(event) {
        event.preventDefault(); // Evita el envío normal del formulario

        const form = event.target; // Obtiene el formulario que desencadenó el evento
        const formData = new FormData(form); // Crea un objeto FormData a partir del formulario

        fetch('enviar-contacto', { // Realiza una solicitud fetch al servidor
            method: 'POST', // Método POST
            body: formData // Envía los datos del formulario
        })
        .then(response => response.json()) // Procesa la respuesta como JSON
        .then(data => {
            // Verifica si la respuesta indica éxito o error
            if (data.success) {
                mostrarAlerta('success', data.message); // Muestra mensaje de éxito
            } else {
                mostrarAlerta('danger', data.message); // Muestra mensaje de error
            }
        })
        .catch(error => {
            mostrarAlerta('danger', 'Ocurrió un error al enviar el formulario.'); // Maneja errores de la solicitud
        });
    }

    // Asociar la función de envío al formulario
    document.addEventListener('DOMContentLoaded', function() { // Espera a que el DOM esté completamente cargado
        const form = document.querySelector('#contactoForm'); // Selecciona el formulario
        form.addEventListener('submit', enviarFormulario); // Asocia el evento de envío con la función
    });
</script>

<?php require_once '../public/vistas/footer.php'; ?> <!-- Incluye el pie de página -->
