<?php require_once '../public/vistas/header.php'; ?>
<!-- Incluir Tailwind CSS desde CDN -->
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<link href="https://unpkg.com/animate.css@4.1.1/animate.min.css" rel="stylesheet"> <!-- Animaciones adicionales -->
<style>
.marca:hover .marca-inner {
    transform: rotateY(180deg);
}
</style>
<div class="bg-gray-900 min-h-screen">
    <!-- Sección Principal con Imagen de Fondo y Animaciones -->
    <div class="principal bg-cover bg-center h-screen relative overflow-hidden">
        <div class="absolute inset-0 bg-black opacity-60"></div>
        <div class="info text-center z-10 relative animate__animated animate__fadeInUp">
            <h1 class="titulo text-6xl mt-16 font-extrabold text-white drop-shadow-lg tracking-widest">SneakFlow</h1>
            <p class="descripcion text-xl text-gray-300 mt-6 tracking-wide">
                Innovación y estilo futurista en cada paso. Explora las mejores marcas y descubre el futuro de la moda.
            </p>
            <a href="#marcas" class="mt-10 inline-block bg-indigo-600 text-white px-8 py-3 rounded-full hover:bg-indigo-700 transition transform hover:scale-110">Descubre más</a>
        </div>
        <div class="futuristic-overlay absolute inset-0 flex justify-around items-center animate-pulse mt-16">
            <!-- Líneas futuristas flotantes -->
            <div class="h-64 w-1 bg-gradient-to-b from-indigo-500 to-transparent"></div>
            <div class="h-64 w-1 bg-gradient-to-b from-indigo-500 to-transparent"></div>
            <div class="h-64 w-1 bg-gradient-to-b from-indigo-500 to-transparent"></div>
            <div class="h-64 w-1 bg-gradient-to-b from-indigo-500 to-transparent"></div>
        </div>
    </div>

    <!-- Sección Nuestras Marcas con Animación 3D -->
    <div id="marcas" class="marcas-container py-16 bg-white">
        <h2 class="subtitulo text-4xl font-bold text-center text-gray-900 mb-12 animate__animated animate__fadeInUp">Nuestras Marcas</h2>
        <div class="marcas flex justify-center flex-wrap gap-10">
            <?php foreach ($mars as $marks): ?>
                <a href="marca?id=<?= htmlspecialchars($marks['id']); ?>" class="marca w-48 h-48 relative transform transition-transform hover:rotate-y-180 perspective" style="transform-style: preserve-3d; perspective: 1000px;">
                    <div class="marca w-48 h-48 relative transform transition-transform hover:rotate-y-180 perspective" style="transform-style: preserve-3d; perspective: 1000px;">
                        <div class="marca-inner w-full h-full relative" style="transform-style: preserve-3d; transition: transform 0.8s;">
                            <!-- Parte trasera de la marca -->
                            <div class="marca-reversa absolute w-full h-full bg-gray-800 flex items-center justify-center" style="transform: rotateY(180deg); backface-visibility: hidden;">
                                <img src="/SneakFlow/public/vistas/img/logos/<?= isset($marks['logo']) ? htmlspecialchars($marks['logo']) : 'default-logo.png'; ?>" 
                                    alt="Logo de <?= isset($marks['marca']) ? htmlspecialchars($marks['marca']) : 'Marca desconocida'; ?>" 
                                    class="marca-imagen w-full h-full object-cover transition-transform transform hover:scale-105">
                            </div>
                            <!-- Parte frontal de la marca -->
                            <div class="marca-frontal absolute w-full h-full bg-gray-800 flex items-center justify-center" style="backface-visibility: hidden;">
                                <img src="/SneakFlow/public/vistas/img/<?= isset($marks['imagen']) ? htmlspecialchars($marks['imagen']) : 'default.png'; ?>" 
                                    alt="<?= isset($marks['marca']) ? htmlspecialchars($marks['marca']) : 'Marca desconocida'; ?>" 
                                    class="marca-logo w-full h-full object-cover transition-transform transform hover:scale-105">
                            </div>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Sección Sobre Nosotros con Neón Futurista -->
    <div class="nosotros-container py-16 bg-gray-900">
        <div class="nosotros flex flex-col lg:flex-row items-center mt-8">
            <div class="relative w-full lg:w-1/2 h-80 lg:h-96 overflow-hidden rounded-lg shadow-lg">
                <img src="/SneakFlow/public/vistas/img/Designer.jfif" alt="Nosotros" class="nosotros-imagen w-full h-full object-cover filter brightness-75">
                <div class="absolute inset-0 bg-purple-500 opacity-50 animate-pulse"></div> <!-- Overlay de color futurista -->
            </div>
            <div class="nosotros-info lg:ml-12 mt-8 lg:mt-0 text-center lg:text-left text-white">
                <h2 class="subtitulo text-4xl font-bold text-neon mb-6">Sobre Nosotros</h2>
                <p class="text-lg text-gray-300 leading-relaxed">
                    Somos un equipo apasionado por la moda y el deporte. En SneakFlow, nos esforzamos por brindarte lo mejor en calzado, combinando estilo y comodidad.
                </p>
                <p class="text-lg text-gray-300 leading-relaxed mt-4">
                    Nuestro compromiso es ofrecer productos de alta calidad, con atención personalizada para que disfrutes de una experiencia de compra inigualable.
                </p>
                <a href="Contactenos" class="inline-block mt-8 bg-indigo-600 text-white px-6 py-2 rounded-full hover:bg-indigo-700 transform hover:scale-105 transition duration-300">Contáctanos</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php require_once '../public/vistas/footer.php'; ?>
</div>
