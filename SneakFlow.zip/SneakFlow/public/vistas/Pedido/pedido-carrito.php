<?php
    session_start(); // Asegúrate de que la sesión esté iniciada

    // Verifica si la sesión contiene datos del pedido
    if (isset($_SESSION['pedido']) && is_array($_SESSION['pedido']) && count($_SESSION['pedido']) > 0) {
        // Si la sesión contiene productos, asigna a $productos
        $productos = $_SESSION['pedido'];
    } else {
        // Si no hay productos en la sesión, muestra un mensaje de error
        echo "No hay productos en el carrito.";
        exit; // Termina el script si no hay productos
    }

    // Recorre todos los productos en el pedido
    foreach ($productos as $producto) {
        $producto_id = htmlspecialchars($producto['producto_id']);
        $talla_id = htmlspecialchars($producto['talla_id']);
        $cantidad = htmlspecialchars($producto['cantidad']);
        $precio = htmlspecialchars($producto['precio']);
        $nombre_producto = htmlspecialchars($producto['nombre_producto']);
        $nombre_talla = isset($producto['nombre_talla']) ? htmlspecialchars($producto['nombre_talla']) : 'Desconocida';

    }

    include 'alertas/crear.php';

    require_once '../public/vistas/header.php';
?>
    <link rel="stylesheet" href="/SneakFlow/public/vistas/css/pedido.css">
    <div class="container mx-auto p-5 mt-12">
        <form action="RealizarPedidoC" id="pedido-form" method="post" class="bg-gray-800 border border-neon-blue rounded-lg p-8 shadow-lg">
            <h1 class="text-4xl font-bold text-white mb-2 text-center">Detalles de la Compra</h1>
            <div class="w-full h-1 bg-green-500 mx-auto mb-4"></div>    
            <!-- Parte 1: Datos Personales -->
            <div id="parte1">
                <h3 class="text-3xl font-semibold mb-4 text-neon-blue">Datos Personales</h3>
                <div class="mb-6">
                    <label for="tipo_documento" class="block text-sm font-medium text-gray-300">Tipo de Documento:</label>
                    <select name="tipo_documento" id="tipo_documento" required class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
                        <option value="">Seleccione</option>
                        <option value="T.I">T.I</option>
                        <option value="C.C">C.C</option>
                    </select>
                </div>

                <div class="mb-6">
                    <label for="numero_documento" class="block text-sm font-medium text-gray-300">Número de Documento:</label>
                    <input type="text" name="numero_documento" id="numero_documento" required class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
                </div>

                <div class="mb-6">
                    <label for="telefono" class="block text-sm font-medium text-gray-300">Teléfono:</label>
                    <input type="tel" name="telefono" id="telefono" required class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
                </div>

                <div class="mb-6">
                    <label for="direccion" class="block text-sm font-medium text-gray-300">Dirección:</label>
                    <input type="text" name="direccion" id="direccion" required class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
                </div>

                <button type="button" onclick="mostrarSegundaParte()" class="mt-4 w-full bg-neon-blue text-black font-bold p-3 rounded-md hover:bg-blue-600 transition">Siguiente</button>
            </div>

            <!-- Parte 2: Datos del Pedido -->
            <div id="parte2" style="display: none;">
                <h3 class="text-3xl font-semibold mb-4 text-neon-blue">Detalles del Pedido</h3>
                
                <input type="hidden" name="usuario_id" value="<?php echo htmlspecialchars($_SESSION['id']); ?>">
                <!-- Campos ocultos para cada producto -->
                <input type="hidden" name="producto_id[]" value="<?php echo $producto_id; ?>">
                <input type="hidden" name="talla_id[]" value="<?php echo $talla_id; ?>">
                <input type="hidden" name="precio[]" value="<?php echo $precio; ?>">
                <input type="hidden" name="nombre_producto[]" value="<?php echo $nombre_producto; ?>">
                <input type="hidden" name="nombre_talla[]" value="<?php echo $nombre_talla; ?>">

                <?php foreach ($productos as $producto) { ?>
                    <div class="mb-6">
                        <label for="cantidad_<?php echo $producto['producto_id']; ?>" class="block text-sm font-medium text-gray-300">Cantidad de <?php echo htmlspecialchars($producto['nombre_producto']); ?>:</label>
                        <input type="number" name="cantidad[]" id="cantidad_<?php echo $producto['producto_id']; ?>" value="1" min="1" required class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
                        <input type="hidden" name="producto_id[]" value="<?php echo htmlspecialchars($producto['producto_id']); ?>">
                        <input type="hidden" name="talla_id[]" value="<?php echo htmlspecialchars($producto['talla_id']); ?>">
                    </div>
                <?php } ?>


                <div class="mb-6">
                    <label for="metodo_pago" class="block text-sm font-medium text-gray-300">Método de Pago:</label>
                    <select name="metodo_pago" id="metodo_pago" onchange="mostrarNumeroMetodoPago()" required class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
                        <option value="">Seleccione</option>
                        <option value="Daviplata">Daviplata</option>
                        <option value="Nequi">Nequi</option>
                    </select>
                </div>
                <div class="mb-6">
                    <label id="label_numero_pago" for="numero_pago" style="display:none;" class="block text-sm font-medium text-gray-300">Número de Pago:</label>
                    <input id="numero_pago" type="text" name="numero_pago" style="display:none;" class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue" />
                </div>
                <div class="mb-6">
                <!-- Clave Dinámica para Nequi -->
                    <label id="label_clave_dinamica" for="clave_dinamica" style="display:none;" class="block text-sm font-medium text-gray-300">Clave Dinámica:</label>
                    <input id="clave_dinamica" type="text" name="clave_dinamica" style="display:none;" class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue" />
                </div>

                <button type="button" onclick="mostrarTerceraParte()" class="mt-4 w-full bg-neon-blue text-black font-bold p-3 rounded-md hover:bg-blue-600 transition">Siguiente</button>
                
                <button type="button" onclick="mostrarPrimeraParte()" class="mt-4 w-full bg-gray-600 text-gray-300 font-semibold p-3 rounded-md hover:bg-gray-500 transition">Atrás</button>
            </div>

            <!-- Parte 3: Resumen del Pedido -->
            <div id="parte3" style="display: none;">
                <h3 class="text-3xl font-semibold mb-4 text-white">Resumen del Pedido</h3>
                <table class="table-auto w-full text-gray-300 border-collapse">
                    <thead>
                        <tr>
                            <th class="px-4 py-2 border-b">Producto</th>
                            <th class="px-4 py-2 border-b">ID Producto</th>
                            <th class="px-4 py-2 border-b">Cantidad</th>
                            <th class="px-4 py-2 border-b">Precio Unitario</th>
                            <th class="px-4 py-2 border-b">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $totalPedido = 0; // Inicializamos el total del pedido
                        foreach ($productos as $producto): 
                            $totalProducto = $producto['cantidad'] * $producto['precio'];
                            $totalPedido += $totalProducto; // Acumulamos el total del pedido
                        ?>
                            <tr class="text-gray-300 hover:bg-gray-800 text-center">
                                <td class="px-6 py-4 border-b border-gray-700"><?php echo htmlspecialchars($producto['nombre_producto']); ?></td>
                                <td class="px-6 py-4 border-b border-gray-700"><?php echo htmlspecialchars($producto['producto_id']); ?></td>
                                <td class="px-6 py-4 border-b border-gray-700"><?php echo htmlspecialchars($producto['cantidad']); ?></td>
                                <td class="px-6 py-4 border-b border-gray-700"><?php echo htmlspecialchars($producto['precio']); ?></td>
                                <td class="px-6 py-4 border-b border-gray-700 font-semibold text-green-400">
                                    <?php echo number_format($totalProducto, 2); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Total general -->
                <div class="mt-4 text-right">
                    <h4 class="text-xl font-semibold text-white">Total Pedido: <span class="text-green-400"><?php echo number_format($totalPedido, 2); ?></span></h4>
                </div>

                <!-- Botones -->
                <button type="submit" class="mt-4 w-full bg-green-600 text-white font-bold p-3 rounded-md hover:bg-green-500 transition">Enviar Pedido</button>
                <button type="button" onclick="mostrarSegundaParte()" class="mt-4 w-full bg-gray-600 text-gray-300 font-semibold p-3 rounded-md hover:bg-gray-500 transition">Atrás</button>
            </div>



        </form>

        <button onclick="window.history.back();" class="mt-4 bg-gray-600 text-gray-300 font-semibold p-3 rounded-md hover:bg-gray-500 transition">Volver a la tienda</button>
    </div>

    <script>
        function mostrarTerceraParte() {
            // Muestra la tercera parte y oculta la segunda
            document.getElementById('parte2').style.display = 'none';
            document.getElementById('parte3').style.display = 'block';
        }
    </script>

    <?php require_once '../public/vistas/footer.php'; ?>
    <script src="/SneakFlow/public/vistas/js/pedido.js"></script> <!-- Script de productos marcas -->
