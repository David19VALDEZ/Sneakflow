<?php
    session_start(); // Asegúrate de que la sesión esté iniciada

    // Obtiene los datos del pedido de la sesión
    $pedido = $_SESSION['pedido'];
    $producto_id = htmlspecialchars($pedido['producto_id']);
    $talla_id = htmlspecialchars($pedido['talla']);
    $cantidad = htmlspecialchars($pedido['cantidad']);
    $precio = htmlspecialchars($pedido['precio']);
    $nombre_producto = htmlspecialchars($pedido['nombre_producto']);
    $nombre_talla = isset($pedido['nombre_talla']) ? htmlspecialchars($pedido['nombre_talla']) : 'Desconocida'; // Asegúrate de obtener el nombre de la talla
    $imagen_producto = htmlspecialchars($pedido['imagen']); // Asegúrate de que tengas la imagen en los datos del pedido
    $marca = htmlspecialchars($pedido["marca"]);
    
    include 'alertas/crear.php';
    require_once '../public/vistas/header.php';
?>
<link rel="stylesheet" href="/SneakFlow/public/vistas/css/pedido.css">
<div class="container mx-auto p-5 mt-12 flex flex-nowrap items-start">
    <!-- Formulario de Pedido -->
    <form action="RealizarPedido" id="pedido-form" method="post" class="bg-gray-900 border border-neon-blue rounded-lg p-8 shadow-lg w-full mr-5">
        <h1 class="text-4xl font-bold text-white mb-2 text-center">Detalles de la Compra</h1>
        <div class="w-full h-1 bg-green-500 mx-auto mb-4"></div>

        <!-- Parte 1: Datos Personales -->
        <div id="parte1">
            <h3 class="text-3xl font-semibold mb-4 text-white">Datos Personales</h3>
            <div class="mb-6">
                <label for="tipo_documento" class="block text-sm font-medium text-gray-300">Tipo de Documento:</label>
                <select name="tipo_documento" id="tipo_documento" required class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
                    <option value="">Seleccione</option>
                    <option value="T.I">T.I</option>
                    <option value="C.C">C.C</option>
                </select>
            </div>

            <div class="mb-6">
                <label for="numero_documento" class="block text-sm font-medium text-gray-300">Número de Documento:</label>
                <input type="text" name="numero_documento" id="numero_documento" required class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
            </div>

            <div class="mb-6">
                <label for="telefono" class="block text-sm font-medium text-gray-300">Teléfono:</label>
                <input type="tel" name="telefono" id="telefono" required class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
            </div>

            <div class="mb-6">
                <label for="direccion" class="block text-sm font-medium text-gray-300">Dirección:</label>
                <input type="text" name="direccion" id="direccion" required class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
            </div>

            <button type="button" onclick="mostrarSegundaParte()" class="mt-4 w-full bg-neon-blue text-black font-bold p-3 rounded-md hover:bg-blue-600 transition">Siguiente</button>
        </div>

        <!-- Parte 2: Datos del Pedido -->
        <div id="parte2" style="display: none;">
            <h3 class="text-3xl font-semibold mb-4 text-white">Detalles del Pedido</h3>

            <input type="hidden" name="producto_id" value="<?php echo htmlspecialchars($producto_id); ?>">
            <input type="hidden" name="talla_id" value="<?php echo htmlspecialchars($talla_id); ?>">
            <input type="hidden" name="usuario_id" value="<?php echo htmlspecialchars($_SESSION['id']); ?>">
            <input type="hidden" name="precio" value="<?php echo htmlspecialchars($precio); ?>">
            <input type="hidden" name="total" id="total" value="" />

            <div class="mb-6">
                <label for="cantidad" class="block text-sm font-medium text-gray-300">Cantidad:</label>
                <input type="number" name="cantidad" id="cantidad" value="1" required min="1" class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
            </div>

            <div class="mb-6">
                <label for="metodo_pago" class="block text-sm font-medium text-gray-300">Método de Pago:</label>
                <select name="metodo_pago" id="metodo_pago" onchange="mostrarNumeroMetodoPago()" required class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue">
                    <option value="">Seleccione</option>
                    <option value="Daviplata">Daviplata</option>
                    <option value="Nequi">Nequi</option>
                </select>
            </div>

            <label id="label_numero_pago" for="numero_pago" style="display:none;" class="block text-sm font-medium text-gray-300">Número de Pago:</label>
            <input id="numero_pago" type="text" name="numero_pago" style="display:none;" class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue" />

            <label id="label_clave_dinamica" for="clave_dinamica" style="display:none;" class="block text-sm font-medium text-gray-300">Clave Dinámica:</label>
            <input id="clave_dinamica" type="text" name="clave_dinamica" style="display:none;" class="mt-1 block w-full p-3 border border-neon-blue bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-neon-blue" />

            <button type="button" onclick="mostrarTerceraParte()" class="mt-4 w-full bg-neon-blue text-black font-bold p-3 rounded-md hover:bg-blue-600 transition">Siguiente</button>

            <button type="button" onclick="mostrarPrimeraParte()" class="mt-2 w-full bg-gray-600 text-gray-300 font-semibold p-3 rounded-md hover:bg-gray-500 transition">Atrás</button>
        </div>

        <!-- Parte 3: Resumen del Pedido -->
        <div id="parte3" style="display: none;">
            <h3 class="text-3xl font-semibold mb-4 text-white">Resumen del Pedido</h3>
            <ul class="grid grid-cols-4 sm:grid-cols-3 gap-4 text-gray-300 pl-0">
                <li><strong>Producto:</strong> <?php echo $nombre_producto; ?></li>
                <li><strong>ID del Producto:</strong> <span id="producto_id_resumen"><?php echo $producto_id; ?></span></li>
                <li><strong>Cantidad:</strong> <span id="cantidad_resumen"></span></li>
                <li><strong>Precio Unitario:</strong> <?php echo $precio; ?></li>
                <li><strong>Total:</strong> <span id="total_resumen"></span></li>
                <li><strong>Tipo de Documento:</strong> <span id="tipo_documento_resumen"></span></li>
                <li><strong>Número de Documento:</strong> <span id="numero_documento_resumen"></span></li>
                <li><strong>Teléfono:</strong> <span id="telefono_resumen"></span></li>
                <li><strong>Dirección:</strong> <span id="direccion_resumen"></span></li>
                <li><strong>Método de Pago:</strong> <span id="metodo_pago_resumen"></span></li>
                <li><strong>Número de Pago:</strong> <span id="numero_pago_resumen"></span></li>
            </ul>

            <button type="submit" class="mt-4 w-full bg-green-600 text-white font-bold p-3 rounded-md hover:bg-green-500 transition">Enviar Pedido</button>

            <button type="button" onclick="mostrarSegundaParte()" class="mt-2 w-full bg-gray-600 font-semibold p-3 rounded-md hover:bg-gray-500 transition">Atrás</button>
        </div>
    </form>

    <!-- Detalles del Producto -->
    <div class="w-full max-w-sm bg-transparent border border-gray-300 rounded-lg p-4 shadow-lg">
        <h3 class="text-3xl font-semibold mb-2 text-gray-900 text-center">Detalles del Producto</h3>
        <img src="/SneakFlow/public/vistas/img/<?php echo $imagen_producto; ?>" alt="<?php echo $nombre_producto; ?>" class="w-full h-auto rounded-md mb-3 shadow-md border border-gray-200">
        
        <div class="space-y-2">
            <div class="flex items-center">
                <span class="arrow"></span>
                <p class="text-lg text-gray-800"><strong>Nombre:</strong> <span class="font-medium text-gray-900"><?php echo $nombre_producto; ?></span></p>
            </div>
            <div class="flex items-center">
                <span class="arrow"></span>
                <p class="text-lg text-gray-800"><strong>Precio:</strong> <span class="font-medium text-gray-900"><?php echo $precio; ?></span></p>
            </div>
            <div class="flex items-center">
                <span class="arrow"></span>
                <p class="text-lg text-gray-800"><strong>Talla:</strong> <span class="font-medium text-gray-900"><?php echo $nombre_talla; ?></span></p>
            </div>
        </div>
    </div>
</div>



<script>

function mostrarTerceraParte() {
    // Obtiene los datos de la segunda parte y los muestra en la tercera parte
    const cantidad = document.getElementById('cantidad').value;
    const precio = <?php echo json_encode($precio); ?>; // Obtiene el precio desde PHP

    document.getElementById('cantidad_resumen').innerText = cantidad;
    document.getElementById('total_resumen').innerText = (cantidad * precio).toFixed(2); // Calcula el total aquí
    
    const total = parseFloat(document.getElementById('cantidad').value) * parseFloat(document.getElementsByName('precio')[0].value);
    document.getElementById('total').value = total; // Establece el valor del total en el campo oculto

    document.getElementById('tipo_documento_resumen').innerText = document.getElementById('tipo_documento').value;
    document.getElementById('numero_documento_resumen').innerText = document.getElementById('numero_documento').value;
    document.getElementById('telefono_resumen').innerText = document.getElementById('telefono').value;
    document.getElementById('direccion_resumen').innerText = document.getElementById('direccion').value;
    document.getElementById('metodo_pago_resumen').innerText = document.getElementById('metodo_pago').value;
    document.getElementById('numero_pago_resumen').innerText = document.getElementById('numero_pago').value;

    // Muestra la tercera parte y oculta la segunda
    document.getElementById('parte2').style.display = 'none';
    document.getElementById('parte3').style.display = 'block';
}

document.getElementById('pedido-form').addEventListener('submit', function(e) {
    e.preventDefault(); // Evita el envío predeterminado

    // Obtener el valor de cantidad y multiplicar
    const cantidadInput = document.getElementById('cantidad');
    const cantidad = parseInt(cantidadInput.value);

    // Ajustar la cantidad si es necesario (cambiar 2 por cualquier multiplicador)
    cantidadInput.value = cantidad * 2; // Cambia esto según tu lógica

    // Ahora enviar el formulario
    this.submit(); // Envía el formulario
});
</script>

<script src="/SneakFlow/public/vistas/js/pedido.js"></script> <!-- Script de productos marcas -->

<?php require_once '../public/vistas/footer.php'; ?>
