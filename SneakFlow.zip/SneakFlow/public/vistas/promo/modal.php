
<div id="popup" class="hidden inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50" onclick="cerrarPopup(event)">
    <div class="bg-white rounded-3xl shadow-2xl p-6 w-5/6 md:w-3/4 lg:w-2/3 xl:w-1/2 relative max-h-screen overflow-y-auto border border-gray-200" onclick="event.stopPropagation();"> <!-- Agrega stopPropagation aquí -->
        <button 
            onclick="cerrarPopup(event)" 
            class="absolute top-3 right-3 bg-transparent text-gray-500 hover:text-gray-700 text-3xl transition-transform transform hover:scale-125 duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-opacity-50" 
            aria-label="Cerrar"
        >
            &times;
        </button>
        
        <div class="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-6">
            <div class="md:w-1/2">
                <img id="popupImagen" src="" alt="" class="w-full h-64 object-cover rounded-md mb-3 border border-gray-300 shadow-sm">
                
                <!-- Sección para seleccionar talla debajo de la imagen -->
                <div class="mt-4 mb-4 px-3 py-2 bg-gray-100 rounded-md shadow-inner border border-gray-200">
                    <h3 class="text-md font-semibold text-gray-800 mb-2">Tallas Disponibles:</h3>
                    <select id="tallaSelect" class="w-full py-2 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400">
                        <?php foreach ($producto['tallas_assoc'] as $tallaId => $talla): ?>
                            <option value="<?php echo htmlspecialchars($tallaId); ?>">
                                <?php echo htmlspecialchars($talla['nombre']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="md:ml-4 flex-1">
                <h3 id="popupNombre" class="text-2xl font-semibold text-gray-800 mb-3 border-b pb-2 border-gray-300 text-center">Producto</h3>
                <p id="popupDescripcion" class="text-gray-700 text-sm"></p>
                
                <span id="verMasBtnContainer" class="inline" style="display: none; "> 
                    <button id="verMasBtn" class="text-blue-500 text-sm" onclick="verMas()">Ver más</button>
                    <button id="verMenosBtn" class="text-blue-500 text-sm hidden" onclick="verMenos()">Ver menos</button>
                </span>
                
                <div class="flex flex-col mb-2 mt-4 p-3 bg-gray-50 rounded-md shadow-inner border border-gray-200">
                    <table class="w-full border-collapse border border-gray-300 text-center">
                        <tbody>
                            <tr>
                                <td class="bg-gray-100 text-gray-800 font-bold text-sm py-2 border-b-2 border-gray-400">Género</td>
                                <td class="bg-gray-100 text-gray-800 font-bold text-sm py-2 border-b-2 border-gray-400">Marca</td>
                            </tr>
                            <tr>
                                <td id="popupGenero" class="text-gray-900 font-medium text-sm py-2 border border-gray-300"></td>
                                <td id="popupMarca" class="text-gray-900 font-medium text-sm py-2 border border-gray-300"></td>
                            </tr>

                            <tr>
                                <td class="bg-gray-100 text-gray-800 font-bold text-sm py-2 border-b-2 border-gray-400">Colores</td>
                                <td class="bg-gray-100 text-gray-800 font-bold text-sm py-2 border-b-2 border-gray-400">Precio</td>
                            </tr>
                            <tr>
                                <td id="popupColores" class="text-gray-900 font-medium text-sm py-2 border border-gray-300"></td>
                                <td id="popupPrecio" class="text-gray-900 font-medium text-sm py-2 border border-gray-300"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <form action="enviarDatosProm" method="post" class="comprar-form flex-1">
                    <input type="hidden" name="cantidad" value="2">
                    <input type="hidden" name="producto_id" value="<?php echo htmlspecialchars($producto['id']); ?>">
                    <input type="hidden" name="precio" value="<?php echo htmlspecialchars($producto["precio"]); ?>">
                    <input type="hidden" name="nombre_producto" id="nombre_producto" value="<?php echo htmlspecialchars($producto['nombre']); ?>">
                    <input type="hidden" name="talla_id" id="tallaId">
                    <input type="hidden" name="imagen" value="<?php echo htmlspecialchars($producto['imagen']); ?>"> <!-- Campo oculto para la imagen -->
                    <input type="hidden" name="marca" value="<?php echo htmlspecialchars($producto['marca_nombre']); ?>"> <!-- Campo oculto para la marca -->
                    
                    <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded-full hover:bg-blue-600 transition-transform transform hover:scale-105 w-full font-semibold shadow">Comprar</button>
                </form>  
            </div>
        </div>
    </div>
</div>
