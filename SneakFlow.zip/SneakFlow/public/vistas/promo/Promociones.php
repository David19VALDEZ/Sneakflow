<?php 
require_once '../public/vistas/header.php';

?>
<link rel="stylesheet" href="/SneakFlow/public/vistas/css/promo.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">

<div class="banner mt-16">
    <div class="overlay"></div> <!-- Capa de superposición -->
    <div class="banner-content">
        <h2 class="text-2xl font-bold">¡Grandes Ofertas Este Fin de Semana!</h2>
        <p>Compra uno y llévate el segundo a mitad de precio en toda la tienda. ¡No te lo pierdas!</p>
        <br>
        <a href="#productos" class="cta-button">¡Compra Ahora!</a> <!-- Botón de llamada a la acción -->
    </div>
</div>

<p class="text-center text-lg text-gray-600 mt-10 mb-4 ml-10 mr-10">
    Aprovecha nuestras ofertas especiales y lleva el doble de estilo con nuestras promociones 2x1. ¡No te lo pierdas!
    Además, contamos con una amplia selección de zapatillas deportivas, casuales y de lujo que se adaptan a cada estilo y ocasión. 
    No dejes pasar la oportunidad de renovar tu guardarropa y lucir a la moda. Ven y descubre nuestras novedades y disfruta de un 
    ambiente amigable y profesional. ¡Te esperamos!
</p>

<div id="productos" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 px-4">
    <?php if (!empty($productos)): ?> <!-- Cambiar de productosEnPromocion a productos -->
        <?php foreach ($productos as $producto): ?>
            <div class="producto bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow relative overflow-hidden">
                <div class="relative cursor-pointer" onclick="abrirPopup('<?php echo htmlspecialchars(json_encode($producto)); ?>')"><?php include "modal.php"; ?>

                    <img src="/SneakFlow/public/vistas/img/<?php echo htmlspecialchars($producto['imagen']); ?>" alt="<?php echo htmlspecialchars($producto['nombre']); ?>" class="w-full h-72 object-cover rounded-t-lg hover:scale-105 transition-transform duration-300">

                    <div class="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/4 bg-red-500 text-white p-2 rounded-md border-2 border-yellow-300 shadow-md" style="width: 120px; text-align: center;">
                        <span class="font-bold text-lg">¡2x1!</span>
                    </div>
                </div>
                <div class="p-4">
                    <h3 class="text-xl font-semibold text-gray-800"><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                    <p class="text-gray-500 mb-1">$<?php echo htmlspecialchars($producto['precio']); ?></p>
                    <p class="text-gray-700 mb-4" id="descripcion-<?php echo $producto['id']; ?>">
                        <?php 
                        $descripcion = htmlspecialchars($producto['descripcion']);
                        $palabras = explode(' ', $descripcion);
                        $longitudDescripcion = count($palabras);
                        $mostrarResumen = $longitudDescripcion > 27; // Check if description is longer than 27 words
                        if ($mostrarResumen) {
                            echo implode(' ', array_slice($palabras, 0, 27)); // Show only the first 27 words without ellipsis
                        } else {
                            echo $descripcion;
                        }
                        ?>
                    </p>

                    <form action="enviarDatosProm" method="post" onsubmit="return validarTallaSeleccionada()" class="comprar-form flex-1">
                        <!-- Select de tallas oculto por defecto -->
                        <h3 class="text-md font-semibold text-gray-800 hidden" id="tallasLabel-<?php echo $producto['id']; ?>">Tallas Disponibles:</h3>
                        <select 
                            class="mb-4 hidden bg-white border border-gray-300 w-full rounded-lg p-2 shadow-sm focus:outline-none focus:ring focus:ring-blue-300 transition-colors duration-200"
                            name="talla" 
                            id="tallaSelect-<?php echo $producto['id']; ?>">
                            <?php foreach ($producto['tallas_assoc'] as $tallaId => $talla): ?>
                                <option value="<?php echo htmlspecialchars($tallaId); ?>">
                                    <?php echo htmlspecialchars($talla['nombre']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                        <!-- Campos ocultos para enviar datos del producto -->
                        <input type="hidden" name="cantidad" value="2">
                        <input type="hidden" name="producto_id" value="<?php echo htmlspecialchars($producto['id']); ?>">
                        <input type="hidden" name="precio" value="<?php echo htmlspecialchars($producto["precio"]); ?>">
                        <input type="hidden" name="nombre_producto" id="nombre_producto" value="<?php echo htmlspecialchars($producto['nombre']); ?>">
                        <input type="hidden" name="talla_id" id="tallaId-<?php echo $producto['id']; ?>">
                        <input type="hidden" name="imagen" value="<?php echo htmlspecialchars($producto['imagen']); ?>"> <!-- Campo oculto para la imagen -->

                        <!-- Botón de compra -->
                        <button type="button" onclick="gestionarCompra(<?php echo $producto['id']; ?>)" class="bg-blue-600 text-white py-2 px-4 rounded-full hover:bg-blue-700 transition-colors w-full font-medium" id="botonComprar-<?php echo $producto['id']; ?>">Comprar</button>
                    </form>

                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p class="text-center text-gray-600">No hay productos en promoción 2x1.</p>
    <?php endif; ?>
</div>

<script src="/SneakFlow/public/vistas/js/promocion.js"></script>

<?php require_once '../public/vistas/footer.php'; ?>
