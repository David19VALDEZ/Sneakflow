<div class="products-preview grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
    <?php foreach ($productosDetalles as $producto): ?>
        <div class="preview bg-white rounded-lg shadow-lg overflow-hidden relative" data-target="p-<?php echo htmlspecialchars($producto['id']); ?>">
            <i class="fas fa-times absolute top-2 right-2 text-gray-600 cursor-pointer" onclick="closePreview()"></i>
            <div class="preview-image">
            <img src="/SneakFlow/public/vistas/img/<?php echo htmlspecialchars($producto['imagen']); ?>" alt="<?php echo htmlspecialchars($producto['nombre']); ?>" class="w-full h-auto object-cover">
            <?php if (!empty($producto['tallas_assoc'])): ?>
                    <div class="filtro-tallas mt-2">
                        <label class="block text-lg font-semibold text-black mb-3 tracking-wide"></label>
                        <table id="tallas-table-<?php echo htmlspecialchars($producto['id']); ?>" class="w-full border border-gray-200 rounded-lg shadow-md transition-transform duration-300 hover:scale-105">
                            <tbody class="divide-y divide-gray-300">
                                <?php
                                $count = 0;
                                $columns = 5; // Número de columnas deseadas
                                foreach ($producto['tallas_assoc'] as $id => $talla): 
                                    $isAgotada = ($talla['cantidad'] <= 0) ? 'agotada' : '';
                                    if ($count % $columns === 0): ?>
                                        <tr>
                                            <?php endif; ?>
                                            <td class="py-1 px-2 text-center <?php echo $isAgotada; ?>">
                                                <div class="talla-row w-full h-full cursor-pointer py-0.5 px-2 bg-white text-black font-medium rounded-md shadow-sm 
                                                            transition-transform duration-300 ease-in-out 
                                                            hover:scale-105 hover:shadow-md hover:text-blue-600
                                                            <?php echo $isAgotada; ?>"
                                                    data-talla-id="<?php echo htmlspecialchars($id); ?>" 
                                                    data-cantidad="<?php echo htmlspecialchars($talla['cantidad']); ?>"
                                                    onclick="<?php echo $isAgotada ? 'return false;' : 'selectTalla(this, \'' . htmlspecialchars($producto['id']) . '\')'; ?>">
                                                    <?php echo htmlspecialchars($talla['talla']); ?>
                                                </div>
                                            </td>
                                    <?php if ($count % $columns === $columns - 1): ?>
                                        </tr>
                                    <?php endif; ?>
                                    <?php $count++; ?>
                                <?php endforeach; ?>
                                <!-- Completa la última fila si es necesario -->
                                <?php if ($count % $columns !== 0): ?>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-red-600 font-medium">No hay tallas disponibles para este producto.</p>
                <?php endif; ?>
            </div>

            <div class="info">
                <h3 class="text-2xl font-bold"><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                <?php 
                    $descripcion = htmlspecialchars($producto['descripcion']);
                    $descripcion_resumida = substr($descripcion, 0, 120);
                    $mostrar_ver_mas = str_word_count($producto['descripcion']) > 20;
                ?>

                <p class="text-gray-700 short-description" 
                id="desc-<?php echo htmlspecialchars($producto['id']); ?>" 
                data-full-description="<?php echo $descripcion; ?>">
                    <?php echo $descripcion_resumida; ?>
                    <?php if ($mostrar_ver_mas): ?>
                        ... <a href="#" class="text-blue-500 cursor-pointer ver-mas" data-producto-id="<?php echo htmlspecialchars($producto['id']); ?>">Ver Más</a>
                    <?php endif; ?>
                </p>
                <!-- Tabla de características del producto -->
                <div class="features overflow-x-auto">
                    <table class="min-w-full bg-white rounded-lg shadow-md custom-table">
                        <thead class="bg-blue-600">
                            <tr>
                                <th colspan="4" class="features-title text-lg font-semibold text-gray-900 p-3 text-center bg-gray-200">Características</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="hover:bg-blue-50">
                                <th class="py-3 px-5 text-gray-600 text-left">Marca</th>
                                <td class="py-3 px-5 text-center text-gray-800 shadow-md" data-label="Marca"><?php echo htmlspecialchars($producto['marca']); ?></td>
                                <th class="py-3 px-5 text-gray-600 text-left">Género</th>
                                <td class="py-3 px-5 text-center text-gray-800 shadow-md" data-label="Género"><?php echo htmlspecialchars($producto['genero']); ?></td>
                            </tr>
                            <tr class="hover:bg-blue-50">
                                <th class="py-3 px-5 text-gray-600 text-left">Color</th>
                                <td class="py-3 px-5 text-center text-gray-800 shadow-md" data-label="Color"><?php echo htmlspecialchars($producto['color']); ?></td>
                                <th class="py-3 px-5 text-gray-600 text-left">Descuento</th>
                                <td class="py-3 px-5 text-center text-gray-800 shadow-md" data-label="Descuento">
                                    <?php echo $producto['descuento'] > 0 ? htmlspecialchars($producto['descuento']) . "%" : "No aplica"; ?>
                                </td>
                            </tr>
                            <tr class="hover:bg-blue-50">
                                <th class="py-3 px-5 text-gray-600 text-left">Precio</th>
                                <td class="py-3 px-5 text-center text-gray-800 shadow-md" data-label="Precio">
                                    <?php 
                                        if ($producto['descuento'] !== '0') {
                                            $descuento = floatval($producto['descuento']) / 100;
                                            $precioConDescuento = $producto['precio'] * (1 - $descuento);
                                            echo "$" . htmlspecialchars(number_format($precioConDescuento, 2));
                                        } else {
                                            echo "$" . htmlspecialchars($producto['precio']);
                                        }
                                    ?>
                                </td>
                                <th class="py-3 px-5 text-gray-600 text-left">Talla Seleccionada</th>
                                <td class="py-3 px-5 text-center text-gray-800 shadow-md" data-label="Talla Seleccionada">
                                    <div id="selected-talla-display-<?php echo htmlspecialchars($producto['id']); ?>" class="py-2 px-4 rounded-lg text-center text-gray-800 shadow-md">Ninguna</div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="cantidad-container mt-2">
                    <label for="cantidad-<?php echo htmlspecialchars($producto['id']); ?>" class="text-lg font-semibold text-gray-800 mr-4 flex-shrink-0 transition-all duration-300 hover:translate-x-1 hover:text-blue-500">
                        Cantidad:
                    </label>
                    <input type="number" id="cantidad-<?php echo htmlspecialchars($producto['id']); ?>" min="1" value="1"
                        class="w-16 p-1 text-md text-center border border-gray-300 rounded bg-white text-gray-800 font-medium shadow-inner focus:outline-none focus:ring-2 focus:ring-gray-300 transition-all duration-300 ease-[cubic-bezier(0.65, 0, 0.35, 1)] hover:scale-105 hover:border-gray-400" max="1"
                        oninput="actualizarCantidad(<?php echo htmlspecialchars($producto['id']); ?>)">
                </div>
                <div class="mt-3">
                    <div class="flex justify-between">
                        <!-- Formulario para agregar al carrito -->
                        <form action="agregar-al-carrito" method="post" id="carrito-form-<?php echo htmlspecialchars($producto['id']); ?>" class="carrito-form flex-1 mr-2">
                            <input type="hidden" name="producto_id" value="<?php echo htmlspecialchars($producto['id']); ?>">
                            <input type="hidden" id="cantidad-carrito-<?php echo htmlspecialchars($producto['id']); ?>" name="cantidad" value="1">
                            <input type="hidden" id="talla-<?php echo htmlspecialchars($producto['id']); ?>" name="talla_id" value="">
                            <button type="submit" class="w-full px-3 py-1 bg-gradient-to-r from-green-500 to-green-700 text-white font-medium rounded-md shadow transform transition duration-300 hover:scale-105 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-offset-1 flex items-center justify-center">
                                <i class='bx bx-cart text-white mr-1'></i> <!-- Icono de carrito -->
                                Añadir al carrito
                            </button>
                        </form>

                        <!-- Formulario para agregar a favoritos -->
                        <form action="agregar-favorito" method="post" class="favorito-form flex-1" id="favorito-form-<?php echo $producto['id']; ?>">
                            <input type="hidden" name="producto_id" value="<?php echo $producto['id']; ?>">
                            <button type="submit" class="w-full px-3 py-1 bg-gradient-to-r from-green-500 to-green-700 text-white font-medium rounded-md shadow transform transition duration-300 hover:scale-105 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-offset-1 flex items-center justify-center">
                                <i class='bx bx-heart text-white mr-1'></i> <!-- Icono de favoritos -->
                                Añadir a Favoritos
                            </button>
                        </form>
                    </div>

                    <!-- Formulario para comprar ahora -->
                    <div class="flex justify-between mt-3">
                        <form action="EnviarDatos" method="post" class="comprar-form flex-1">
                            <input type="hidden" name="producto_id" value="<?php echo htmlspecialchars($producto['id']); ?>">
                            <input type="hidden" id="talla-pedido-<?php echo htmlspecialchars($producto['id']); ?>" name="talla_id" value="">
                            <input type="hidden" id="cantidad-comprar-<?php echo htmlspecialchars($producto['id']); ?>" name="cantidad" value="1">
                            
                            <?php
                                $precio = $producto['precio'];
                                $descuento = $producto['descuento'];
                                
                                if ($descuento !== "0") {
                                    // Calcular el precio con descuento
                                    $precioConDescuento = $precio * (1 - $descuento / 100);
                                    ?>
                                    <input type="hidden" name="precio" value="<?php echo htmlspecialchars($precioConDescuento); ?>"> <!-- Campo oculto para el precio con descuento -->
                                    <?php
                                } else {
                                    ?>
                                    <input type="hidden" name="precio" value="<?php echo htmlspecialchars($precio); ?>"> <!-- Campo oculto para el precio original -->
                                    <?php
                                }
                            ?>
                            
                            <input type="hidden" name="precio" value="<?php echo htmlspecialchars($precioConDescuento); ?>"> <!-- Enviar el precio con descuento -->
                            <input type="hidden" name="nombre_producto" value="<?php echo htmlspecialchars($producto['nombre']); ?>"> <!-- Nombre del producto -->

                            <button type="submit" class="w-full px-3 py-1 bg-gradient-to-r from-blue-500 to-blue-700 text-white font-medium rounded-md shadow transform transition duration-300 hover:scale-105 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-1 flex items-center justify-center">
                                <i class='bx bx-cart text-white mr-1'></i> <!-- Icono de carrito -->
                                Realizar Pedido
                            </button>
                        </form>
                    </div>

                </div>

                <div id="message-<?php echo htmlspecialchars($producto['id']); ?>" class="mt-3"></div>

            </div>

        </div>
    <?php endforeach; ?>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Maneja el envío de todos los formularios con la clase 'carrito-form'
        $('.carrito-form').on('submit', function(event) {
            event.preventDefault(); // Evita el envío tradicional del formulario

            var form = $(this);
            var formData = form.serialize(); // Serializa los datos del formulario
            var productId = form.find('input[name="producto_id"]').val(); // Obtén el ID del producto
            var messageDiv = $('#message-' + productId); // Selecciona el contenedor de mensajes específico

            $.ajax({
                url: 'http://localhost/SneakFlow/public/agregar-al-carrito', 
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(data) {
                    var messageHtml = `<div class='p-2 ${data.status === 'success' ? 'bg-green-200 text-green-800 border-green-400' : 'bg-red-200 text-red-800 border-red-400'} rounded'>${data.message}</div>`;
                    messageDiv.html(messageHtml);
                    
                    if (data.status === 'success') {
                        // Actualiza el contador del carrito en el menú
                        $('#cart-count').text(data.cart_count); // Asegúrate de que esto contenga el nuevo conteo
                        $('#cart-count').css('display', data.cart_count > 0 ? 'flex' : 'none'); // Mostrar u ocultar el contador
                    }

                    // Configura un temporizador para ocultar el mensaje después de 2 segundos
                    setTimeout(function() {
                        messageDiv.empty(); // Vacía el contenido del contenedor de mensajes
                    }, 2000);
                },
                error: function() {
                    var messageHtml = `<div class='p-2 bg-red-200 text-red-800 border-red-400 rounded'>Error al procesar la solicitud.</div>`;
                    messageDiv.html(messageHtml);
                    
                    // Configura un temporizador para ocultar el mensaje después de 2 segundos
                    setTimeout(function() {
                        messageDiv.empty(); // Vacía el contenido del contenedor de mensajes
                    }, 2000);
                }
            });
        });

        // Maneja el envío de todos los formularios con la clase 'favorito-form'
        $('.favorito-form').on('submit', function(event) {
            event.preventDefault(); // Evita el envío tradicional del formulario

            var form = $(this);
            var formData = form.serialize(); // Serializa los datos del formulario
            var productId = form.find('input[name="producto_id"]').val(); // Obtén el ID del producto
            var messageDiv = $('#message-' + productId); // Selecciona el contenedor de mensajes específico

            $.ajax({
                url: 'http://localhost/SneakFlow/public/agregar-favorito',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(data) {
                    var messageHtml = `<div class='p-2 ${data.status === 'success' ? 'bg-green-200 text-green-800 border-green-400' : data.status === 'info' ? 'bg-yellow-200 text-yellow-800 border-yellow-400' : 'bg-red-200 text-red-800 border-red-400'} rounded'>${data.message}</div>`;
                    messageDiv.html(messageHtml);
                    
                    if (data.status === 'success') {
                        // Actualiza el contador de favoritos en el menú
                        $('#fav-count').text(data.fav_count);
                        $('#fav-count').css('display', data.fav_count > 0 ? 'flex' : 'none');
                    }

                    // Configura un temporizador para ocultar el mensaje después de 2 segundos
                    setTimeout(function() {
                        messageDiv.empty(); // Vacía el contenido del contenedor de mensajes
                    }, 2000);
                },
                error: function() {
                    var messageHtml = `<div class='p-2 bg-red-200 text-red-800 border-red-400 rounded'>Error al procesar la solicitud.</div>`;
                    messageDiv.html(messageHtml);
                    
                    // Configura un temporizador para ocultar el mensaje después de 2 segundos
                    setTimeout(function() {
                        messageDiv.empty(); // Vacía el contenido del contenedor de mensajes
                    }, 2000);
                }
            });
        });
    });
</script>
