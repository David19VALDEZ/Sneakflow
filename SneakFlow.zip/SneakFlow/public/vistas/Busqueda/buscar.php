<?php require_once '../public/vistas/header.php'; // Incluir el encabezado de la página ?>
<link rel="stylesheet" href="/SneakFlow/public/vistas/css/productos.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">
<style>
    .product-card {
        position: relative;
    }

    .discount-tag {
        position: absolute;
        top: 10px;
        background-color: rgba(255, 0, 0, 0.8); /* Color de fondo de la etiqueta */
        color: white;
        font-weight: bold;
        padding: 5px 10px;
        border-radius: 5px;
        opacity: 0; /* Invisible por defecto */
        transition: opacity 0.3s ease; /* Transición para suavizar la aparición */
    }

    .product-card:hover .discount-tag {
        opacity: 1; /* Mostrar cuando se pasa el ratón por encima */
    }
</style>

<div class="container mx-auto px-4 py-20">

    <?php if (!empty($resultados)): // Verificar si hay resultados disponibles ?>
        <h2 class="text-5xl font-extrabold text-center mb-4 mt-20"> <!-- Título de la sección -->
            <span class="relative inline-block">
                <span class="absolute inset-0 rounded-lg  opacity-60"></span>
                <span class="relative text-black font-extrabold tracking-wide uppercase">Resultados</span>
            </span>
        </h2> 
        <!-- Descripción de la página -->
        <p class="text-gray-700 text-lg mb-6">
            Explora nuestra selección exclusiva de productos de calzado. Aquí encontrarás las últimas tendencias, descuentos imperdibles y una variedad de estilos que se adaptan a cada personalidad. ¡Descubre tu próximo par de sneakers hoy!
        </p>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"> <!-- Contenedor para los productos -->
            <?php foreach ($resultados as $producto): // Iterar sobre cada producto ?>
                <div class="bg-white shadow-md rounded-xl overflow-hidden hover:shadow-lg relative product-card">
                    <div class="h-48 overflow-hidden rounded-t-xl"> <!-- Contenedor para la imagen del producto -->
                        <img src="/SneakFlow/public/vistas/img/<?php echo htmlspecialchars($producto['imagen']); ?>" 
                            alt="<?php echo htmlspecialchars($producto['nombre']); ?>" 
                            class="w-full h-full object-cover"
                        > <!-- Imagen del producto -->
                        
                        <!-- Etiqueta de descuento -->
                        <?php if (!empty($producto['descuento']) && $producto['descuento'] > 0): ?>
                            <?php 
                                $precioOriginal = $producto['precio'];
                                $precioConDescuento = $precioOriginal - ($precioOriginal * $producto['descuento'] / 100);
                            ?>
                            <span class="discount-tag">-<?php echo $producto['descuento']; ?>%</span>
                        <?php endif; ?>
                    </div>

                    <div class="p-6"> <!-- Contenedor para el contenido del producto -->
                        <h3 class="text-xl font-bold text-gray-800 mb-2 tracking-tight">
                            <?php echo htmlspecialchars($producto['nombre']); ?>
                        </h3> <!-- Nombre del producto -->
                        <p class="text-gray-600 text-sm leading-relaxed">
                            <?php 
                                $descripcion = explode(' ', $producto['descripcion']); // Separar la descripción en palabras
                                echo implode(' ', array_slice($descripcion, 0, 21)) . (count($descripcion) > 21 ? '...' : ''); // Mostrar las primeras 21 palabras
                            ?>
                        </p>
                        <div class="mt-6 flex justify-center"> <!-- Botón para ver más -->
                            <button type="button" class="bg-gradient-to-r from-blue-500 to-blue-700 text-white px-5 py-2 rounded-full font-semibold shadow-lg" data-id="p-<?php echo htmlspecialchars($producto['id']); ?>" onclick="toggleProductPreview('p-<?php echo htmlspecialchars($producto['id']); ?>')">Ver detalles</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; // Fin de la iteración sobre los productos ?>
        </div>
    <?php else: // Si no hay resultados ?>
        <h2 class="text-2xl font-semibold text-red-500 text-center mt-12">No hay resultados.</h2> <!-- Mensaje cuando no hay resultados -->
    <?php endif; ?>
</div>

<?php include 'info.php'; ?>

<script src="/SneakFlow/public/vistas/js/producto.js"></script>

<?php require_once '../public/vistas/footer.php'; // Incluir el pie de página ?>
