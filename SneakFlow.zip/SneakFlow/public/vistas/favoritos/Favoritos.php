<?php 
    // Incluir archivo para mostrar alertas de eliminación
    include 'alertas/eliminar.php'; 
    // Incluir el encabezado de la página
    require_once '../public/vistas/header.php'; 
?>

<!-- Incluir Tailwind CSS desde CDN para estilos -->
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@3.2.0/dist/tailwind.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<link rel="stylesheet" href="/SneakFlow/public/vistas/css/favoritos.css">
<link rel="stylesheet" href="/SneakFlow/public/vistas/css/productos.css">
<br><br>

<div class="container mx-auto p-6 rounded-lg shadow-2xl backdrop-blur-sm">
    <!-- Título de la sección de favoritos -->
    <h1 class="text-center text-white text-4xl font-extrabold tracking-wide mb-8">Tu colección de favoritos</h1>
    
    <div class="grid grid-cols-1 gap-2">
        <!-- Verifica si hay productos en la lista de favoritos -->
        <?php if (!empty($productosDetalles)): ?>
            <!-- Agrupar los productos en filas de 3 -->
            <?php foreach (array_chunk($productosDetalles, 3) as $filaProductos): ?>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <!-- Iterar sobre cada producto en la fila -->
                    <?php foreach ($filaProductos as $producto): ?>
                        <div class="card-container bg-black bg-opacity-50 rounded-lg p-4">
                            <div class="card-header">
                                <!-- Nombre del producto -->
                                <h5><?php echo htmlspecialchars($producto['nombre']); ?></h5>
                            </div>
                            <!-- Imagen del producto -->
                            <img src="/SneakFlow/public/vistas/img/<?php echo htmlspecialchars($producto['imagen']); ?>" class="w-full h-48 object-cover rounded-lg transition-transform duration-300 hover:scale-105" alt="<?php echo htmlspecialchars($producto['nombre']); ?>">
                            <div class="card-content mt-4">
                                <!-- Descripción del producto -->
                                <?php
                                $descripcion = $producto['descripcion'] ?? 'Descripción no disponible por el momento.';
                                $palabras = explode(' ', $descripcion);
                                $descripcion_limitada = implode(' ', array_slice($palabras, 0, 32)) . (count($palabras) > 32 ? '...' : '');
                                ?>
                                <p><?php echo htmlspecialchars($descripcion_limitada); ?></p>
                                <!-- Precio del producto -->
                                <!-- Cálculo del precio con descuento si aplica -->
                                <?php 
                                    $precioOriginal = $producto['precio'];
                                    $precioConDescuento = $precioOriginal;
                                    if (!empty($producto['descuento']) && $producto['descuento'] > 0) {
                                        $precioConDescuento = $precioOriginal - ($precioOriginal * $producto['descuento'] / 100);
                                    }
                                ?>

                                <!-- Mostrar el precio -->
                                <p class="price mt-2">
                                    <?php if ($precioConDescuento < $precioOriginal): ?>
                                        <span class="line-through text-gray-400">$<?php echo htmlspecialchars(number_format($precioOriginal, 2)); ?></span>
                                        <span class="text-red-500 font-semibold ml-2">$<?php echo htmlspecialchars(number_format($precioConDescuento, 2)); ?></span>
                                    <?php else: ?>
                                        $<?php echo htmlspecialchars(number_format($precioOriginal, 2)); ?>
                                    <?php endif; ?>
                                </p>                            </div>
                            <div class="card-footer flex justify-center gap-3 mt-4">
                                <!-- Botón para ver detalles del producto -->
                                <button type="button" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-500 transition duration-300" data-id="p-<?php echo htmlspecialchars($producto['id']); ?>" onclick="toggleProductPreview('p-<?php echo htmlspecialchars($producto['id']); ?>')">Ver detalles</button>

                                <!-- Formulario para eliminar el producto de favoritos -->
                                <form action="eliminar-favorito" method="post" class="inline-block">
                                    <input type="hidden" name="producto_id" value="<?php echo htmlspecialchars($producto['id']); ?>">
                                    <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-500 transition duration-300">Eliminar</button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
            
            <!-- Botón para eliminar todos los productos de favoritos -->
            <div class="text-center mb-6 mt-4">
                <form action="eliminar-todos-favoritos" method="post" class="inline-block">
                    <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-500 transition duration-300">
                        Eliminar todos los productos
                    </button>
                </form>
            </div>

        <?php else: ?>
            <!-- Mensaje cuando no hay productos en favoritos -->
            <div class="container mx-auto p-4 empty-cart text-center">
                <img src="/SneakFlow/public/vistas/img/Adidas.jpg" alt="Favoritos vacíos" class="img-fluid mx-auto mb-4" >
                <h1 class="text-white text-2xl font-bold mb-3">Tu lista de favoritos está vacía</h1>
                <p class="text-gray-300 mb-4">Parece que no has agregado ningún producto a tus favoritos. ¡Explora nuestra tienda y encuentra lo que te encanta!</p>
                <a href="/SneakFlow/public/productos" class="btn-glow">Ver productos</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Incluir detalles del producto -->
<?php include_once 'ver.php'; ?> 
<!-- Script de favoritos -->
<script src="/SneakFlow/public/vistas/js/favoritos.js"></script>
<!-- Incluir el footer -->
<?php require_once '../public/vistas/footer.php'; ?> 
