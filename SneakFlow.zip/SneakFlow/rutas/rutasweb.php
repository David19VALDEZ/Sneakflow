<?php
    use Libreria\Enrutador;

    require_once '../configuracion/conexionBD.php'; // Asegúrate de que la ruta sea correcta

    // Rutas para la página de inicio y autenticación
    Enrutador::get('/', [InicioControlador::class, 'mostrarInicio']); // Página principal del sitio
    Enrutador::get('inicio', [InicioControlador::class, 'mostrarInicio']); // Página de inicio
    Enrutador::get('login', [PaginaControlador::class, 'login']); // Página de inicio de sesión
    Enrutador::get('Recuperar_Contrasena', [PaginaControlador::class, 'recuperarContrasena']); // Página de recuperación de contraseña
    Enrutador::get('Nueva_contrasena', [PaginaControlador::class, 'actualizarContraseña']); // Página para actualizar la contraseña

    // Rutas para la página de productos
    Enrutador::get('productos', [PaginaControlador::class, 'Productos']); // Muestra todos los productos
    Enrutador::get('marca', [MarcaControlador::class, 'mostrarProductosPorMarca']); // Muestra productos filtrados por marca específica

    // Rutas para el perfil del usuario
    Enrutador::get('perfil', [PerfilControlador::class, 'mostrarPerfil']); // Muestra el perfil del usuario
    Enrutador::post('actualizarPerfil', [PerfilControlador::class, 'actualizarPerfil']); // Actualiza los datos del perfil del usuario

    // Ruta para cerrar sesión
    Enrutador::get('logout', [UsuarioControlador::class, 'logout']); // Cierra la sesión del usuario

    // Rutas para gestionar usuarios
    Enrutador::post('registrar', [UsuarioControlador::class, 'registrar']); // Registra un nuevo usuario
    Enrutador::post('login', [UsuarioControlador::class, 'login']); // Inicia sesión del usuario
    Enrutador::post('enviar-enlace', [RecuperarControlador::class, 'enviarEnlace']); // Envía el enlace de recuperación de contraseña
    Enrutador::post('actualizarContrasena', [RecuperarControlador::class, 'actualizarContrasena']); // Actualiza la contraseña del usuario

    // Rutas para el carrito de compras
    Enrutador::get('Carrito', [CarritoControlador::class, 'mostrarCarrito']); // Muestra el carrito de compras
    Enrutador::post('agregar-al-carrito', [CarritoControlador::class, 'agregarAlCarrito']); // Agrega un producto al carrito
    Enrutador::post('editar-carrito', [CarritoControlador::class, 'actualizarCarrito']); // Edita productos en el carrito
    Enrutador::post('actualizar-carrito', [CarritoControlador::class, 'actualizarCarrito']); // Actualiza el carrito (posiblemente redundante)
    Enrutador::post('eliminar-carrito', [CarritoControlador::class, 'eliminarDelCarrito']); // Elimina un producto del carrito
    Enrutador::post('eliminar-todo-carrito', [CarritoControlador::class, 'eliminarTodoCarrito']); // Vacia el carrito completamente

    // Rutas para productos favoritos
    Enrutador::get('Favoritos', [FavoritoControlador::class, 'mostrarFavoritos']); // Muestra productos favoritos
    Enrutador::post('agregar-favorito', [FavoritoControlador::class, 'agregarFavoritos']); // Agrega un producto a favoritos
    Enrutador::post('eliminar-favorito', [FavoritoControlador::class, 'eliminarFavorito']); // Elimina un producto de favoritos
    Enrutador::post('eliminar-todos-favoritos', [FavoritoControlador::class, 'eliminarTodosFavoritos']); // Elimina todos los productos de favoritos

    // Rutas para promociones
    Enrutador::get('Promociones', [PromocionControlador::class, 'mostrarPromociones']); // Muestra las promociones activas

    // Rutas de contacto
    Enrutador::get('Contactenos', [ContactoControlador::class, 'contacto']); // Muestra la página de contacto
    Enrutador::post('enviar-contacto', [ContactoControlador::class, 'enviarEmail']); // Envía el formulario de contacto por correo

    // Rutas para buscar productos
    Enrutador::get('buscar', [BuscarControlador::class, 'buscarProductos']); // Página de búsqueda de productos
    Enrutador::post('buscar', [BuscarControlador::class, 'buscarProductos']); // Realiza la búsqueda de productos

    // Rutas de pedidos
    Enrutador::get('Confirmar-Pedido', [PaginaControlador::class, 'formulario_pedido']); // Formulario de compra de productos
    Enrutador::get('Confirmar-PedidoC', [PaginaControlador::class, 'Formulario_Pedido_Carrito']); // Formulario de compra de carrito
    Enrutador::get('Confirmar-Pedido-Prom', [PaginaControlador::class, 'Formulario_Pedido_Promocion']); // Formulario de compra de promociones
    Enrutador::post('EnviarDatos', [PedidoControlador::class, 'EnviarDatos']); // Envío de datos de compra
    Enrutador::post('EnviarDatosCart', [PedidoControlador::class, 'enviarDC']); // Envío de datos de compra desde el carrito
    Enrutador::post('enviarDatosProm', [PedidoControlador::class, 'enviarDatosProm']); // Envío de datos de compra de promociones
    Enrutador::post('RealizarPedido', [PedidoControlador::class, 'RealizarPedido']); // Procesa la compra
    Enrutador::post('RealizarPedidoC', [PedidoControlador::class, 'RealizarPedidoC']); // Procesa la compra desde el carrito

    // Rutas para administradores

    // Gestión de productos por administradores
    Enrutador::get('Administrar-Productos', [PaginaControlador::class, 'admin']); // Panel de control de productos
    Enrutador::get('Crear-Producto', [PaginaControlador::class, 'loginProducto']); // Formulario de creación de producto
    Enrutador::post('Crear-Producto', [ProductoControlador::class, 'crearProducto']); // Crea un nuevo producto
    Enrutador::post('Editar-Producto', [ProductoControlador::class, 'EditarProduct']); // Edita un producto existente
    Enrutador::post('NuevaTalla', [TallaControlador::class, 'agregarTalla']); // Agrega una nueva talla de producto
    Enrutador::post('editarTalla', [TallaControlador::class, 'editarTalla']); // Edita una talla existente
    Enrutador::post('eliminar-Producto', [ProductoControlador::class, 'DeleteProduct']); // Elimina un producto

    // Registro y gestión de administradores
    Enrutador::get('Login-Admin', [PaginaControlador::class, 'registrarAdmin']); // Página de inicio de sesión del admin
    Enrutador::post('registroAdmin', [UsuarioControlador::class, 'registrarAdmin']); // Registro de un nuevo admin

    // Gestión de usuarios por administradores
    Enrutador::get('Administrar-Usuarios', [UsuarioControlador::class, 'mostrarUsuarios']); // Muestra todos los usuarios
    Enrutador::post('Editar-Usuarios', [UsuarioControlador::class, 'editarUsuario']); // Edita información de un usuario
    Enrutador::post('Eliminar-Usuario', [UsuarioControlador::class, 'eliminarUsuario']); // Elimina un usuario

    // Gestión de repartidores
    Enrutador::get('Formulario-de-Repartidor', [PaginaControlador::class, 'Repartidores']); // Formulario para gestionar repartidores
    Enrutador::post('agrgarRepartidor', [RepartidorControlador::class, 'CrearRepartidor']); // Crea un nuevo repartidor

    // Gestión de pedidos
    Enrutador::get('Administrar-Pedidos', [PedidoControlador::class, 'administrarPedido']); // Panel de administración de pedidos
    Enrutador::post('Eliminar-Pedido', [PedidoControlador::class, 'EliminarPedido']); // Elimina un pedido
    Enrutador::post('ActualizarEstado', [PedidoControlador::class, 'ActualizarEstado']); // Actualiza el estado de un pedido

?>
