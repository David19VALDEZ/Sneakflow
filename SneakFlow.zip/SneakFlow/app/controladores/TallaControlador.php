<?php 
    require_once __DIR__ . '/../modelos/TallaModelo.php'; 

    class TallaControlador {
        private $tallaModelo;

        public function __construct() {
            $this->tallaModelo = new TallaModelo();
        }

        // Método para manejar la adición de una nueva talla
        public function agregarTalla() {
            // Verifica si se recibieron los datos del formulario
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                // Obtener los datos del formulario
                $producto_id = $_POST['producto_id'] ?? null;
                $talla = $_POST['talla'] ?? null;
                $cantidad = $_POST['cantidad'] ?? null;

                // Validar los datos
                if ($producto_id && $talla && is_numeric($cantidad) && $cantidad >= 0) {
                    // Agregar la nueva talla utilizando el modelo
                    $resultado = $this->tallaModelo->agregarTalla($producto_id, $talla, $cantidad);

                    if ($resultado) {
                        // Redirigir o mostrar un mensaje de éxito
                        header('Location: Administrar-Productos'); // Cambia esto a la página deseada
                        exit();
                    } else {
                        // Manejar el error al agregar la talla
                        echo "Error al agregar la talla. Inténtalo de nuevo.";
                    }
                } else {
                    echo "Por favor, completa todos los campos correctamente.";
                }
            }
        }

        public function editarTalla() {
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $producto_id = $_POST['producto_id'];
                $tallas = $_POST['tallas'];
                $cantidades = $_POST['cantidades'];
    
                foreach ($tallas as $tallaId => $talla) {
                    $cantidad = $cantidades[$tallaId];
                    $this->tallaModelo->actualizarTalla($tallaId, $producto_id, $talla, $cantidad);
                }
    
                // Redirigir o mostrar mensaje de éxito
                header('Location: Administrar-Productos'); // Cambia esto por la ruta correcta
                exit();
            }
        }
    }

?>