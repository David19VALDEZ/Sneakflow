<?php
    require_once __DIR__ . '/../modelos/ProductoModelo.php'; 
    require_once __DIR__ . '/../../configuracion/conexionBD.php'; // Incluir el archivo de conexión a la base de datos
    require_once __DIR__ . '/../modelos/PedidoModelo.php'; // Asegúrate de tener el modelo para pedidos
    require_once __DIR__ . '/../modelos/DetallePedidoModelo.php'; // Asegúrate de tener el modelo para detalles del pedido
    require_once __DIR__ . '/../modelos/UsuarioModelo.php'; // Asegúrate de tener el modelo para usuarios
    require_once __DIR__ . '/../modelos/CarritoModelo.php'; // Asegúrate de tener el modelo para usuarios

    session_start();

    class PedidoControlador {
        private $pedidoModelo;
        private $detallePedidoModelo;
        private $usuarioModelo;
        private $carritoModelo;
        private $db; // Variable para almacenar la conexión a la base de datos

        public function __construct() {
            $this->pedidoModelo = new PedidoModelo(); // Crea una instancia del modelo de perfil
            $this->detallePedidoModelo = new DetallePedidoModelo();
            $this->usuarioModelo = new UsuarioModelo();
            $this->carritoModelo = new CarritoModelo();
            $conexionBD = new ConexionBD();
            $this->db = $conexionBD->getConnection();
        }

         public function administrarPedido() {
    
            // Obtener todos los pedidos
            $pedidos = $this->pedidoModelo->obtenerTodosLosPedidos();
    
            include '../public/vistas_admin/Administrar_Ped/Admin-Pedido.php';
        }


        public function RealizarPedido() {
            // Verificar que se han enviado los datos del formulario
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                // Obtener datos del pedido
                $usuario_id = htmlspecialchars($_POST['usuario_id']);
                $producto_id = htmlspecialchars($_POST['producto_id']);
                $talla_id = htmlspecialchars($_POST['talla_id']);
                $cantidad = htmlspecialchars($_POST['cantidad']);
                $precio = htmlspecialchars($_POST['precio']);
                $total = htmlspecialchars($_POST['total']);
                $tipo_documento = htmlspecialchars($_POST['tipo_documento']);
                $numero_documento = htmlspecialchars($_POST['numero_documento']);
                $telefono = htmlspecialchars($_POST['telefono']);
                $direccion = htmlspecialchars($_POST['direccion']);
                $metodo_pago = htmlspecialchars($_POST['metodo_pago']);
                $numero_pago = htmlspecialchars($_POST['numero_pago']);
                
                // Iniciar una transacción para asegurar la integridad de los datos
                $this->db->begin_transaction();
        
                try {
                    // Crear el pedido
                    $pedido_id = $this->pedidoModelo->crearPedido($usuario_id, $total);
            
                    // Crear detalles del pedido
                    $this->detallePedidoModelo->crearDetallePedido($pedido_id, $producto_id, $talla_id, $cantidad, $precio, $metodo_pago, $numero_pago);
                    
                    // Actualizar los datos del usuario
                    $this->usuarioModelo->ActualizarUsuario($usuario_id, $tipo_documento, $numero_documento, $telefono, $direccion); // Asegúrate de pasar el $usuario_id
                    
                    // Seleccionar un repartidor con menos de 5 pedidos activos
                    $repartidor = $this->db->query("SELECT id FROM repartidores WHERE pedidos_activos < 5 ORDER BY pedidos_activos ASC LIMIT 1");
        
                    if ($repartidor->num_rows > 0) {
                        // Obtener el ID del repartidor
                        $repartidor_id = $repartidor->fetch_assoc()['id'];
                        
                        // Asignar el repartidor al pedido y actualizar el estado a 'procesado'
                        $this->db->query("UPDATE pedidos SET repartidor_id = '$repartidor_id', estado = 'procesado' WHERE id = '$pedido_id'");
                        
                        // Actualizar la cantidad de pedidos activos del repartidor
                        $this->db->query("UPDATE repartidores SET pedidos_activos = pedidos_activos + 1 WHERE id = '$repartidor_id'");
                    } else {
                        // No hay repartidores disponibles, dejar el estado del pedido en 'pendiente'
                        $this->db->query("UPDATE pedidos SET estado = 'pendiente' WHERE id = '$pedido_id'");
                    }
                    
                    // Confirmar la transacción
                    $this->db->commit();
        
                    // Guardar mensaje de éxito en sesión
                    $_SESSION['mensaje'] = [
                        'tipo' => 'success',
                        'texto' => 'Pedido realizado con éxito.'
                    ];
                } catch (Exception $e) {
                    // Si hay un error, revertir la transacción
                    $this->db->rollback();
        
                    // Guardar mensaje de error en sesión
                    $_SESSION['mensaje'] = [
                        'tipo' => 'error',
                        'texto' => 'Error al realizar el pedido: ' . addslashes($e->getMessage())
                    ];
                }
        
                // Redireccionar a la página desde donde se envió el formulario
                if (isset($_SERVER['HTTP_REFERER'])) {
                    header("Location: " . $_SERVER['HTTP_REFERER']);
                } else {
                    header("Location: productos"); // Redirigir a una página por defecto si no hay HTTP_REFERER
                }
        
                exit();
            }
        }
        
        public function RealizarPedidoC() {
            // Verificar que se han enviado los datos del formulario
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                
                // Obtener los datos del formulario
                $usuario_id = htmlspecialchars($_POST['usuario_id']);
                $tipo_documento = htmlspecialchars($_POST['tipo_documento']);
                $numero_documento = htmlspecialchars($_POST['numero_documento']);
                $telefono = htmlspecialchars($_POST['telefono']);
                $direccion = htmlspecialchars($_POST['direccion']);
                $metodo_pago = htmlspecialchars($_POST['metodo_pago']);
                $numero_pago = htmlspecialchars($_POST['numero_pago']);
                
                // Obtener los arrays de productos
                $producto_ids = $_POST['producto_id']; // Array de ids de productos
                $talla_ids = $_POST['talla_id']; // Array de ids de tallas
                $cantidades = $_POST['cantidad']; // Array de cantidades
                $precios = $_POST['precio']; // Array de precios
        
                // Inicializar el total del pedido
                $total = 0;
                
                // Calcular el total del pedido recorriendo los productos
                foreach ($producto_ids as $index => $producto_id) {
                    $talla_id = htmlspecialchars($talla_ids[$index]);
                    $cantidad = (int) htmlspecialchars($cantidades[$index]);
                    $precio = (float) htmlspecialchars($precios[$index]);
            
                    // Calcular el total acumulado
                    $total += $cantidad * $precio;
        
                    // Crear el pedido (este se debe hacer después de calcular el total)
                    $pedido_id = $this->pedidoModelo->crearPedido($usuario_id, $total);
        
                    // Crear los detalles del pedido
                    $this->detallePedidoModelo->crearDetallePedido($pedido_id, $producto_id, $talla_id, $cantidad, $precio, $metodo_pago, $numero_pago);
                }
        
                // Iniciar una transacción para asegurar la integridad de los datos
                $this->db->begin_transaction();
                
                try {
                    // Crear el pedido
                    $pedido_id = $this->pedidoModelo->crearPedido($usuario_id, $total);
                    
                    // Crear detalles del pedido (ya fue hecho dentro del foreach, ahora solo hacemos el pedido)
                    // ...
        
                    // Actualizar los datos del usuario
                    $this->usuarioModelo->ActualizarUsuario($usuario_id, $tipo_documento, $numero_documento, $telefono, $direccion);
                
                    // Seleccionar un repartidor con menos de 5 pedidos activos
                    $repartidor = $this->db->query("SELECT id FROM repartidores WHERE pedidos_activos < 5 ORDER BY pedidos_activos ASC LIMIT 1");
        
                    if ($repartidor->num_rows > 0) {
                        // Obtener el ID del repartidor
                        $repartidor_id = $repartidor->fetch_assoc()['id'];
                        
                        // Asignar el repartidor al pedido y actualizar el estado a 'procesado'
                        $this->db->query("UPDATE pedidos SET repartidor_id = '$repartidor_id', estado = 'procesado' WHERE id = '$pedido_id'");
                        
                        // Actualizar la cantidad de pedidos activos del repartidor
                        $this->db->query("UPDATE repartidores SET pedidos_activos = pedidos_activos + 1 WHERE id = '$repartidor_id'");
                    } else {
                        // No hay repartidores disponibles, dejar el estado del pedido en 'pendiente'
                        $this->db->query("UPDATE pedidos SET estado = 'pendiente' WHERE id = '$pedido_id'");
                    }
        
                    // Eliminar los productos del carrito del usuario
                    foreach ($producto_ids as $index => $producto_id) {
                        $talla_id = htmlspecialchars($talla_ids[$index]);
                        $this->carritoModelo->eliminarDelCarrito($usuario_id, $producto_id, $talla_id);
                    }
        
                    if (is_array($cantidades)) {
                        $_SESSION['cart_count'] = max(0, $_SESSION['cart_count'] - array_sum($cantidades));
                    } else {
                        // Si no es un array, asigna un valor por defecto o maneja el error según lo necesario
                        $_SESSION['cart_count'] = max(0, $_SESSION['cart_count'] - 0); // 0 en este caso
                    }
                    
        
                    // Confirmar la transacción
                    $this->db->commit();
        
                    // Guardar mensaje de éxito en sesión
                    $_SESSION['mensaje'] = [
                        'tipo' => 'success',
                        'texto' => 'Pedido realizado con éxito.'
                    ];
                } catch (Exception $e) {
                    // Si hay un error, revertir la transacción
                    $this->db->rollback();
        
                    // Guardar mensaje de error en sesión
                    $_SESSION['mensaje'] = [
                        'tipo' => 'error',
                        'texto' => 'Error al realizar el pedido: ' . addslashes($e->getMessage())
                    ];
                }
        
                // Redireccionar a la página desde donde se envió el formulario
                if (isset($_SERVER['HTTP_REFERER'])) {
                    header("Location: " . $_SERVER['HTTP_REFERER']);
                } else {
                    header("Location: productos"); // Redirigir a una página por defecto si no hay HTTP_REFERER
                }
        
                exit();
            }
        }

        public function enviarDatos() {
            if (!isset($_SESSION['id'])) {
                echo "<script>alert('Debes iniciar sesión para realizar un pedido.'); window.history.back();</script>";
                return;
            }
        
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $errores = [];
            
                // Validación del ID del producto
                if (empty($_POST['producto_id']) || !is_numeric($_POST['producto_id'])) {
                    $errores['producto_id'] = "El ID del producto es requerido y debe ser un número.";
                }
            
                // Validación de la talla
                if (empty($_POST['talla_id'])) {
                    $errores['talla_id'] = "La talla es requerida.";
                }
            
                // Validación de la cantidad
                if (empty($_POST['cantidad']) || !is_numeric($_POST['cantidad']) || $_POST['cantidad'] <= 0) {
                    $errores['cantidad'] = "La cantidad debe ser un número positivo.";
                }
            
                // Validación del precio
                if (empty($_POST['precio']) || !is_numeric($_POST['precio']) || $_POST['precio'] <= 0) {
                    $errores['precio'] = "El precio debe ser un número positivo.";
                }
            
                // Validación del nombre del producto
                if (empty($_POST['nombre_producto'])) {
                    $errores['nombre_producto'] = "El nombre del producto es requerido.";
                }
            
                // Si hay errores, los guardamos en sesión y mostramos alertas
                if (!empty($errores)) {
                    $_SESSION['errores'] = $errores;
                    echo '<script>';
                        foreach ($errores as $error) {
                            echo "alert('¡Error! " . addslashes($error) . "');";
                        }
                        echo "window.history.back();";
                    echo '</script>';
                    exit();
                }
            
                // Si no hay errores, guarda los datos en la sesión
                $_SESSION['pedido'] = [
                    'producto_id' => htmlspecialchars($_POST['producto_id']),
                    'talla' => htmlspecialchars($_POST['talla_id']),
                    'cantidad' => htmlspecialchars($_POST['cantidad']),
                    'precio' => htmlspecialchars($_POST['precio']),
                    'nombre_producto' => htmlspecialchars($_POST['nombre_producto']),
                    'usuario_id' => $_SESSION['id'], // Guardar el ID de la sesión
                ];
        
                // Obtiene la talla
                $talla_id = $_SESSION['pedido']['talla'];
                $tallas = $this->pedidoModelo->obtenerTallaPorId($talla_id);
        
                if ($tallas) {
                    $_SESSION['pedido']['nombre_talla'] = htmlspecialchars($tallas['talla']); 
                    header("Location: Confirmar-Pedido");
                    exit();
                } else {
                    echo "<script>alert('Talla no encontrada.'); window.history.back();</script>";
                    return;
                }
            }
        }

        public function enviarDc() {
            if (!isset($_SESSION['id'])) {
                echo "<script>alert('Debes iniciar sesión para realizar un pedido.'); window.history.back();</script>";
                return;
            }
        
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $errores = [];
                $productos = $_POST['productos']; // Aquí estamos obteniendo el array de productos
        
                // Validación de cada producto
                foreach ($productos as $producto) {
                    // Validación del ID del producto
                    if (empty($producto['producto_id']) || !is_numeric($producto['producto_id'])) {
                        $errores['producto_id'] = "El ID del producto es requerido y debe ser un número.";
                    }
        
                    // Validación de la talla
                    if (empty($producto['talla_id'])) {
                        $errores['talla_id'] = "La talla es requerida.";
                    }
        
                    // Validación de la cantidad
                    if (empty($producto['cantidad']) || !is_numeric($producto['cantidad']) || $producto['cantidad'] <= 0) {
                        $errores['cantidad'] = "La cantidad debe ser un número positivo.";
                    }
        
                    // Validación del precio
                    if (empty($producto['precio']) || !is_numeric($producto['precio']) || $producto['precio'] <= 0) {
                        $errores['precio'] = "El precio debe ser un número positivo.";
                    }
        
                    // Validación del nombre del producto
                    if (empty($producto['nombre_producto'])) {
                        $errores['nombre_producto'] = "El nombre del producto es requerido.";
                    }
                }
        
                // Si hay errores, mostrar alertas y detener la ejecución
                if (!empty($errores)) {
                    $_SESSION['errores'] = $errores;
                    echo '<script>';
                        foreach ($errores as $error) {
                            echo "alert('¡Error! " . addslashes($error) . "');";
                        }
                        echo "window.history.back();";
                    echo '</script>';
                    exit();
                }
        
                // Si no hay errores, guarda los datos en la sesión
                $_SESSION['pedido'] = $productos; // Guardamos el array de productos en la sesión
        
                // Redirige a la página de confirmación
                header("Location: Confirmar-PedidoC");
                exit();
            }
        }
        

        public function enviarDatosProm() {
            if (!isset($_SESSION['id'])) {
                echo "<script>alert('Debes iniciar sesión para realizar un pedido.'); window.history.back();</script>";
                return;
            }
        
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $errores = [];
            
                // Validación del ID del producto
                if (empty($_POST['producto_id']) || !is_numeric($_POST['producto_id'])) {
                    $errores['producto_id'] = "El ID del producto es requerido y debe ser un número.";
                }
            
                // Validación de la talla
                if (empty($_POST['talla_id'])) {
                    $errores['talla_id'] = "La talla es requerida.";
                }
            
                // Validación de la cantidad
                if (empty($_POST['cantidad']) || !is_numeric($_POST['cantidad']) || $_POST['cantidad'] <= 0) {
                    $errores['cantidad'] = "La cantidad debe ser un número positivo.";
                }
            
                // Validación del precio
                if (empty($_POST['precio']) || !is_numeric($_POST['precio']) || $_POST['precio'] <= 0) {
                    $errores['precio'] = "El precio debe ser un número positivo.";
                }
            
                // Validación del nombre del producto
                if (empty($_POST['nombre_producto'])) {
                    $errores['nombre_producto'] = "El nombre del producto es requerido.";
                }
            
                // Si hay errores, los guardamos en sesión y mostramos alertas
                if (!empty($errores)) {
                    $_SESSION['errores'] = $errores;
                    echo '<script>';
                        foreach ($errores as $error) {
                            echo "alert('¡Error! " . addslashes($error) . "');";
                        }
                        echo "window.history.back();";
                    echo '</script>';
                    exit();
                }
            
                // Si no hay errores, guarda los datos en la sesión
                $_SESSION['pedido'] = [
                    'producto_id' => htmlspecialchars($_POST['producto_id']),
                    'talla' => htmlspecialchars($_POST['talla_id']),
                    'cantidad' => htmlspecialchars($_POST['cantidad']),
                    'precio' => htmlspecialchars($_POST['precio']),
                    'nombre_producto' => htmlspecialchars($_POST['nombre_producto']),
                    'imagen' => htmlspecialchars($_POST["imagen"]),
                    'marca' => htmlspecialchars($_POST['marca']),
                    'usuario_id' => $_SESSION['id'], // Guardar el ID de la sesión
                ];
        
                // Obtiene la talla
                $talla_id = $_SESSION['pedido']['talla'];
                $tallas = $this->pedidoModelo->obtenerTallaPorId($talla_id);
        
                if ($tallas) {
                    $_SESSION['pedido']['nombre_talla'] = htmlspecialchars($tallas['talla']); 
                    header("Location: Confirmar-Pedido-Prom");
                    exit();
                } else {
                    echo "<script>alert('Talla no encontrada.'); window.history.back();</script>";
                    return;
                }
            }
        }

        public function ActualizarEstado() {
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                // Sanitizar y validar la entrada
                $id = filter_var($_POST['pedido_id'], FILTER_VALIDATE_INT);
                $nuevo_estado = $_POST['nuevo_estado']; // El nuevo estado que se quiere establecer
                
                // Verificar si el ID es válido
                if ($id !== false && in_array($nuevo_estado, ['entregado', 'otro_estado_que_desees'])) {
                    // Llamar al modelo para actualizar el estado del pedido
                    $resultado = $this->pedidoModelo->actualizarEstadoPedido($id, $nuevo_estado);
                    
                    // Verificar si la actualización fue exitosa
                    if ($resultado) {
                        $_SESSION['mensaje'] = [
                            'tipo' => 'success',
                            'texto' => 'El estado del pedido ha sido actualizado a ' . htmlspecialchars($nuevo_estado) . '.'
                        ];
                    } else {
                        $_SESSION['mensaje'] = [
                            'tipo' => 'error',
                            'texto' => 'Hubo un problema al actualizar el estado del pedido.'
                        ];
                    }
                } else {
                    $_SESSION['mensaje'] = [
                        'tipo' => 'error',
                        'texto' => 'El ID de pedido proporcionado no es válido.'
                    ];
                }
        
                // Redireccionar a la página anterior
                header("Location: " . $_SERVER['HTTP_REFERER']);
                exit();
            }
        }
        
        

        public function EliminarPedido() {
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                // Sanitizar y validar la entrada (asumiendo que es un entero)
                $id = filter_var($_POST['pedido_id'], FILTER_VALIDATE_INT);
                
                // Verificar si el ID es válido
                if ($id !== false) {
                    // Llamar al modelo para cancelar el pedido
                    $resultado = $this->pedidoModelo->CancelarPedido($id);
                    
                    // Verificar si la cancelación fue exitosa
                    if ($resultado) {
                        // Éxito: Mostrar mensaje y redirigir
                        echo "<script>alert('El pedido ha sido cancelado con éxito.');</script>";
                        echo "<script>window.location.href = document.referrer;</script>"; // Retorna a la página anterior
                    } else {
                        // Fallo: Manejar el error
                        echo "<script>alert('Hubo un problema al cancelar el pedido. Por favor, inténtalo de nuevo.');</script>";
                        echo "<script>window.location.href = document.referrer;</script>"; // Retorna a la página anterior
                    }
                } else {
                    // Manejar ID no válido
                    echo "<script>alert('El ID de pedido proporcionado no es válido.');</script>";
                    echo "<script>window.location.href = document.referrer;</script>"; // Retorna a la página anterior
                }
            }
        }
        
    }
