<?php

require_once __DIR__ . '/../../configuracion/conexionBD.php'; // Incluye el archivo de configuración para la conexión a la base de datos
require_once __DIR__ . '/../modelos/UsuarioModelo.php'; // Incluye el modelo de usuario para interactuar con la base de datos
require_once __DIR__ . '/../modelos/CarritoModelo.php'; // Incluye el modelo de carrito para interactuar con la base de datos
require_once __DIR__ . '/../modelos/FavoritoModelo.php'; // Incluye el modelo de favoritos

session_start(); // Inicia la sesión al principio del archivo

class UsuarioControlador {

    // Modelo para gestionar la información del usuario
    private $usuarioModelo;

    // Modelo para gestionar las operaciones del carrito de compras
    private $carritoModelo;

    // Modelo para gestionar los productos marcados como favoritos
    private $favoritoModelo;

    public function __construct() {
        $this->usuarioModelo = new UsuarioModelo(); // Crea una instancia del modelo de usuario
        $this->carritoModelo = new CarritoModelo(); // Crea una instancia del modelo de carrito
        $this->favoritoModelo = new FavoritoModelo(); // Crea una instancia del modelo de favoritos
    }

    public function mostrarUsuarios() {
        // Obtener todos los usuarios desde el modelo
        $usuarios = $this->usuarioModelo->obtenerTodosLosUsuarios();
    
        // Pasar los usuarios a la vista
        $datos = [
            'usuarios' => $usuarios
        ];
    
        // Renderiza la vista y pasa los datos
        include '../public/vistas_admin/Administrar-U/Admin_Usuarios.php';
    }

    // Maneja el inicio de sesión del usuario
    public function login() {
        // Sanitiza la entrada del usuario
        $usuario = filter_var($_POST['usuario'], FILTER_SANITIZE_EMAIL);
        $contrasena = $_POST['contraseña'];

        // Obtiene los datos del usuario del modelo
        $datos_usuario = $this->usuarioModelo->obtenerUsuarioPorNombre($usuario);

        // Verifica si el usuario existe y la contraseña es correcta
        if ($datos_usuario) {
            if (password_verify($contrasena, $datos_usuario["contrasena"])) {
                $_SESSION['id'] = $datos_usuario['id']; // Guarda el id del usuario en la sesión
                $_SESSION['usuario'] = $usuario; // Guarda el nombre de usuario en la sesión
                $_SESSION['rol'] = $datos_usuario['rol']; // Guarda el rol del usuario en la sesión

                // Calcula el total de productos en el carrito para este usuario desde la base de datos
                $_SESSION['cart_count'] = $this->carritoModelo->obtenerConteoCarrito($_SESSION['id']); // Usar el modelo de carrito
                $_SESSION['fav_count'] = $this->favoritoModelo->obtenerConteoFavoritos($_SESSION['id']); // Usar el modelo de favoritos

                // Redirige a la página de administración o inicio según el rol
                if ($_SESSION['rol'] === 'administrador') {
                    header("Location: Administrar-Productos");
                } else {
                    header("Location: inicio");
                }
                exit(); // Asegura que no se ejecute más código
            } else {
                echo '<script>
                        alert("Usuario y/o contraseña incorrectos");
                        window.location = "login"; 
                      </script>'; // Mensaje de error
            }
        } else {
            echo '<script>
                    alert("El usuario al que intentas acceder no existe");
                    window.location = "login"; 
                  </script>'; // Mensaje de error si no se encuentra el usuario
        }
    }
    
    // Maneja el registro de un nuevo usuario
    public function registrar() {
        // Sanitiza la entrada del usuario para evitar inyecciones de código
        $usuario = filter_var($_POST['username']);
        $correo = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL); // Sanitiza el correo electrónico
        $contraseña = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash de la contraseña para almacenamiento seguro
    
        // Verifica si el usuario o correo ya están registrados
        if ($this->usuarioModelo->verificarUsuarioExistente($usuario, $correo)) {
            echo '<script>
                    alert("El correo y/o usuario ya está registrado.");
                    window.location = "login"; 
                  </script>'; // Mensaje de error si el usuario ya existe
        } else {
            // Intenta registrar el nuevo usuario
            if ($this->usuarioModelo->registrarUsuario($usuario, $correo, $contraseña)) {
                echo '<script>
                        alert("Usuario registrado Exitosamente");
                        window.location = "login"; 
                      </script>'; // Mensaje de éxito si el registro fue exitoso
            } else {
                echo '<script>
                        alert("Error al registrar el usuario");
                        window.location = "login"; 
                      </script>'; // Mensaje de error si hubo un problema al registrar
            }
        }
    }

    public function registrarAdmin() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Obtener datos del formulario
            $usuario = filter_var($_POST['usuario']);
            $correo = filter_var($_POST['correo'], FILTER_SANITIZE_EMAIL);
            $tipo_documento = $_POST['tipo_documento'];
            $numero_documento = $_POST['numero_documento'];
            $telefono = filter_var($_POST['telefono']);
            $direccion = filter_var($_POST['direccion']);
            $contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
            $rol = filter_var($_POST['rol']);
    
            // Crear una instancia del modelo
            $usuarioModelo = new UsuarioModelo();
    
            // Verificar si el usuario o correo ya están registrados
            if ($usuarioModelo->verificarUsuarioExistente($usuario, $correo)) {
                echo '<script>
                        alert("El correo y/o usuario ya están registrados.");
                        window.location = "Login-Admin"; 
                      </script>'; // Mensaje de error si el usuario ya existe
            } else {
                // Intentar registrar el nuevo usuario
                if ($usuarioModelo->registrarUsuarioAdmin($usuario, $correo,$tipo_documento,$numero_documento, $telefono, $direccion, $contrasena, $rol)) {
                    echo '<script>
                            alert("Usuario registrado exitosamente.");
                            window.location = "Login-Admin"; 
                          </script>'; // Mensaje de éxito si el registro fue exitoso
                } else {
                    echo '<script>
                            alert("Error al registrar el usuario.");
                            window.location = "Login-Admin"; 
                          </script>'; // Mensaje de error si hubo un problema al registrar
                }
            }
        }
    }
    
    public function editarUsuario() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'];
            $usuario = $_POST['usuario'];
            $correo = $_POST['correo'];
            $tipo_documento = $_POST['tipo_documento'];
            $numero_documento = $_POST['numero_documento'];
            $telefono = $_POST['telefono'];
            $direccion = $_POST['direccion'];

            $resultado = $this->usuarioModelo->editarUsuario($id, $usuario, $correo, $tipo_documento,$numero_documento, $telefono, $direccion);
            if ($resultado) {
                echo '<script>
                        alert("Usuario Actualizado exitosamente.");
                        window.location = "Administrar-Usuarios"; 
                      </script>'; // Mensaje de éxito si la edición fue exitosa
                exit();
            } else {
                echo '<script>
                        alert("Error al editar el usuario.");
                        window.location = "Administrar-Usuarios"; 
                      </script>'; // Mensaje de error
            }
        }
    }
    
    public function eliminarUsuario() {
        $id = $_POST['id'] ?? null;

        if ($id) {
            $exito = $this->usuarioModelo->eliminarUsuario($id);
        
            // Si la eliminación fue exitosa
            if ($exito) {
                echo '<script>
                        alert("Usuario eliminado Exitosamente");
                        window.location = "Administrar-Usuarios"; 
                      </script>'; // Mensaje de éxito si la eliminación fue exitosa
            } else {
                echo '<script>
                        alert("El usuario ha sido eliminado");
                        window.location = "Administrar-Usuarios"; 
                      </script>'; // Mensaje de error si hubo un problema al eliminar
            }
        } else {
            echo '<script>
                    alert("Error el id no ha sido enviado");
                    window.location = "Administrar-Usuarios"; 
                  </script>'; // Mensaje de advertencia si no se envía el id
        }
    }
    
    // Maneja el cierre de sesión del usuario
    public function logout() {
        session_start(); // Inicia la sesión para poder acceder a las variables de sesión
        session_unset(); // Limpia todas las variables de sesión, eliminando datos del usuario
        session_destroy(); // Destruye la sesión actual, cerrando efectivamente la sesión del usuario
        header("Location: login"); // Redirige a la página de inicio de sesión
        exit(); // Asegura que no se ejecute más código después de la redirección
    }
}
?>
