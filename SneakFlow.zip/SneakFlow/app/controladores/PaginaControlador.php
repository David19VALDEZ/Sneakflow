<?php
    class PaginaControlador {

        // Método para mostrar la página de login
        public function login() {
            include '../public/vistas/Autentificacion/login.php';
        }

        // Método para mostrar la página de recuperación de contraseña
        public function recuperarContrasena() {
            include '../public/vistas/autentificacion/Recuperar_Contrasena.php'; // Ruta ajustada
        }

        // Método para mostrar la página para crear nueva contraseña
        public function actualizarContraseña() {
            include '../public/vistas/autentificacion/nueva_contrasena.php'; // Ruta ajustada
        }

        public function Productos() {
            include '../public/vistas/Productos/Productos.php';

        }
        
        public function Carrito() {
            include '../public/vistas/carrito/Carrito.php';
        }
        
        public function formulario_pedido() {
            include '../public/vistas/Pedido/pedido.php';
        }
       
        public function Formulario_Pedido_Carrito() {
            include '../public/vistas/Pedido/pedido-carrito.php';
        }

        public function Formulario_Pedido_promocion() {
            include '../public/vistas/Pedido/pedido-promocion.php';
        }
        public function admin() {
            include '../public/vistas_admin/Administrar-P/Admin-Productos.php';
        }

        public function administrarPedido() {
            include '../public/vistas_admin/Administrar_Ped/Admin-Pedido.php';
        }

        public function registrarAdmin() {
            include '../public/vistas_admin/Registrar_Ad/registro.php';
        }

        public function loginProducto() {
            include '../public/vistas_admin/Crear_Productos/CrearProducto.php';

        }

        public function Repartidores(){
            include '../public/vistas_admin/repartidor/registrarRepartidor.php';
        }

    }
    ?>
