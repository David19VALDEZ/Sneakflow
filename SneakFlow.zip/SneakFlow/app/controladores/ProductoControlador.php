<?php
    // Se incluye el archivo del modelo de productos
    require_once __DIR__ . '/../modelos/ProductoModelo.php'; 
    session_start(); // Inicia la sesión para mantener datos del usuario

    /**
    * Controlador para manejar las operaciones relacionadas con los productos.
    */
    class ProductoControlador {

        private $productoModelo; // Variable para almacenar la instancia del modelo de productos

        /**
        * Constructor de la clase. Inicializa el modelo de productos.
        */
        public function __construct() {
            // Crea una instancia del modelo de productos
            $this->productoModelo = new ProductoModelo(); 
        }

        /**
        * Muestra la página de productos con los productos filtrados y paginados.
        */
        public function mostrarProductos() {
            $filtros = $_GET; // Captura los filtros de búsqueda enviados por GET
            
            $productosPorPagina = 10; // Define el número de productos que se mostrarán por página
            $paginaActual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1; 
            $offset = ($paginaActual - 1) * $productosPorPagina;
        
            // Llama al modelo para obtener los productos filtrados y paginados
            $productos = $this->productoModelo->obtenerProductos($filtros, $productosPorPagina, $offset);
        
            // Obtener marcas, colores y tallas (si es necesario)
            $marcas = $this->productoModelo->obtenerMarcas();
            $colores = $this->productoModelo->obtenerColores();
            $tallas = $this->productoModelo->obtenerTallas();
        
            // Recorre los productos para asociar las tallas correspondientes
            foreach ($productos as $key => $producto) {
                $productoTallas = $this->productoModelo->obtenerTallasPorProducto($producto['id']);
                $productos[$key]['tallas_assoc'] = [];
        
                foreach ($productoTallas as $talla) {
                    $productos[$key]['tallas_assoc'][$talla['id']] = [
                        'nombre' => $talla['talla'], 
                        'cantidad' => $talla['cantidad'] 
                    ];
                }
            }
        
            // Contar productos para la paginación
            $totalProductos = $this->productoModelo->contarProductos($filtros);
            $totalPaginas = max(1, ceil($totalProductos / $productosPorPagina)); // Asegura al menos 1 página
        
            // Retorna los datos para la vista
            return [
                'productos' => $productos,
                'totalPaginas' => $totalPaginas,
                'paginaActual' => $paginaActual,
                'marcas' => $marcas,
                'colores' => $colores,
                'tallas' => $tallas,
            ];
        }

        public function crearProducto() {
            // Verificar si el método de la solicitud es POST
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                // Obtener y validar los datos del formulario
                $nombre = $_POST['nombre'] ?? null;
                $descripcion = $_POST['descripcion'] ?? null;
                $marca_id = $_POST['marca'] ?? null;
                $color_id = $_POST['color'] ?? null;
                $genero = $_POST['genero']   ?? null;
                $precio = $_POST['precio'] ?? null;
                $descuento = $_POST['descuento'] ?? null;
                $talla = $_POST['talla'] ?? null;
                $cantidad = $_POST['cantidad'] ?? null;
                $promocion = $_POST['promocion'] ?? null;
                $imagenes = $_FILES['imagenes'] ?? null;
    
                // Llamar al método del modelo para agregar el producto
                $productoId = $this->productoModelo->agregarProducto($nombre, $descripcion, $marca_id, $color_id, $genero, $precio, $descuento,$promocion, $imagenes, $talla, $cantidad);
                
                if ($productoId) {
                    // Redireccionar o mostrar un mensaje de éxito
                    header("Location: Crear-Producto"); // Ajusta según tu ruta
                    exit;
                } else {
                    // Manejar el error
                    echo "Error al agregar el producto.";
                }
            }
        }
        
        public function EditarProduct() {
            // Recibir los datos del formulario
            $id = $_POST['id'];
            $nombre = $_POST['nombre'] ?? null; 
            $descripcion = $_POST['descripcion'] ?? null;
            $marca_id = $_POST['marca_id']; // Obtener el ID de la marca
            $color_id = $_POST['color_id'];
            $genero = $_POST['genero'] ?? null;
            $precio = $_POST['precio'] ?? null;
            $descuento = $_POST['descuento'] ?? null;
            $tallas = $_POST['tallas'] ?? [];
            $promocion = $_POST['promocion'] ?? null;
            $cantidades = $_POST['cantidades'] ?? [];
            $imagen = $_POST['imagen'] ?? [];
            
            // Lógica para actualizar el producto
            $resultado = $this->productoModelo->actualizarProducto($id, $nombre, $descripcion, $marca_id, $color_id, $genero, $precio, $descuento,$promocion, $imagen);
            
            // Actualizar las tallas y cantidades
            if ($resultado) {
                foreach ($tallas as $talla) {
                    // Obtener la cantidad correspondiente a la talla
                    $cantidad = $cantidades[$talla] ?? null; 
                    
                    // Si la cantidad no se pasó, obtener la cantidad actual de la base de datos
                    if ($cantidad === null || $cantidad === '') {
                        $cantidadActual = $this->productoModelo->obtenerCantidadPorTalla($id, $talla);
                        if ($cantidadActual !== false) {
                            $cantidad = $cantidadActual; // Mantener la cantidad actual
                        }
                    }
        
                    // Solo actualizar si la cantidad es numérica y válida (0 o mayor)
                    if (is_numeric($cantidad) && $cantidad >= 0) {
                        $resultado = $this->productoModelo->actualizarCantidadYtalla($id, $talla, $cantidad);
                    }
                }
            } else {
                echo "Error al actualizar el producto. Verifica el ID de la marca.";
            }
        
            // Redirigir a la lista de productos o mostrar un mensaje
            header('Location: Administrar-Productos'); // Cambia esto por la ruta correcta
            exit();
        }
        
        
        public function DeleteProduct() {
            // Verificamos si el método de solicitud es POST
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $id = $_POST['producto_id'] ?? null; // Obtenemos el ID del producto, o null si no está definido
                if ($id) {
                    // Intentamos eliminar el producto
                    $exito = $this->productoModelo->eliminarProducto($id);
        
                    // Si la eliminación fue exitosa
                    if ($exito) {
                        // Almacenamos un mensaje de éxito en la sesión
                        $_SESSION['mensaje'] = [
                            'texto' => '¡El producto ha sido eliminado! ¡Nos vemos pronto!',
                            'tipo' => 'success'
                        ];
                    } else {
                        // Si hubo un error al eliminar el producto, almacenamos un mensaje de error
                        $_SESSION['mensaje'] = [
                            'texto' => '¡Error al eliminar el producto! Inténtalo de nuevo.',
                            'tipo' => 'error'
                        ];
                    }
                } else {
                    // Si los datos son inválidos, almacenamos un mensaje de advertencia
                    $_SESSION['mensaje'] = [
                        'texto' => '¡Datos inválidos! Asegúrate de que estás enviando el id.',
                        'tipo' => 'warning'
                    ];
                }
        
                // Redirigir a la página de productos
                header('Location: Administrar-Productos'); // Ajusta la ruta según tu estructura
                exit();
            }
        }
        
    }        
?>
