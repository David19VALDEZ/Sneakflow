<?php 
require_once __DIR__ . '/../modelos/RepartidorModelo.php'; 

class RepartidorControlador {
    private $repartidorModelo;

    public function __construct() {
        $this->repartidorModelo = new RepartidorModelo();
    }

    public function CrearRepartidor() {
        // Iniciar sesión
        session_start();

        // Captura los datos del formulario
        $nombre = $_POST['nombre'];
        $contactoNombre = $_POST['contacto_nombre'];
        $contactoTelefono = $_POST['contacto_telefono'];
        $contactoEmail = $_POST['contacto_email'];
        $direccion = $_POST['direccion'];

        // Verificar si el repartidor ya existe
        if ($this->repartidorModelo->existeRepartidor($nombre)) {
            $_SESSION['mensaje'] = "Error: Ya existe un repartidor con ese nombre.";
            header("Location: " . $_SERVER['HTTP_REFERER']);
            exit();
        }

        // Llama al modelo para agregar el repartidor
        if ($this->repartidorModelo->agregarRepartidor($nombre, $contactoNombre, $contactoTelefono, $contactoEmail, $direccion)) {
            $_SESSION['mensaje'] = "Repartidor agregado exitosamente.";
        } else {
            $_SESSION['mensaje'] = "Error al agregar repartidor.";
        }

        // Redirigir a la misma página
        header("Location: " . $_SERVER['HTTP_REFERER']);
        exit();
    }
}
?>
