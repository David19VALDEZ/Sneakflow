<?php
require_once '../configuracion/conexionBD.php'; // Asegúrate de que la ruta sea correcta
require_once '../app/modelos/InicioModelo.php'; // Asegúrate de que la ruta sea correcta

class InicioControlador {
    private $modelo;

    public function __construct() {
        $conexion = new ConexionBD(); // Crea una nueva conexión
        $this->modelo = new InicioModelo();
    }

    public function mostrarInicio() {
        $mars = $this->modelo->obtenerMarcas();
        include '../public/vistas/inicio.php';
    }
}
?>
