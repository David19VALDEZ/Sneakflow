<?php
require_once __DIR__ . '/../modelos/PromocionesModelo.php';

class PromocionControlador {
    private $modelo;

    public function __construct() {
        $this->modelo = new PromocionModelo();
    }

    public function mostrarPromociones() {
        $productosEnPromocion = $this->modelo->obtenerProductosEnPromocion();
        $productos = [];

        foreach ($productosEnPromocion as $producto) {
            // Asegúrate de que no estemos añadiendo el mismo producto varias veces
            if (!isset($productos[$producto['id']])) {
                $productos[$producto['id']] = $producto; // Guarda el producto
                $productos[$producto['id']]['tallas_assoc'] = []; // Inicializa el array de tallas

                // Obtener tallas para este producto
                $productoTallas = $this->modelo->obtenerTallaPorProducto($producto['id']);
                foreach ($productoTallas as $talla) {
                    $productos[$producto['id']]['tallas_assoc'][$talla['id']] = [
                        'nombre' => $talla['talla'], 
                    ];
                }
            }
        }

        // Cargar la vista de promociones
        require_once '../public/vistas/promo/Promociones.php';
    }
}

