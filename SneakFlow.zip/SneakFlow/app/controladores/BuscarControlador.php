<?php
require_once __DIR__ . '/../modelos/BusquedaModelo.php'; // Asegúrate de que la ruta sea correcta
require_once __DIR__ . '/../modelos/ProductoModelo.php';

class BuscarControlador {
    private $busquedaModelo;
    private $productoModelo; // Modelo para manejar la información de los productos

    public function __construct() {
        $this->busquedaModelo = new BusquedaModelo();
        $this->productoModelo = new ProductoModelo(); // Inicializa el modelo de productos
    }

    public function buscarProductos() {
        // Verificar si hay un término de búsqueda
        if (isset($_POST['query']) && !empty(trim($_POST['query']))) {
            $busqueda = htmlspecialchars(trim($_POST['query']));
            $resultados = $this->busquedaModelo->buscarProductos($busqueda);

            $productosDetalles = [];

            foreach ($resultados as $resultado) {
                // Obtener detalles del producto a partir del ID
                $productoDetalles = $this->productoModelo->obtenerProductoPorId($resultado['id']);
                if ($productoDetalles) {
                    // Obtener tallas para el producto
                    $tallas = $this->productoModelo->obtenerTallasPorProducto($resultado['id']);
                    $productoDetalles['tallas_assoc'] = [];
                    
                    // Asocia las tallas al producto
                    foreach ($tallas as $talla) {
                        $productoDetalles['tallas_assoc'][$talla['id']] = $talla;
                    }

                    // Agrega el producto detallado a la lista
                    $productosDetalles[] = $productoDetalles;
                }
            }

            // Cargar la vista con los resultados
            include_once __DIR__ . '../../../public/vistas/Busqueda/buscar.php';
        } else {
            // Si no hay término de búsqueda, generar una alerta
            echo "<script>alert('Por favor ingresa un término de búsqueda.'); window.location.href = 'productos';</script>";
            exit();
        }
    }
}
?>
