<?php 
    class DetallePedidoModelo {
        private $db;

        public function __construct() {
            $conexionBD = new ConexionBD();
            $this->db = $conexionBD->getConnection();
        }

    
        public function crearDetallePedido($pedido_id, $producto_id, $talla_id, $cantidad, $precio, $metodo_pago, $numero_pago) {
            // Primero, intentamos restar la cantidad de la talla
            if ($this->restarCantidadTalla($talla_id, $cantidad)) {
                // Solo si la actualización fue exitosa, procedemos a insertar el detalle del pedido
                $sql = "INSERT INTO detalles_pedidos (pedido_id, producto_id, talla_id, cantidad, precio, metodo_pago, numero_pago)
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
                $stmt = $this->db->prepare($sql);
                $stmt->bind_param('iiiidsi', $pedido_id, $producto_id, $talla_id, $cantidad, $precio, $metodo_pago, $numero_pago);
                return $stmt->execute(); // Retorna true o false según el éxito
            } else {
                // Manejar el error si la actualización de la talla falla
                return false;
            }
        }
        
        
        private function restarCantidadTalla($talla_id, $cantidad) {
            $sql = "UPDATE tallas SET cantidad = cantidad - ? WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->bind_param('ii', $cantidad, $talla_id);
            return $stmt->execute(); // Retorna true o false según el éxito
        }
        
    }
?>