<?php
    class RepartidorModelo {
        private $db;

        public function __construct() {
            $conexionBD = new ConexionBD();
            $this->db = $conexionBD->getConnection();
        }
        
        public function agregarRepartidor($nombre, $contactoNombre, $contactoTelefono, $contactoEmail, $direccion) {
            // Prepara la consulta SQL
            $sql = "INSERT INTO repartidores (nombre, contacto_nombre, contacto_telefono, contacto_email, direccion) VALUES (?, ?, ?, ?, ?)";
            
            // Prepara la sentencia
            $stmt = $this->db->prepare($sql);
            
            // Bind de parámetros
            $stmt->bind_param('sssss', $nombre, $contactoNombre, $contactoTelefono, $contactoEmail, $direccion);
            
            // Ejecuta la consulta
            return $stmt->execute();
        }

        public function existeRepartidor($nombre) {
            $sql = "SELECT COUNT(*) FROM repartidores WHERE nombre = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->bind_param('s', $nombre); // Asegúrate de vincular el parámetro
            $stmt->execute();
            $count = "";
            $stmt->bind_result($count); // Vincula el resultado a la variable $count
            $stmt->fetch(); // Obtiene el resultado
            return $count > 0; // Devuelve true si existe, false si no
        }
    }