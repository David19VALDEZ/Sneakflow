<?php 

    class TallaModelo {
        
        private $db;

        public function __construct() {
            $conexionBD = new ConexionBD(); // Crea una instancia de la conexión a la base de datos
            $this->db = $conexionBD->getConnection(); // Obtiene la conexión a la base de datos
        }

        // Método para agregar una nueva talla
        public function agregarTalla($producto_id, $talla, $cantidad) {
            // Prepara la consulta SQL
            $sql = "INSERT INTO tallas (producto_id, talla, cantidad) VALUES (?, ?, ?)";

            // Prepara la declaración
            if ($stmt = $this->db->prepare($sql)) {
                // Vincula las variables a la declaración
                $stmt->bind_param("isi", $producto_id, $talla, $cantidad);

                // Ejecuta la declaración
                if ($stmt->execute()) {
                    // Cierra la declaración
                    $stmt->close();
                    return true; // La talla se agregó correctamente
                } else {
                    // Manejar el error de ejecución
                    echo "Error al ejecutar la consulta: " . $stmt->error;
                    return false;
                }
            } else {
                // Manejar el error de preparación
                echo "Error al preparar la consulta: " . $this->db->error;
                return false;
            }
        }

        public function actualizarTalla($tallaId, $producto_id, $talla, $cantidad) {
            $query = "UPDATE tallas SET talla = ?, cantidad = ? WHERE id = ? AND producto_id = ?";
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("siii", $talla, $cantidad, $tallaId, $producto_id);

            if ($stmt->execute()) {
                return true;
            }
            return false;
        }
    }

?>