<?php 
// Incluir el archivo de conexión a la base de datos
require_once __DIR__ . '/../../configuracion/conexionBD.php';

class InicioModelo {
    private $db; // Variable para almacenar la conexión a la base de datos

    // Constructor de la clase
    public function __construct() {
        // Crear una nueva instancia de la clase de conexión a la base de datos
        $conexionBD = new ConexionBD();
        // Obtener la conexión y asignarla a la variable $db
        $this->db = $conexionBD->getConnection();
    }

    public function obtenerMarcas() {
        $query = "SELECT * FROM marcas";
        $resultado = $this->db->query($query);
    
        if ($resultado) {
            $marcas = $resultado->fetch_all(MYSQLI_ASSOC);
            
            return $marcas; // Retorna los datos obtenidos
        } else {
            return []; // Retorna un array vacío si hay un error
        }
    }
    
}
