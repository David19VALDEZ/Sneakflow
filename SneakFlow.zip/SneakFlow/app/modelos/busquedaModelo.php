<?php
require_once __DIR__ . '/../../configuracion/conexionBD.php';

class BusquedaModelo {
    private $db; // Variable para almacenar la conexión a la base de datos

    // Constructor de la clase
    public function __construct() {
        // Crear una nueva instancia de la clase de conexión a la base de datos
        $conexionBD = new ConexionBD();
        // Obtener la conexión y asignarla a la variable $db
        $this->db = $conexionBD->getConnection();
    }

    public function buscarProductos($query) {
        // Escapar el término de búsqueda para evitar inyecciones SQL
        $query = '%' . $this->db->real_escape_string($query) . '%';
    
        // Consulta SQL para buscar productos por nombre, descripción o marca
        $sql = "SELECT productos.* 
                FROM productos 
                INNER JOIN marcas ON productos.marca_id = marcas.id 
                WHERE productos.nombre LIKE ? 
                OR productos.descripcion LIKE ? 
                OR marcas.marca LIKE ?";
    
        // Preparar la consulta
        $stmt = $this->db->prepare($sql);
        
        // Vincular los parámetros (el término de búsqueda se aplica en tres lugares)
        $stmt->bind_param('sss', $query, $query, $query);
        
        // Ejecutar la consulta
        $stmt->execute();
        
        // Obtener los resultados
        $result = $stmt->get_result();
        $productos = $result->fetch_all(MYSQLI_ASSOC);
    
        // Cierra la conexión y devuelve los productos
        $stmt->close();
        return $productos;
    }   

    public function obtenerProductoPorId($id) {
        // Consulta SQL para seleccionar los detalles del producto junto con la marca y el color
        $query = "
            SELECT 
                p.id, 
                p.nombre, 
                p.descripcion, 
                p.precio, 
                p.imagen, 
                m.marca AS marca, 
                c.color AS color, 
                p.genero, 
                p.descuento,
                p.existencias,
                p.fecha_agregado
            FROM productos p
            LEFT JOIN marcas m ON p.marca_id = m.id
            LEFT JOIN colores c ON p.color_id = c.id
            WHERE p.id = ?
        ";

        // Prepara la declaración
        $stmt = $this->db->prepare($query);
        
        // Manejo de errores de preparación de la declaración
        if ($stmt === false) {
            die('Error en la preparación de la consulta: ' . $this->db->error);
        }

        // Asocia el parámetro de entrada (ID del producto) a la declaración
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        // Obtiene el resultado de la ejecución de la consulta
        $resultado = $stmt->get_result();

        // Verifica si se encontraron resultados
        if ($resultado->num_rows > 0) {
            // Devuelve el primer resultado como un arreglo asociativo
            return $resultado->fetch_assoc();
        } else {
            // Devuelve null si no se encuentra el producto (o lanzar una excepción si prefieres)
            return null; 
        }
    }

    public function obtenerTallasPorProducto($productoId) {
        // Consulta SQL para seleccionar el ID, la talla y la cantidad de la tabla tallas
        $query = "SELECT id, talla, cantidad FROM tallas WHERE producto_id = ?";
        $stmt = $this->db->prepare($query);
        
        // Asocia el parámetro de entrada (ID del producto) a la declaración
        $stmt->bind_param("i", $productoId);
        $stmt->execute();
        
        // Obtiene el resultado de la ejecución de la consulta
        $result = $stmt->get_result();
        
        // Inicializa un arreglo para almacenar las tallas
        $tallas = [];
        
        // Itera sobre los resultados y agrega cada talla al arreglo
        while ($row = $result->fetch_assoc()) {
            $tallas[] = $row;
        }
        
        // Devuelve el arreglo de tallas
        return $tallas;
    }
}
?>
