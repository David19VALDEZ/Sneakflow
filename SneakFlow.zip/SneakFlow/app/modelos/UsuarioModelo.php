<?php

require_once __DIR__ . '/../../configuracion/conexionBD.php'; // Incluye el archivo de conexión a la base de datos

class UsuarioModelo {

    private $db;

    public function __construct() {
        $conexionBD = new ConexionBD(); // Crea una instancia de la conexión a la base de datos
        $this->db = $conexionBD->getConnection(); // Obtiene la conexión a la base de datos
    }

    public function obtenerTodosLosUsuarios() {
        $stmt = $this->db->prepare("SELECT * FROM usuarios"); // Prepara la consulta
        $stmt->execute(); // Ejecuta la consulta
        $result = $stmt->get_result(); // Obtiene el resultado
        return $result->fetch_all(MYSQLI_ASSOC); // Devuelve todos los datos como un array asociativo
    }
    

    // Obtiene los datos del usuario por su ID
    public function obtenerUsuarioPorId($id) {
        $stmt = $this->db->prepare("SELECT  usuario, correo, rol FROM usuarios WHERE id = ?"); // Prepara la consulta
        $stmt->bind_param("i", $id); // Víncula el parámetro (i para entero)
        $stmt->execute(); // Ejecuta la consulta
        $result = $stmt->get_result(); // Obtiene el resultado
        return $result->fetch_assoc(); // Devuelve los datos como un array asociativo
    }

    // Obtiene los datos del usuario por su nombre
    public function obtenerUsuarioPorNombre($usuario) {
        $stmt = $this->db->prepare("SELECT id, usuario, contrasena, rol FROM usuarios WHERE usuario = ?"); // Prepara la consulta
        $stmt->bind_param("s", $usuario); // Víncula el parámetro
        $stmt->execute(); // Ejecuta la consulta
        $result = $stmt->get_result(); // Obtiene el resultado
        return $result->fetch_assoc(); // Devuelve los datos como un array asociativo
    }

    // Verifica si el usuario o correo ya existen en la base de datos
    public function verificarUsuarioExistente($usuario, $correo) {
        $stmt = $this->db->prepare("SELECT * FROM usuarios WHERE correo = ? OR usuario = ?"); // Prepara la consulta
        $stmt->bind_param("ss", $correo, $usuario); // Víncula los parámetros
        $stmt->execute(); // Ejecuta la consulta
        $result = $stmt->get_result(); // Obtiene el resultado
        return $result->num_rows > 0; // Devuelve verdadero si hay registros, falso si no hay
    }

    // Registra un nuevo usuario en la base de datos
    public function registrarUsuario($usuario, $correo, $contraseña) {
        $stmt = $this->db->prepare("INSERT INTO usuarios (usuario, correo, contrasena) VALUES (?, ?, ?)"); // Prepara la consulta
        $stmt->bind_param("sss", $usuario, $correo, $contraseña); // Víncula los parámetros
        return $stmt->execute(); // Ejecuta la consulta y devuelve el resultado
    }

    public function registrarUsuarioAdmin($usuario, $correo,$tipo_documento,$numero_documento, $telefono, $direccion, $contrasena, $rol) {
        // Hashear la contraseña
        $hashedPassword = password_hash($contrasena, PASSWORD_DEFAULT);

        // Preparar la consulta SQL
        $sql = "INSERT INTO usuarios (usuario, correo, tipo_documento, numero_documento, telefono, direccion, contrasena, rol) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        // Preparar la declaración
        $stmt = $this->db->prepare($sql);
        if ($stmt === false) {
            die('Error en la preparación de la declaración: ' . htmlspecialchars($this->db->error));
        }

        // Enlazar los parámetros
        $stmt->bind_param('ssssisss', $usuario, $correo,$tipo_documento,$numero_documento, $telefono, $direccion, $hashedPassword, $rol);
        
        // Ejecutar la declaración
        if ($stmt->execute()) {
            return true; // Registro exitoso
        } else {
            return false; // Fallo en el registro
        }
    }

    public function ActualizarUsuario($usuario_id, $tipo_documento, $numero_documento, $telefono, $direccion) {
        // Preparar la consulta SQL
        $sql = "UPDATE usuarios 
                SET tipo_documento = ?, 
                    numero_documento = ?, 
                    telefono = ?, 
                    direccion = ? 
                WHERE id = ?";
    
        // Preparar la declaración
        if ($stmt = $this->db->prepare($sql)) {
            // Vincular parámetros
            $stmt->bind_param("ssssi", $tipo_documento, $numero_documento, $telefono, $direccion, $usuario_id);
    
            // Ejecutar la declaración
            if ($stmt->execute()) {
                // Comprobar si se actualizó al menos una fila
                if ($stmt->affected_rows > 0) {
                    return true; // Actualización exitosa
                } else {
                    return false; // No se actualizó ninguna fila (posiblemente, no hubo cambios)
                }
            } else {
                // Manejo de errores al ejecutar la declaración
                throw new Exception("Error al ejecutar la consulta: " . $stmt->error);
            }
    
            // Cerrar la declaración
            $stmt->close();
        } else {
            // Manejo de errores al preparar la consulta
            throw new Exception("Error al preparar la consulta: " . $this->db->error);
        }
    }
    

    public function editarUsuario($id, $usuario, $correo, $tipo_documento,$numero_documento, $telefono, $direccion) {
        // Prepara la consulta SQL
        $stmt = $this->db->prepare("UPDATE usuarios SET usuario = ?, correo = ?, tipo_documento = ?, numero_documento = ?, telefono = ?, direccion = ? WHERE id = ?");
        
        // Asegúrate de que todos los parámetros coincidan
        if ($stmt === false) {
            die("Error en la preparación de la consulta: " . $this->db->error);
        }
    
        // Vincula los parámetros, asegúrate de que la cantidad y tipos coincidan
        $stmt->bind_param('sssissi', $usuario, $correo,$tipo_documento,$numero_documento, $telefono, $direccion, $id);
    
        // Ejecuta la consulta
        if ($stmt->execute()) {
            return true; // Retorna verdadero si la ejecución fue exitosa
        } else {
            return false; // Retorna falso si hubo un error
        }
    }
    
    

    public function eliminarUsuario($id){
        $sql = "DELETE FROM usuarios WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute(); // Ejecuta la consulta
    }
}
?>
