<?php
require_once __DIR__ . '/../../configuracion/conexionBD.php';

class PromocionModelo {
    // Propiedad para almacenar la conexión a la base de datos
    private $db;

    // Constructor que inicializa la conexión a la base de datos usando la clase ConexionBD
    public function __construct() {
        $conexionBD = new ConexionBD(); 
        $this->db = $conexionBD->getConnection();
    }

    // Método para obtener los productos en promoción
    public function obtenerProductosEnPromocion() {
        // Consulta para obtener productos en promoción y su marca
        $query = "
            SELECT p.*, m.marca AS marca_nombre, t.id AS talla_id, t.talla AS talla_nombre 
            FROM productos p 
            LEFT JOIN marcas m ON p.marca_id = m.id 
            LEFT JOIN tallas t ON p.id = t.producto_id 
            WHERE p.promocion = 1
        ";

        
        // Manejo de errores
        if ($resultado = $this->db->query($query)) {
            $productos = [];

            while ($producto = $resultado->fetch_assoc()) {
                // Agregamos colores y tallas al producto
                $producto['colores'] = $this->obtenerColoresPorProducto($producto['id']);
                $producto['tallas'] = $this->obtenerTallasPorProducto($producto['id']); // Aquí agregamos las tallas
                $productos[] = $producto;
            }

            $resultado->free(); // Liberar el resultado
            return $productos;
        } else {
            // Aquí podrías registrar el error o manejarlo como prefieras
            error_log("Error en la consulta: " . $this->db->error);
            return [];
        }
    }

    // Método para obtener los colores de un producto específico
    private function obtenerColoresPorProducto($idProducto) {
        $query = "
            SELECT colores.color 
            FROM productos 
            INNER JOIN colores ON productos.color_id = colores.id 
            WHERE productos.id = ?
        ";

        if ($stmt = $this->db->prepare($query)) {
            $stmt->bind_param("i", $idProducto); // Enlazar el ID del producto
            $stmt->execute();
            $resultado = $stmt->get_result();

            $colores = [];
            while ($color = $resultado->fetch_assoc()) {
                $colores[] = $color['color'];
            }

            $stmt->close(); // Cerrar la declaración
            return $colores;
        } else {
            error_log("Error en la consulta de colores: " . $this->db->error);
            return [];
        }
    }

    // Método para obtener las tallas de un producto específico
    private function obtenerTallasPorProducto($idProducto) {
        $query = "
            SELECT tallas.talla  
            FROM tallas 
            WHERE tallas.producto_id = ?
        ";

        if ($stmt = $this->db->prepare($query)) {
            $stmt->bind_param("i", $idProducto); // Enlazar el ID del producto
            $stmt->execute();
            $resultado = $stmt->get_result();

            $tallas = [];
            while ($talla = $resultado->fetch_assoc()) {
                $tallas[] = $talla['talla'];
            }

            $stmt->close(); // Cerrar la declaración
            return $tallas;
        } else {
            error_log("Error en la consulta de tallas: " . $this->db->error);
            return [];
        }
    }

    public function obtenerTallaporProducto($productoId) {
        // Consulta SQL para seleccionar el ID, la talla y la cantidad de la tabla tallas
        $query = "SELECT id, talla FROM tallas WHERE producto_id = ?";
        $stmt = $this->db->prepare($query);
        
        // Asocia el parámetro de entrada (ID del producto) a la declaración
        $stmt->bind_param("i", $productoId);
        $stmt->execute();
        
        // Obtiene el resultado de la ejecución de la consulta
        $result = $stmt->get_result();
        
        // Inicializa un arreglo para almacenar las tallas
        $tallas = [];
        
        // Itera sobre los resultados y agrega cada talla al arreglo
        while ($row = $result->fetch_assoc()) {
            $tallas[] = $row;
        }
        
        // Devuelve el arreglo de tallas
        return $tallas;
    }
}
