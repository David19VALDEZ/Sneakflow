<?php
require_once __DIR__ . '/../../configuracion/conexionBD.php';

class PedidoModelo {
    private $db; // Variable para almacenar la conexión a la base de datos

    // Constructor de la clase
    public function __construct() {
        // Crear una nueva instancia de la clase de conexión a la base de datos
        $conexionBD = new ConexionBD();
        // Obtener la conexión y asignarla a la variable $db
        $this->db = $conexionBD->getConnection();
    }

    public function crearPedido($usuario_id, $total) {
        $sql = "INSERT INTO pedidos (usuario_id, total) VALUES (?, ?)";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('id', $usuario_id, $total);
        
        if ($stmt->execute()) {
            return $this->db->insert_id; // Retorna el ID del nuevo pedido
        }
        return false;
    }

    public function obtenerTallaPorId($talla_id) {
        // Asegúrate de tener la conexión a la base de datos
        $query = "SELECT * FROM tallas WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $talla_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc(); // Retorna la fila como un array asociativo
    }
    
    public function obtenerTodosLosPedidos() {
        $query = "
            SELECT 
                pedidos.*, 
                usuarios.usuario AS nombre_usuario, 
                usuarios.direccion AS direccion_producto,
                repartidores.nombre AS nombre_repartidor,
                detalles_pedidos.metodo_pago AS metodo_pago
            FROM pedidos 
            JOIN usuarios ON pedidos.usuario_id = usuarios.id
            JOIN repartidores ON pedidos.repartidor_id = repartidores.id
            LEFT JOIN detalles_pedidos ON pedidos.id = detalles_pedidos.pedido_id"; // Relación con detalles_pedido usando id_pedido
    
        $result = $this->db->query($query);
    
        if (!$result) {
            throw new Exception("Error al obtener pedidos: " . $this->db->error);
        }
    
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    public function CancelarPedido($id) {
        $this->db->begin_transaction();
        try {
            // Consultar detalles del pedido
            $detallesQuery = "SELECT producto_id, talla_id, cantidad FROM detalles_pedidos WHERE pedido_id = ?";
            $detallesStmt = $this->db->prepare($detallesQuery);
            $detallesStmt->bind_param('i', $id);
            $detallesStmt->execute();
            $result = $detallesStmt->get_result();
    
            // Restaurar cantidades
            while ($detalle = $result->fetch_assoc()) {
                $producto_id = $detalle['producto_id'];
                $talla_id = $detalle['talla_id'];
                $cantidad = $detalle['cantidad'];
    
                // Actualizar cantidad
                $restaurarQuery = "UPDATE tallas SET cantidad = cantidad + ? WHERE producto_id = ? AND id = ?";
                $restaurarStmt = $this->db->prepare($restaurarQuery);
                $restaurarStmt->bind_param('iii', $cantidad, $producto_id, $talla_id);
                $restaurarStmt->execute();
            }
    
            // Obtener el repartidor asignado al pedido
            $repartidorQuery = "SELECT repartidor_id FROM pedidos WHERE id = ?";
            $repartidorStmt = $this->db->prepare($repartidorQuery);
            $repartidorStmt->bind_param('i', $id);
            $repartidorStmt->execute();
            $repartidorResult = $repartidorStmt->get_result();
            $repartidor = $repartidorResult->fetch_assoc();
            $repartidor_id = $repartidor['repartidor_id'];
    
            // Disminuir el contador de pedidos del repartidor en 1
            $actualizarRepartidorQuery = "UPDATE repartidores SET pedidos_activos = pedidos_activos - 1 WHERE id = ?";
            $actualizarRepartidorStmt = $this->db->prepare($actualizarRepartidorQuery);
            $actualizarRepartidorStmt->bind_param('i', $repartidor_id);
            $actualizarRepartidorStmt->execute();
    
            // Eliminar el pedido
            $query = "DELETE FROM pedidos WHERE id = ?";
            $stmt = $this->db->prepare($query);
            $stmt->bind_param('i', $id);
            $stmt->execute();
    
            $this->db->commit();
            return true; // Éxito
        } catch (Exception $e) {
            $this->db->rollback();
            return false; // Error
        }
    }
    
    public function actualizarEstadoPedido($pedido_id, $nuevo_estado) {
        // Preparar la consulta SQL para actualizar el estado del pedido
        $sql = "UPDATE pedidos SET estado = ? WHERE id = ?";
    
        // Preparar la declaración
        $stmt = $this->db->prepare($sql);
    
        // Bind de los parámetros
        $stmt->bind_param('si', $nuevo_estado, $pedido_id);
    
        // Ejecutar la declaración
        if ($stmt->execute()) {
            return true;
        } else {
            throw new Exception("No se pudo actualizar el estado del pedido.");
        }
    }
    
    
}

